# SmartStock

SmartStock is a MySQL-backed inventory management application designed for a DBMS project demonstration.

## Project status

The workspace has been initialized and the database seed files are being validated before any manual execution. The original sample data file was reviewed for schema consistency and was found to contain stock totals that do not match the movement history. A corrected seed file is provided separately and must be run manually only on an empty SmartStock database.

## Structure

- `client/` – React + Vite frontend
- `server/` – Express.js backend and API layer
- `database/` – MySQL schema, views, procedures, triggers, and data scripts
- `database/sample_data.sql` – original provided seed; left untouched
- `database/sample_data_corrected.sql` – corrected seed for empty database use only

## Seed file safety note

The original sample seed script is intentionally not executed automatically. It contains fixed IDs and is designed for a one-time empty-database setup only. Do not re-run it against a database that already contains records.

If your database already contains data, inspect the tables first and use a different test database or backup before running any seed script.

## Run the corrected seed in MySQL

From MySQL Shell or the MySQL client, connect to the SmartStock database and run the corrected script manually:

```
mysql -u root -p
USE SmartStock;
SOURCE C:/path/to/smartstock/database/sample_data_corrected.sql;
```

Or from the command line:

```
mysql -u root -p SmartStock < C:/path/to/smartstock/database/sample_data_corrected.sql
```

The command should be run only once against an empty SmartStock database.

## Important data risks identified

The original `sample_data.sql` contains current product stock totals that do not match the recorded stock movement history:

- Product 1: movement history implies 41 units, but the seed sets 42
- Product 3: movement history implies 18 units, but the seed sets 8
- Product 5: movement history implies 13 units, but the seed sets 4

These mismatches can make inventory totals inaccurate and create invalid dashboard and BI outputs if the script is used as-is. The corrected seed resolves those inconsistencies while keeping the original fixed IDs and sample data pattern intact.

## Next phases

1. Confirm the live MySQL schema and credentials.
2. Build the Express API and validate MySQL connectivity.
3. Implement product, category, supplier, and customer modules.
4. Add transactional purchase and sales workflows.
5. Complete reporting, BI, and dashboard functionality.
