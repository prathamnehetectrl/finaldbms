import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar.jsx';
import TopNav from './components/TopNav.jsx';
import Toast from './components/Toast.jsx';

// Pages
import DashboardPage from './pages/DashboardPage.jsx';
import InventoryPage from './pages/InventoryPage.jsx';
import CategoriesPage from './pages/CategoriesPage.jsx';
import SuppliersPage from './pages/SuppliersPage.jsx';
import CustomersPage from './pages/CustomersPage.jsx';
import PurchasesPage from './pages/PurchasesPage.jsx';
import SalesPage from './pages/SalesPage.jsx';
import PaymentsPage from './pages/PaymentsPage.jsx';
import MovementsPage from './pages/MovementsPage.jsx';
import BIPage from './pages/BIPage.jsx';
import ReportsPage from './pages/ReportsPage.jsx';
import SettingsPage from './pages/SettingsPage.jsx';

// API
import { api } from './api/client';

export default function App() {
  const [activePage, setActivePage] = useState('dashboard');
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  // Core Data Collections
  const [dashboardData, setDashboardData] = useState(null);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [sales, setSales] = useState([]);
  const [payments, setPayments] = useState([]);
  const [movements, setMovements] = useState([]);
  const [biData, setBiData] = useState({});

  // Toasts
  const [toasts, setToasts] = useState([]);

  const showToast = useCallback((message, type = 'info', title = '') => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message, type, title }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  }, []);

  const dismissToast = (id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Master Data Refresh
  const loadAllData = useCallback(async () => {
    setLoading(true);
    try {
      const [
        dashRes,
        prodRes,
        catRes,
        supRes,
        custRes,
        purchRes,
        saleRes,
        payRes,
        movRes,
        biRes
      ] = await Promise.all([
        api.getDashboard().catch(() => null),
        api.getProducts().catch(() => []),
        api.getCategories().catch(() => []),
        api.getSuppliers().catch(() => []),
        api.getCustomers().catch(() => []),
        api.getPurchases().catch(() => []),
        api.getSales().catch(() => []),
        api.getPayments().catch(() => []),
        api.getMovements().catch(() => []),
        api.getBI().catch(() => ({}))
      ]);

      if (dashRes) setDashboardData(dashRes);
      if (prodRes) setProducts(prodRes);
      if (catRes) setCategories(catRes);
      if (supRes) setSuppliers(supRes);
      if (custRes) setCustomers(custRes);
      if (purchRes) setPurchases(purchRes);
      if (saleRes) setSales(saleRes);
      if (payRes) setPayments(payRes);
      if (movRes) setMovements(movRes);
      if (biRes) setBiData(biRes);
    } catch (err) {
      console.error('Failed to load application data:', err);
      showToast('Could not load some data from MySQL. Please check server.', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // CRUD Handler Bindings
  const handleAddProduct = async (data) => {
    await api.createProduct(data);
    await loadAllData();
  };

  const handleUpdateProduct = async (id, data) => {
    await api.updateProduct(id, data);
    await loadAllData();
  };

  const handleDeleteProduct = async (id) => {
    await api.deleteProduct(id);
    await loadAllData();
  };

  const handleAddCategory = async (data) => {
    await api.createCategory(data);
    await loadAllData();
  };

  const handleUpdateCategory = async (id, data) => {
    await api.updateCategory(id, data);
    await loadAllData();
  };

  const handleDeleteCategory = async (id) => {
    await api.deleteCategory(id);
    await loadAllData();
  };

  const handleAddSupplier = async (data) => {
    await api.createSupplier(data);
    await loadAllData();
  };

  const handleUpdateSupplier = async (id, data) => {
    await api.updateSupplier(id, data);
    await loadAllData();
  };

  const handleDeleteSupplier = async (id) => {
    await api.deleteSupplier(id);
    await loadAllData();
  };

  const handleAddCustomer = async (data) => {
    await api.createCustomer(data);
    await loadAllData();
  };

  const handleUpdateCustomer = async (id, data) => {
    await api.updateCustomer(id, data);
    await loadAllData();
  };

  const handleDeleteCustomer = async (id) => {
    await api.deleteCustomer(id);
    await loadAllData();
  };

  const handleCreatePurchase = async (data) => {
    const res = await api.createPurchase(data);
    await loadAllData();
    return res;
  };

  const handleUpdatePurchaseStatus = async (id, status) => {
    const res = await api.updatePurchaseStatus(id, status);
    await loadAllData();
    return res;
  };

  const handleCreateSale = async (data) => {
    const res = await api.createSale(data);
    await loadAllData();
    return res;
  };

  const handleCancelSale = async (id) => {
    const res = await api.cancelSale(id);
    await loadAllData();
    return res;
  };

  const handleAddPayment = async (data) => {
    const res = await api.createPayment(data);
    await loadAllData();
    return res;
  };

  const handleAddMovement = async (data) => {
    const res = await api.createMovement(data);
    await loadAllData();
    return res;
  };

  // Derive low stock list
  const lowStockItems = products.filter(
    (p) => Number(p.stock_quantity) <= Number(p.reorder_level)
  );

  return (
    <div className="app-shell">
      {/* Toast Notification Layer */}
      <Toast toasts={toasts} onDismiss={dismissToast} />

      {/* Collapsible Sidebar */}
      <Sidebar
        activePage={activePage}
        setActivePage={setActivePage}
        collapsed={collapsed}
        setCollapsed={setCollapsed}
        mobileOpen={mobileOpen}
        setMobileOpen={setMobileOpen}
        stats={{
          totalProducts: products.length,
          lowStockCount: lowStockItems.length,
          pendingPurchases: purchases.filter((p) => p.status === 'Pending').length
        }}
      />

      {/* Main Layout Area */}
      <div className={`main-layout ${collapsed ? 'sidebar-collapsed' : ''}`}>
        {/* Top Navigation */}
        <TopNav
          activePage={activePage}
          setActivePage={setActivePage}
          onRefresh={loadAllData}
          loading={loading}
          onOpenNewSale={() => setActivePage('sales')}
          setMobileOpen={setMobileOpen}
          lowStockItems={lowStockItems}
          allProducts={products}
          allCustomers={customers}
          allSuppliers={suppliers}
        />

        {/* Dynamic Page Views */}
        <main className="content-viewport">
          {activePage === 'dashboard' && (
            <DashboardPage
              dashboardData={dashboardData}
              loading={loading}
              onRefresh={loadAllData}
              setActivePage={setActivePage}
              onOpenNewSale={() => setActivePage('sales')}
            />
          )}

          {activePage === 'inventory' && (
            <InventoryPage
              products={products}
              categories={categories}
              suppliers={suppliers}
              loading={loading}
              onAddProduct={handleAddProduct}
              onUpdateProduct={handleUpdateProduct}
              onDeleteProduct={handleDeleteProduct}
              onRefresh={loadAllData}
              showToast={showToast}
            />
          )}

          {activePage === 'categories' && (
            <CategoriesPage
              categories={categories}
              loading={loading}
              onAddCategory={handleAddCategory}
              onUpdateCategory={handleUpdateCategory}
              onDeleteCategory={handleDeleteCategory}
              onRefresh={loadAllData}
              showToast={showToast}
            />
          )}

          {activePage === 'suppliers' && (
            <SuppliersPage
              suppliers={suppliers}
              loading={loading}
              onAddSupplier={handleAddSupplier}
              onUpdateSupplier={handleUpdateSupplier}
              onDeleteSupplier={handleDeleteSupplier}
              onRefresh={loadAllData}
              showToast={showToast}
            />
          )}

          {activePage === 'customers' && (
            <CustomersPage
              customers={customers}
              loading={loading}
              onAddCustomer={handleAddCustomer}
              onUpdateCustomer={handleUpdateCustomer}
              onDeleteCustomer={handleDeleteCustomer}
              onRefresh={loadAllData}
              showToast={showToast}
            />
          )}

          {activePage === 'purchases' && (
            <PurchasesPage
              purchases={purchases}
              suppliers={suppliers}
              products={products}
              loading={loading}
              onCreatePurchase={handleCreatePurchase}
              onUpdateStatus={handleUpdatePurchaseStatus}
              onRefresh={loadAllData}
              showToast={showToast}
            />
          )}

          {activePage === 'sales' && (
            <SalesPage
              sales={sales}
              customers={customers}
              products={products}
              loading={loading}
              onCreateSale={handleCreateSale}
              onCancelSale={handleCancelSale}
              onRefresh={loadAllData}
              showToast={showToast}
            />
          )}

          {activePage === 'payments' && (
            <PaymentsPage
              payments={payments}
              loading={loading}
              onAddPayment={handleAddPayment}
              onRefresh={loadAllData}
              showToast={showToast}
            />
          )}

          {activePage === 'movements' && (
            <MovementsPage
              movements={movements}
              products={products}
              loading={loading}
              onAddMovement={handleAddMovement}
              onRefresh={loadAllData}
              showToast={showToast}
            />
          )}

          {activePage === 'bi' && (
            <BIPage
              biData={biData}
              loading={loading}
              setActivePage={setActivePage}
              onRefresh={loadAllData}
            />
          )}

          {activePage === 'reports' && (
            <ReportsPage showToast={showToast} />
          )}

          {activePage === 'settings' && (
            <SettingsPage showToast={showToast} />
          )}
        </main>
      </div>
    </div>
  );
}
