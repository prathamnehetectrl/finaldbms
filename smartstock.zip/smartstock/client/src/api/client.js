const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export async function apiRequest(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  const response = await fetch(url, {
    ...options,
    headers
  });

  const contentType = response.headers.get('content-type') || '';
  let data = null;
  if (contentType.includes('application/json')) {
    data = await response.json();
  } else {
    data = await response.text();
  }

  if (!response.ok) {
    const errorMsg = data && data.error ? data.error : (data && data.message ? data.message : `Request failed with status ${response.status}`);
    throw new Error(errorMsg);
  }

  return data;
}

export const api = {
  // Dashboard
  getDashboard: () => apiRequest('/dashboard'),

  // Products
  getProducts: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/products${query ? `?${query}` : ''}`);
  },
  getProduct: (id) => apiRequest(`/products/${id}`),
  createProduct: (data) => apiRequest('/products', { method: 'POST', body: JSON.stringify(data) }),
  updateProduct: (id, data) => apiRequest(`/products/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteProduct: (id) => apiRequest(`/products/${id}`, { method: 'DELETE' }),

  // Categories
  getCategories: () => apiRequest('/categories'),
  createCategory: (data) => apiRequest('/categories', { method: 'POST', body: JSON.stringify(data) }),
  updateCategory: (id, data) => apiRequest(`/categories/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteCategory: (id) => apiRequest(`/categories/${id}`, { method: 'DELETE' }),

  // Suppliers
  getSuppliers: () => apiRequest('/suppliers'),
  getSupplier: (id) => apiRequest(`/suppliers/${id}`),
  createSupplier: (data) => apiRequest('/suppliers', { method: 'POST', body: JSON.stringify(data) }),
  updateSupplier: (id, data) => apiRequest(`/suppliers/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteSupplier: (id) => apiRequest(`/suppliers/${id}`, { method: 'DELETE' }),

  // Customers
  getCustomers: () => apiRequest('/customers'),
  getCustomer: (id) => apiRequest(`/customers/${id}`),
  createCustomer: (data) => apiRequest('/customers', { method: 'POST', body: JSON.stringify(data) }),
  updateCustomer: (id, data) => apiRequest(`/customers/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteCustomer: (id) => apiRequest(`/customers/${id}`, { method: 'DELETE' }),

  // Purchases
  getPurchases: () => apiRequest('/purchases'),
  getPurchase: (id) => apiRequest(`/purchases/${id}`),
  createPurchase: (data) => apiRequest('/purchases', { method: 'POST', body: JSON.stringify(data) }),
  updatePurchaseStatus: (id, status) => apiRequest(`/purchases/${id}/status`, { method: 'PUT', body: JSON.stringify({ status }) }),

  // Sales
  getSales: () => apiRequest('/sales'),
  getSale: (id) => apiRequest(`/sales/${id}`),
  createSale: (data) => apiRequest('/sales', { method: 'POST', body: JSON.stringify(data) }),
  cancelSale: (id) => apiRequest(`/sales/${id}/cancel`, { method: 'PUT' }),

  // Payments
  getPayments: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/payments${query ? `?${query}` : ''}`);
  },
  createPayment: (data) => apiRequest('/payments', { method: 'POST', body: JSON.stringify(data) }),

  // Stock Movements
  getMovements: (params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/stock-movements${query ? `?${query}` : ''}`);
  },
  createMovement: (data) => apiRequest('/stock-movements', { method: 'POST', body: JSON.stringify(data) }),

  // BI
  getBI: () => apiRequest('/bi'),

  // Reports
  getReport: (type, params = {}) => {
    const query = new URLSearchParams(params).toString();
    return apiRequest(`/reports/${type}${query ? `?${query}` : ''}`);
  },

  // System
  getSystemHealth: () => apiRequest('/system/health')
};

export const formatCurrency = (value) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(Number(value) || 0);
};

export const formatDate = (dateStr) => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
};
