import React, { useState } from 'react';
import { formatCurrency } from '../api/client';

export function AreaTrendChart({ data = [], height = 240 }) {
  const [hoveredIdx, setHoveredIdx] = useState(null);

  if (!data || data.length === 0) {
    return <div className="chart-empty-state">No sales history available for trend analysis</div>;
  }

  const values = data.map(d => Number(d.revenue) || 0);
  const maxVal = Math.max(...values, 100);
  const minVal = 0;
  const paddingX = 40;
  const paddingY = 25;
  const width = 600;
  const innerWidth = width - paddingX * 2;
  const innerHeight = height - paddingY * 2;

  const points = data.map((d, i) => {
    const x = paddingX + (i / Math.max(data.length - 1, 1)) * innerWidth;
    const y = height - paddingY - ((Number(d.revenue) - minVal) / (maxVal - minVal)) * innerHeight;
    return { x, y, ...d };
  });

  // Generate smooth SVG path
  let pathD = `M ${points[0].x} ${points[0].y}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const mx = (p0.x + p1.x) / 2;
    pathD += ` C ${mx} ${p0.y}, ${mx} ${p1.y}, ${p1.x} ${p1.y}`;
  }

  const areaD = `${pathD} L ${points[points.length - 1].x} ${height - paddingY} L ${points[0].x} ${height - paddingY} Z`;

  return (
    <div className="chart-container" style={{ position: 'relative' }}>
      <svg viewBox={`0 0 ${width} ${height}`} className="responsive-svg">
        <defs>
          <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2563eb" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#2563eb" stopOpacity="0.0" />
          </linearGradient>
        </defs>

        {/* Horizontal grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((pct, idx) => {
          const y = height - paddingY - pct * innerHeight;
          const val = maxVal * pct;
          return (
            <g key={idx}>
              <line x1={paddingX} y1={y} x2={width - paddingX} y2={y} stroke="#e2e8f0" strokeDasharray="3 3" />
              <text x={paddingX - 8} y={y + 4} textAnchor="end" className="chart-axis-label">
                ₹{val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val.toFixed(0)}
              </text>
            </g>
          );
        })}

        {/* Area fill & line */}
        <path d={areaD} fill="url(#areaGradient)" />
        <path d={pathD} fill="none" stroke="#2563eb" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

        {/* Data points & X-axis labels */}
        {points.map((p, i) => (
          <g key={i} onMouseEnter={() => setHoveredIdx(i)} onMouseLeave={() => setHoveredIdx(null)} style={{ cursor: 'pointer' }}>
            <circle
              cx={p.x}
              cy={p.y}
              r={hoveredIdx === i ? 6 : 4}
              fill="#ffffff"
              stroke="#2563eb"
              strokeWidth={hoveredIdx === i ? 3 : 2}
            />
            <text x={p.x} y={height - 6} textAnchor="middle" className="chart-axis-label">
              {p.month_label}
            </text>
          </g>
        ))}
      </svg>

      {/* Hover Tooltip */}
      {hoveredIdx !== null && (
        <div
          className="chart-tooltip"
          style={{
            left: `${(points[hoveredIdx].x / width) * 100}%`,
            top: `${(points[hoveredIdx].y / height) * 100 - 15}%`
          }}
        >
          <div className="tooltip-title">{points[hoveredIdx].month_label}</div>
          <div className="tooltip-value">{formatCurrency(points[hoveredIdx].revenue)}</div>
        </div>
      )}
    </div>
  );
}

export function RevenueVsProfitChart({ data = [], height = 240 }) {
  const [hoveredIdx, setHoveredIdx] = useState(null);

  if (!data || data.length === 0) {
    return <div className="chart-empty-state">No revenue vs profit records to display</div>;
  }

  const maxVal = Math.max(...data.map(d => Math.max(Number(d.revenue) || 0, Number(d.profit) || 0)), 100);
  const width = 600;
  const paddingX = 40;
  const paddingY = 25;
  const innerWidth = width - paddingX * 2;
  const innerHeight = height - paddingY * 2;
  const groupWidth = innerWidth / data.length;
  const barWidth = Math.min(22, groupWidth * 0.35);

  return (
    <div className="chart-container" style={{ position: 'relative' }}>
      <div className="chart-legend">
        <span className="legend-item"><span className="legend-color" style={{ background: '#2563eb' }} /> Revenue</span>
        <span className="legend-item"><span className="legend-color" style={{ background: '#10b981' }} /> Gross Profit</span>
      </div>
      <svg viewBox={`0 0 ${width} ${height}`} className="responsive-svg">
        {[0, 0.5, 1].map((pct, idx) => {
          const y = height - paddingY - pct * innerHeight;
          const val = maxVal * pct;
          return (
            <g key={idx}>
              <line x1={paddingX} y1={y} x2={width - paddingX} y2={y} stroke="#e2e8f0" strokeDasharray="3 3" />
              <text x={paddingX - 8} y={y + 4} textAnchor="end" className="chart-axis-label">
                ₹{val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val.toFixed(0)}
              </text>
            </g>
          );
        })}

        {data.map((d, i) => {
          const centerX = paddingX + i * groupWidth + groupWidth / 2;
          const revH = (Number(d.revenue) / maxVal) * innerHeight;
          const profH = (Number(d.profit) / maxVal) * innerHeight;
          const revY = height - paddingY - revH;
          const profY = height - paddingY - profH;

          return (
            <g key={i} onMouseEnter={() => setHoveredIdx(i)} onMouseLeave={() => setHoveredIdx(null)} style={{ cursor: 'pointer' }}>
              {/* Revenue Bar */}
              <rect
                x={centerX - barWidth - 2}
                y={revY}
                width={barWidth}
                height={Math.max(revH, 2)}
                rx="3"
                fill="#2563eb"
                opacity={hoveredIdx === null || hoveredIdx === i ? 1 : 0.6}
              />
              {/* Profit Bar */}
              <rect
                x={centerX + 2}
                y={profY}
                width={barWidth}
                height={Math.max(profH, 2)}
                rx="3"
                fill="#10b981"
                opacity={hoveredIdx === null || hoveredIdx === i ? 1 : 0.6}
              />
              <text x={centerX} y={height - 6} textAnchor="middle" className="chart-axis-label">
                {d.month_label}
              </text>
            </g>
          );
        })}
      </svg>

      {hoveredIdx !== null && (
        <div
          className="chart-tooltip"
          style={{
            left: `${((paddingX + hoveredIdx * groupWidth + groupWidth / 2) / width) * 100}%`,
            top: '20%'
          }}
        >
          <div className="tooltip-title">{data[hoveredIdx].month_label}</div>
          <div className="tooltip-row"><span style={{ color: '#2563eb' }}>Revenue:</span> {formatCurrency(data[hoveredIdx].revenue)}</div>
          <div className="tooltip-row"><span style={{ color: '#10b981' }}>Profit:</span> {formatCurrency(data[hoveredIdx].profit)}</div>
        </div>
      )}
    </div>
  );
}

export function DonutChart({ data = [], height = 240 }) {
  const [hoveredIdx, setHoveredIdx] = useState(null);

  if (!data || data.length === 0) {
    return <div className="chart-empty-state">No category breakdown available</div>;
  }

  const colors = ['#2563eb', '#06b6d4', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];
  const total = data.reduce((sum, d) => sum + (Number(d.total_sales) || Number(d.value) || 0), 0);

  const radius = 70;
  const strokeWidth = 26;
  const center = 100;
  const circumference = 2 * Math.PI * radius;

  let currentOffset = 0;
  const segments = data.map((d, i) => {
    const val = Number(d.total_sales) || Number(d.value) || 0;
    const pct = total > 0 ? val / total : 0;
    const strokeDasharray = `${pct * circumference} ${circumference}`;
    const strokeDashoffset = -currentOffset;
    currentOffset += pct * circumference;
    return {
      ...d,
      value: val,
      pct: (pct * 100).toFixed(1),
      strokeDasharray,
      strokeDashoffset,
      color: colors[i % colors.length]
    };
  });

  return (
    <div className="donut-wrap">
      <div className="donut-chart-box">
        <svg viewBox="0 0 200 200" width="180" height="180">
          <circle cx={center} cy={center} r={radius} fill="none" stroke="#f1f5f9" strokeWidth={strokeWidth} />
          {segments.map((s, i) => (
            <circle
              key={i}
              cx={center}
              cy={center}
              r={radius}
              fill="none"
              stroke={s.color}
              strokeWidth={hoveredIdx === i ? strokeWidth + 4 : strokeWidth}
              strokeDasharray={s.strokeDasharray}
              strokeDashoffset={s.strokeDashoffset}
              strokeLinecap="round"
              transform={`rotate(-90 ${center} ${center})`}
              onMouseEnter={() => setHoveredIdx(i)}
              onMouseLeave={() => setHoveredIdx(null)}
              style={{ transition: 'stroke-width 0.2s', cursor: 'pointer' }}
            />
          ))}
          <text x={center} y={center - 4} textAnchor="middle" className="donut-center-total">
            {formatCurrency(total)}
          </text>
          <text x={center} y={center + 14} textAnchor="middle" className="donut-center-sub">
            Total Sales
          </text>
        </svg>
      </div>

      <div className="donut-legend">
        {segments.map((s, i) => (
          <div
            key={i}
            className={`donut-legend-row ${hoveredIdx === i ? 'highlight' : ''}`}
            onMouseEnter={() => setHoveredIdx(i)}
            onMouseLeave={() => setHoveredIdx(null)}
          >
            <span className="legend-indicator" style={{ background: s.color }} />
            <span className="legend-name">{s.category_name || s.name}</span>
            <span className="legend-pct">{s.pct}%</span>
            <span className="legend-val">{formatCurrency(s.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function HorizontalBarChart({ data = [], labelKey = 'category_name', valueKey = 'total_units' }) {
  if (!data || data.length === 0) {
    return <div className="chart-empty-state">No distribution data to show</div>;
  }

  const maxVal = Math.max(...data.map(d => Number(d[valueKey]) || 0), 1);

  return (
    <div className="horizontal-bars">
      {data.map((item, idx) => {
        const val = Number(item[valueKey]) || 0;
        const pct = Math.min(100, Math.round((val / maxVal) * 100));

        return (
          <div key={idx} className="hbar-item">
            <div className="hbar-header">
              <span className="hbar-label">
                <strong>#{idx + 1}</strong> {item[labelKey]}
              </span>
              <span className="hbar-value">
                {val.toLocaleString('en-IN')} units {item.total_value ? `(${formatCurrency(item.total_value)})` : ''}
              </span>
            </div>
            <div className="hbar-track">
              <div
                className="hbar-fill"
                style={{
                  width: `${pct}%`,
                  background: idx === 0 ? '#2563eb' : idx === 1 ? '#3b82f6' : idx === 2 ? '#60a5fa' : '#93c5fd'
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
