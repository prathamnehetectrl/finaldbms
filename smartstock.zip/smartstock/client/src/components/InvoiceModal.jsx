import React from 'react';
import { Printer, Download, CheckCircle, Package } from 'lucide-react';
import Modal from './Modal.jsx';
import { formatCurrency, formatDate } from '../api/client';

export default function InvoiceModal({ isOpen, onClose, sale }) {
  if (!sale) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Tax Invoice #${sale.sale_id || ''}`}
      maxWidth="680px"
      footer={
        <div className="invoice-modal-actions no-print">
          <button className="btn btn-secondary" onClick={onClose}>
            Close
          </button>
          <button className="btn btn-primary" onClick={handlePrint}>
            <Printer size={16} /> Print Invoice
          </button>
        </div>
      }
    >
      <div className="invoice-paper" id="printable-invoice">
        {/* Invoice Header */}
        <div className="invoice-header">
          <div className="invoice-brand">
            <div className="brand-badge-icon"><Package size={22} /></div>
            <div>
              <h2>SmartStock Systems Ltd.</h2>
              <p>Intelligent Inventory Management</p>
              <p className="invoice-address">Tech Park, Phase II, Pune, Maharashtra 411057</p>
              <p className="invoice-tax">GSTIN: 27AABCS1429B1Z8</p>
            </div>
          </div>
          <div className="invoice-meta">
            <div className="invoice-badge">ORIGINAL INVOICE</div>
            <div className="invoice-id">INV-{String(sale.sale_id).padStart(5, '0')}</div>
            <div className="invoice-date">Date: {formatDate(sale.sale_date)}</div>
            <div className="invoice-status">
              Status: <span className="status-pill status-completed">{sale.status || 'Completed'}</span>
            </div>
          </div>
        </div>

        <hr className="invoice-divider" />

        {/* Customer Bill-To Info */}
        <div className="invoice-parties">
          <div className="party-box">
            <span className="party-label">BILLED TO:</span>
            <div className="party-name">{sale.customer_name || 'Walk-in Customer'}</div>
            {sale.customer_phone && <div className="party-detail">Phone: {sale.customer_phone}</div>}
            {sale.customer_email && <div className="party-detail">Email: {sale.customer_email}</div>}
            {sale.customer_address && <div className="party-detail">Address: {sale.customer_address}</div>}
          </div>
          <div className="party-box right">
            <span className="party-label">PAYMENT DETAILS:</span>
            <div className="party-detail">Method: <strong>{sale.payment_method || (sale.payments && sale.payments[0]?.payment_method) || 'Cash / Counter'}</strong></div>
            <div className="party-detail">Payment Status: <strong>PAID IN FULL</strong></div>
          </div>
        </div>

        {/* Line Items Table */}
        <div className="invoice-table-wrap">
          <table className="invoice-table">
            <thead>
              <tr>
                <th>#</th>
                <th>ITEM DESCRIPTION</th>
                <th>SKU</th>
                <th className="text-right">QTY</th>
                <th className="text-right">UNIT PRICE</th>
                <th className="text-right">AMOUNT</th>
              </tr>
            </thead>
            <tbody>
              {(sale.items || []).map((item, idx) => (
                <tr key={idx}>
                  <td>{idx + 1}</td>
                  <td><strong>{item.product_name}</strong></td>
                  <td><span className="sku-tag">{item.sku}</span></td>
                  <td className="text-right">{item.quantity}</td>
                  <td className="text-right">{formatCurrency(item.unit_price)}</td>
                  <td className="text-right"><strong>{formatCurrency(item.line_total || item.quantity * item.unit_price)}</strong></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Invoice Summary Totals */}
        <div className="invoice-summary-box">
          <div className="summary-row">
            <span>Subtotal:</span>
            <span>{formatCurrency(sale.total_amount)}</span>
          </div>
          <div className="summary-row">
            <span>Applicable Taxes (Integrated):</span>
            <span>Included in price</span>
          </div>
          <div className="summary-row total-row">
            <span>Total Payable:</span>
            <span>{formatCurrency(sale.total_amount)}</span>
          </div>
        </div>

        {/* Invoice Footer */}
        <div className="invoice-footer-notes">
          <p>Thank you for doing business with SmartStock Systems!</p>
          <p className="small-text">This is a computer-generated tax invoice verified by the MySQL inventory management database.</p>
        </div>
      </div>
    </Modal>
  );
}
