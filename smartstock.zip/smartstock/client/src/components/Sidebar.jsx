import React from 'react';
import {
  LayoutDashboard,
  Boxes,
  Package,
  Layers,
  Truck,
  Users,
  ShoppingCart,
  TrendingUp,
  CreditCard,
  ArrowLeftRight,
  Sparkles,
  FileSpreadsheet,
  Settings,
  ChevronLeft,
  ChevronRight,
  Database,
  ShieldCheck,
  X
} from 'lucide-react';

export default function Sidebar({
  activePage,
  setActivePage,
  collapsed,
  setCollapsed,
  mobileOpen,
  setMobileOpen,
  stats = {}
}) {
  const navSections = [
    {
      group: 'OVERVIEW',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard }
      ]
    },
    {
      group: 'INVENTORY & CATALOG',
      items: [
        { id: 'inventory', label: 'Inventory', icon: Package, badge: stats.totalProducts },
        { id: 'categories', label: 'Categories', icon: Layers },
        { id: 'suppliers', label: 'Suppliers', icon: Truck },
        { id: 'customers', label: 'Customers', icon: Users }
      ]
    },
    {
      group: 'OPERATIONS',
      items: [
        { id: 'purchases', label: 'Purchases', icon: ShoppingCart, badge: stats.pendingPurchases > 0 ? `${stats.pendingPurchases} pending` : null, badgeClass: 'badge-amber' },
        { id: 'sales', label: 'Sales (POS)', icon: TrendingUp },
        { id: 'payments', label: 'Payments', icon: CreditCard },
        { id: 'movements', label: 'Stock Movements', icon: ArrowLeftRight }
      ]
    },
    {
      group: 'ANALYTICS & BI',
      items: [
        { id: 'bi', label: 'Business Intelligence', icon: Sparkles, highlight: true },
        { id: 'reports', label: 'Reports', icon: FileSpreadsheet }
      ]
    },
    {
      group: 'SYSTEM',
      items: [
        { id: 'settings', label: 'Settings & Health', icon: Settings }
      ]
    }
  ];

  const handleNavClick = (pageId) => {
    setActivePage(pageId);
    if (mobileOpen) {
      setMobileOpen(false);
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div className="mobile-backdrop" onClick={() => setMobileOpen(false)} />
      )}

      <aside className={`app-sidebar ${collapsed ? 'collapsed' : ''} ${mobileOpen ? 'mobile-open' : ''}`}>
        {/* Brand Header */}
        <div className="sidebar-brand">
          <div className="brand-logo-icon">
            <Boxes size={22} />
          </div>
          {!collapsed && (
            <div className="brand-text">
              <span className="brand-title">SmartStock</span>
              <span className="brand-tagline">Intelligent Inventory</span>
            </div>
          )}
          {mobileOpen && (
            <button className="mobile-close-btn" onClick={() => setMobileOpen(false)}>
              <X size={20} />
            </button>
          )}
        </div>

        {/* Navigation Items */}
        <nav className="sidebar-nav">
          {navSections.map((section, sIdx) => (
            <div key={sIdx} className="nav-group">
              {!collapsed && <div className="nav-group-title">{section.group}</div>}
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    className={`nav-btn ${isActive ? 'active' : ''} ${item.highlight ? 'nav-highlight' : ''}`}
                    onClick={() => handleNavClick(item.id)}
                    title={collapsed ? item.label : undefined}
                  >
                    <span className="nav-icon"><Icon size={19} /></span>
                    {!collapsed && <span className="nav-label">{item.label}</span>}
                    {!collapsed && item.badge && (
                      <span className={`nav-badge ${item.badgeClass || ''}`}>{item.badge}</span>
                    )}
                    {collapsed && item.badge && (
                      <span className="nav-dot-badge" />
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Bottom Status & Profile */}
        <div className="sidebar-footer">
          {/* Live MySQL Database Status Card */}
          <div className="db-status-pill" title="Connected to local MySQL Server">
            <span className="db-indicator-dot" />
            {!collapsed && (
              <div className="db-status-info">
                <span className="db-title">MySQL 8.x Connected</span>
                <span className="db-sub">Database: smartstock</span>
              </div>
            )}
          </div>

          {/* User Profile */}
          <div className="user-profile-row">
            <div className="user-avatar">
              <span>AG</span>
            </div>
            {!collapsed && (
              <div className="user-meta">
                <span className="user-name">Administrator</span>
                <span className="user-role">Inventory Manager</span>
              </div>
            )}
          </div>

          {/* Collapse/Expand Toggle (Desktop only) */}
          <button
            className="collapse-toggle-btn"
            onClick={() => setCollapsed(!collapsed)}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
            {!collapsed && <span>Collapse Sidebar</span>}
          </button>
        </div>
      </aside>
    </>
  );
}
