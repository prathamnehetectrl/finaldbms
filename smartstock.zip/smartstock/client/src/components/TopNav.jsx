import React, { useState, useRef, useEffect } from 'react';
import {
  Menu,
  Search,
  Bell,
  RefreshCw,
  Plus,
  Package,
  AlertTriangle,
  User,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  X
} from 'lucide-react';

export default function TopNav({
  activePage,
  setActivePage,
  onRefresh,
  loading,
  onOpenNewSale,
  onOpenAddProduct,
  setMobileOpen,
  lowStockItems = [],
  allProducts = [],
  allCustomers = [],
  allSuppliers = []
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const searchRef = useRef(null);
  const notifRef = useRef(null);

  // Close dropdowns on click outside
  useEffect(() => {
    function handleClickOutside(e) {
      if (searchRef.current && !searchRef.current.contains(e.target)) {
        setSearchOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter global search results across products, customers, suppliers
  const matchedProducts = searchQuery.trim()
    ? allProducts.filter(p => `${p.product_name} ${p.sku}`.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 4)
    : [];
  const matchedCustomers = searchQuery.trim()
    ? allCustomers.filter(c => `${c.customer_name} ${c.phone || ''}`.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 3)
    : [];
  const matchedSuppliers = searchQuery.trim()
    ? allSuppliers.filter(s => `${s.supplier_name}`.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 3)
    : [];

  const hasSearchResults = matchedProducts.length > 0 || matchedCustomers.length > 0 || matchedSuppliers.length > 0;

  const pageTitles = {
    dashboard: 'Dashboard',
    inventory: 'Inventory Management',
    categories: 'Product Categories',
    suppliers: 'Suppliers Directory',
    customers: 'Customer Accounts',
    purchases: 'Purchase Orders',
    sales: 'Point of Sale (POS)',
    payments: 'Payment Transactions',
    movements: 'Stock Movements Log',
    bi: 'Business Intelligence',
    reports: 'Financial & Operational Reports',
    settings: 'System Health & Settings'
  };

  return (
    <header className="app-topnav">
      {/* Left: Mobile Toggle & Breadcrumbs */}
      <div className="topnav-left">
        <button
          className="mobile-menu-trigger"
          onClick={() => setMobileOpen(true)}
          aria-label="Open navigation menu"
        >
          <Menu size={20} />
        </button>

        <div className="breadcrumb-trail">
          <span className="crumb-root">SmartStock</span>
          <ChevronRight size={14} className="crumb-sep" />
          <span className="crumb-active">{pageTitles[activePage] || 'Overview'}</span>
        </div>
      </div>

      {/* Center: Global Search */}
      <div className="topnav-center" ref={searchRef}>
        <div className="global-search-box">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            placeholder="Search products, SKU, suppliers, customers... (Ctrl + K)"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setSearchOpen(true);
            }}
            onFocus={() => setSearchOpen(true)}
          />
          {searchQuery && (
            <button className="search-clear-btn" onClick={() => setSearchQuery('')}>
              <X size={14} />
            </button>
          )}
        </div>

        {/* Global Search Results Dropdown */}
        {searchOpen && searchQuery.trim() && (
          <div className="search-results-dropdown">
            {!hasSearchResults ? (
              <div className="search-no-results">No records found matching "{searchQuery}"</div>
            ) : (
              <>
                {matchedProducts.length > 0 && (
                  <div className="search-group">
                    <div className="search-group-title">Products ({matchedProducts.length})</div>
                    {matchedProducts.map((p) => (
                      <div
                        key={p.product_id}
                        className="search-result-item"
                        onClick={() => {
                          setActivePage('inventory');
                          setSearchOpen(false);
                          setSearchQuery('');
                        }}
                      >
                        <div className="item-icon-box"><Package size={15} /></div>
                        <div className="item-info">
                          <span className="item-primary">{p.product_name}</span>
                          <span className="item-secondary">SKU: {p.sku} · Stock: {p.stock_quantity}</span>
                        </div>
                        <span className="item-meta">₹{Number(p.selling_price).toLocaleString('en-IN')}</span>
                      </div>
                    ))}
                  </div>
                )}

                {matchedCustomers.length > 0 && (
                  <div className="search-group">
                    <div className="search-group-title">Customers ({matchedCustomers.length})</div>
                    {matchedCustomers.map((c) => (
                      <div
                        key={c.customer_id}
                        className="search-result-item"
                        onClick={() => {
                          setActivePage('customers');
                          setSearchOpen(false);
                          setSearchQuery('');
                        }}
                      >
                        <div className="item-icon-box"><User size={15} /></div>
                        <div className="item-info">
                          <span className="item-primary">{c.customer_name}</span>
                          <span className="item-secondary">{c.phone || c.email || 'Customer'}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>

      {/* Right: Actions, Notifications & Profile */}
      <div className="topnav-right">
        {/* Quick Action Button: New Sale */}
        <button
          className="btn btn-primary btn-sm quick-action-btn"
          onClick={() => {
            if (onOpenNewSale) onOpenNewSale();
            else setActivePage('sales');
          }}
        >
          <TrendingUp size={15} />
          <span>New Sale (POS)</span>
        </button>

        {/* Refresh Action */}
        <button
          className="icon-action-btn"
          onClick={onRefresh}
          disabled={loading}
          title="Refresh Data from MySQL"
        >
          <RefreshCw size={17} className={loading ? 'spin' : ''} />
        </button>

        {/* Notifications Dropdown */}
        <div className="notif-wrapper" ref={notifRef}>
          <button
            className="icon-action-btn notif-btn"
            onClick={() => setNotifOpen(!notifOpen)}
            title="Stock Alerts"
          >
            <Bell size={18} />
            {lowStockItems.length > 0 && (
              <span className="notif-badge">{lowStockItems.length}</span>
            )}
          </button>

          {notifOpen && (
            <div className="notif-dropdown">
              <div className="notif-header">
                <div>
                  <strong>Inventory Alerts</strong>
                  <span className="notif-count-label">{lowStockItems.length} active warnings</span>
                </div>
              </div>
              <div className="notif-body">
                {lowStockItems.length === 0 ? (
                  <div className="notif-empty">All stock levels are currently healthy!</div>
                ) : (
                  lowStockItems.map((item) => (
                    <div
                      key={item.product_id}
                      className="notif-alert-row"
                      onClick={() => {
                        setActivePage('inventory');
                        setNotifOpen(false);
                      }}
                    >
                      <div className="notif-alert-icon"><AlertTriangle size={16} /></div>
                      <div className="notif-alert-details">
                        <span className="alert-product">{item.product_name}</span>
                        <span className="alert-stock">
                          Stock: <strong>{item.stock_quantity} units</strong> (Threshold: {item.reorder_level})
                        </span>
                      </div>
                      <span className="alert-action-badge">Reorder</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User Avatar */}
        <div className="admin-chip" onClick={() => setActivePage('settings')} title="View Settings & DB Health">
          <div className="chip-avatar">DB</div>
          <span className="chip-name">MySQL Admin</span>
        </div>
      </div>
    </header>
  );
}
