import React from 'react';
import {
  Sparkles,
  TrendingUp,
  AlertTriangle,
  Award,
  Layers,
  ArrowRight,
  ShieldAlert,
  Zap,
  Info,
  CheckCircle2,
  Package,
  Phone
} from 'lucide-react';
import { formatCurrency } from '../api/client';

export default function BIPage({
  biData = {},
  loading,
  setActivePage,
  onRefresh
}) {
  const {
    bestSelling = [],
    topCategories = [],
    mostProfitable = [],
    lowStockRecommendations = [],
    slowMoving = [],
    supplierAnalysis = [],
    customerPatterns = [],
    insights = []
  } = biData;

  return (
    <div className="page-container bi-page">
      {/* Header */}
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">
            <Sparkles size={14} className="sparkle-icon" /> QUANTITATIVE DECISION INTELLIGENCE
          </div>
          <h1 className="page-title">Business Intelligence & Insights</h1>
          <p className="page-subtitle">
            Turn inventory, margin, and transactional data into actionable commercial recommendations.
          </p>
        </div>
      </div>

      {/* Actionable Insights Cards */}
      <div className="mb-6">
        <div className="section-label-chip mb-3">ACTIONABLE STRATEGIC INSIGHTS</div>
        <div className="insights-grid">
          {insights.length === 0 ? (
            <div className="card p-4 text-muted">Calculating real-time analytics from database...</div>
          ) : (
            insights.map((ins, idx) => {
              let IconComponent = Sparkles;
              let cardClass = 'insight-info';

              if (ins.type === 'critical') {
                IconComponent = ShieldAlert;
                cardClass = 'insight-critical';
              } else if (ins.type === 'warning') {
                IconComponent = AlertTriangle;
                cardClass = 'insight-warning';
              } else if (ins.type === 'success') {
                IconComponent = Zap;
                cardClass = 'insight-success';
              }

              return (
                <div key={idx} className={`card insight-card ${cardClass}`}>
                  <div className="insight-top">
                    <div className="insight-icon"><IconComponent size={19} /></div>
                    <span className="insight-tag">{ins.title}</span>
                    <span className="insight-metric">{ins.metric}</span>
                  </div>
                  <p className="insight-text">{ins.explanation}</p>
                  <div className="insight-action-box">
                    <strong>Recommended Action:</strong> {ins.action}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Grid: Most Profitable Products & Slow Moving Inventory */}
      <div className="dashboard-charts-grid two-column mb-6">
        {/* Most Profitable Products */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">High-Margin Products</h3>
              <p className="card-subtitle">Products ranked by gross profit margin percentage</p>
            </div>
            <Award size={18} className="text-purple" />
          </div>
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>PRODUCT</th>
                    <th className="text-right">UNIT MARGIN</th>
                    <th className="text-right">MARGIN %</th>
                    <th className="text-right">TOTAL PROFIT</th>
                  </tr>
                </thead>
                <tbody>
                  {mostProfitable.length === 0 ? (
                    <tr><td colSpan="4" className="empty-cell">No profit data available</td></tr>
                  ) : (
                    mostProfitable.map((p) => (
                      <tr key={p.product_id}>
                        <td>
                          <strong>{p.product_name}</strong>
                          <span className="sub-sku">{p.sku}</span>
                        </td>
                        <td className="text-right">{formatCurrency(p.unit_margin)}</td>
                        <td className="text-right">
                          <span className="badge badge-success">{p.margin_percentage}%</span>
                        </td>
                        <td className="text-right font-bold text-emerald">
                          {formatCurrency(p.total_profit_generated)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Slow-Moving / Capital Locked Inventory */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Slow-Moving Inventory Analysis</h3>
              <p className="card-subtitle">Working capital locked in slow-turnover warehouse items</p>
            </div>
            <AlertTriangle size={18} className="text-amber" />
          </div>
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>PRODUCT</th>
                    <th className="text-right">UNITS HELD</th>
                    <th className="text-right">CAPITAL TIED</th>
                    <th className="text-right">UNITS SOLD</th>
                  </tr>
                </thead>
                <tbody>
                  {slowMoving.length === 0 ? (
                    <tr><td colSpan="4" className="empty-cell">Inventory velocity is balanced</td></tr>
                  ) : (
                    slowMoving.map((p) => (
                      <tr key={p.product_id}>
                        <td>
                          <strong>{p.product_name}</strong>
                          <span className="sub-sku">{p.sku}</span>
                        </td>
                        <td className="text-right">{p.stock_quantity} units</td>
                        <td className="text-right font-bold text-primary">
                          {formatCurrency(p.tied_capital)}
                        </td>
                        <td className="text-right text-muted">{p.units_sold} sold</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Low Stock Replenishment Priority & Top Customer Lifetime Value */}
      <div className="dashboard-charts-grid two-column">
        {/* Low Stock Replenishment Priority */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Vendor Reorder Recommendations</h3>
              <p className="card-subtitle">Automated reorder quantities calculated from safety stock</p>
            </div>
            <button className="btn btn-secondary btn-sm" onClick={() => setActivePage('purchases')}>
              Create Purchase Order <ArrowRight size={14} />
            </button>
          </div>
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>PRODUCT</th>
                    <th>VENDOR</th>
                    <th className="text-right">CURRENT</th>
                    <th className="text-right">REORDER QTY</th>
                    <th className="text-right">EST. COST</th>
                  </tr>
                </thead>
                <tbody>
                  {lowStockRecommendations.length === 0 ? (
                    <tr><td colSpan="5" className="empty-cell text-emerald">✓ All products have safe inventory margins</td></tr>
                  ) : (
                    lowStockRecommendations.map((r) => (
                      <tr key={r.product_id}>
                        <td><strong>{r.product_name}</strong></td>
                        <td>
                          <span>{r.supplier_name}</span>
                          {r.supplier_phone && <span className="text-xs text-muted block">{r.supplier_phone}</span>}
                        </td>
                        <td className="text-right text-danger font-bold">{r.stock_quantity}</td>
                        <td className="text-right font-bold">+{r.recommended_reorder_qty} units</td>
                        <td className="text-right font-bold text-primary">{formatCurrency(r.estimated_cost)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Customer Purchasing Patterns */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Top Client Accounts by Lifetime Spend</h3>
              <p className="card-subtitle">Key enterprise and recurring retail accounts</p>
            </div>
            <button className="btn btn-secondary btn-sm" onClick={() => setActivePage('customers')}>
              View Accounts <ArrowRight size={14} />
            </button>
          </div>
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>CUSTOMER</th>
                    <th className="text-right">ORDERS</th>
                    <th className="text-right">AVG ORDER</th>
                    <th className="text-right">LIFETIME SPEND</th>
                  </tr>
                </thead>
                <tbody>
                  {customerPatterns.length === 0 ? (
                    <tr><td colSpan="4" className="empty-cell">No customer order patterns detected</td></tr>
                  ) : (
                    customerPatterns.map((c, i) => (
                      <tr key={i}>
                        <td><strong>{c.customer_name}</strong></td>
                        <td className="text-right">{c.orders_count} orders</td>
                        <td className="text-right text-muted">{formatCurrency(c.average_order_value)}</td>
                        <td className="text-right font-bold text-emerald">{formatCurrency(c.total_spent)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
