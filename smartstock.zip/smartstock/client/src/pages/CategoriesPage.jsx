import React, { useState } from 'react';
import { Layers, Plus, Edit2, Trash2, Package, Search } from 'lucide-react';
import Modal from '../components/Modal.jsx';
import { formatCurrency } from '../api/client';

export default function CategoriesPage({
  categories = [],
  loading,
  onAddCategory,
  onUpdateCategory,
  onDeleteCategory,
  onRefresh,
  showToast
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editCategory, setEditCategory] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');

  const openAdd = () => {
    setName('');
    setDesc('');
    setIsAddOpen(true);
  };

  const openEdit = (cat) => {
    setEditCategory(cat);
    setName(cat.category_name);
    setDesc(cat.description || '');
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Category name is required', 'error');
      return;
    }
    setSubmitting(true);
    try {
      if (editCategory) {
        await onUpdateCategory(editCategory.category_id, { category_name: name, description: desc });
        showToast('Category updated successfully', 'success');
        setEditCategory(null);
      } else {
        await onAddCategory({ category_name: name, description: desc });
        showToast('New category created', 'success');
        setIsAddOpen(false);
      }
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSubmitting(true);
    try {
      await onDeleteCategory(deleteTarget.category_id);
      showToast(`Category "${deleteTarget.category_name}" deleted`, 'success');
      setDeleteTarget(null);
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = categories.filter(c =>
    `${c.category_name} ${c.description || ''}`.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="page-container">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">CATALOG CLASSIFICATION</div>
          <h1 className="page-title">Product Categories</h1>
          <p className="page-subtitle">
            Organize inventory items into strategic commercial categories and product lines.
          </p>
        </div>

        <div className="page-header-actions">
          <button className="btn btn-primary" onClick={openAdd}>
            <Plus size={16} /> Add Category
          </button>
        </div>
      </div>

      {/* Search Toolbar */}
      <div className="card table-filter-toolbar">
        <div className="toolbar-search">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            placeholder="Search categories..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="text-sm text-muted">
          Showing <strong>{filtered.length}</strong> categories
        </div>
      </div>

      {/* Category Grid */}
      <div className="grid-cards three-column">
        {filtered.map((cat) => (
          <div key={cat.category_id} className="card entity-card">
            <div className="entity-header">
              <div className="entity-avatar-box"><Layers size={20} /></div>
              <div className="entity-title-box">
                <h4>{cat.category_name}</h4>
                <span className="entity-badge">{cat.product_count || 0} products</span>
              </div>
            </div>

            <p className="entity-desc">{cat.description || 'No description provided.'}</p>

            <div className="entity-stats-row">
              <div className="stat-chunk">
                <span className="sc-label">Stock Units</span>
                <span className="sc-val">{cat.total_units || 0}</span>
              </div>
              <div className="stat-chunk">
                <span className="sc-label">Valuation</span>
                <span className="sc-val text-primary">{formatCurrency(cat.total_value)}</span>
              </div>
            </div>

            <div className="entity-footer-actions">
              <button className="btn btn-secondary btn-sm" onClick={() => openEdit(cat)}>
                <Edit2 size={13} /> Edit
              </button>
              <button className="btn btn-secondary btn-sm text-danger" onClick={() => setDeleteTarget(cat)}>
                <Trash2 size={13} /> Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Category Modal */}
      <Modal
        isOpen={isAddOpen || !!editCategory}
        onClose={() => {
          setIsAddOpen(false);
          setEditCategory(null);
        }}
        title={editCategory ? `Edit Category: ${editCategory.category_name}` : 'Create New Category'}
      >
        <form onSubmit={handleSave} className="modal-form">
          <div className="form-field">
            <label className="form-label">Category Name *</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Storage Devices"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div className="form-field">
            <label className="form-label">Description</label>
            <textarea
              className="form-textarea"
              rows={3}
              placeholder="Brief description of products in this category..."
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
            />
          </div>

          <div className="modal-actions-right">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                setIsAddOpen(false);
                setEditCategory(null);
              }}
            >
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Saving...' : editCategory ? 'Save Changes' : 'Create Category'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      {deleteTarget && (
        <Modal
          isOpen={!!deleteTarget}
          onClose={() => setDeleteTarget(null)}
          title="Confirm Category Deletion"
          maxWidth="440px"
        >
          <div className="confirmation-box">
            <p>Are you sure you want to delete category <strong>"{deleteTarget.category_name}"</strong>?</p>
            <p className="text-sm text-muted mt-2">
              The category cannot be deleted if active products are assigned to it.
            </p>
            <div className="modal-actions-right mt-6">
              <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
              <button className="btn btn-danger" onClick={handleDelete} disabled={submitting}>
                {submitting ? 'Deleting...' : 'Delete Category'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
