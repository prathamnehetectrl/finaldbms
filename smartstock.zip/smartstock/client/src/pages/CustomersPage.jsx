import React, { useState } from 'react';
import { Users, Plus, Edit2, Trash2, Phone, Mail, MapPin, ShoppingCart, Search } from 'lucide-react';
import Modal from '../components/Modal.jsx';
import { formatCurrency } from '../api/client';

export default function CustomersPage({
  customers = [],
  loading,
  onAddCustomer,
  onUpdateCustomer,
  onDeleteCustomer,
  onRefresh,
  showToast
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editCustomer, setEditCustomer] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    customer_name: '',
    phone: '',
    email: '',
    address: ''
  });

  const openAdd = () => {
    setFormData({ customer_name: '', phone: '', email: '', address: '' });
    setIsAddOpen(true);
  };

  const openEdit = (c) => {
    setEditCustomer(c);
    setFormData({
      customer_name: c.customer_name,
      phone: c.phone || '',
      email: c.email || '',
      address: c.address || ''
    });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.customer_name.trim()) {
      showToast('Customer name is required', 'error');
      return;
    }

    setSubmitting(true);
    try {
      if (editCustomer) {
        await onUpdateCustomer(editCustomer.customer_id, formData);
        showToast('Customer updated successfully', 'success');
        setEditCustomer(null);
      } else {
        await onAddCustomer(formData);
        showToast('Customer registered successfully', 'success');
        setIsAddOpen(false);
      }
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSubmitting(true);
    try {
      await onDeleteCustomer(deleteTarget.customer_id);
      showToast(`Customer "${deleteTarget.customer_name}" deleted`, 'success');
      setDeleteTarget(null);
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = customers.filter(c =>
    `${c.customer_name} ${c.phone || ''} ${c.email || ''} ${c.address || ''}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  return (
    <div className="page-container">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">CLIENT RELATIONSHIP MANAGEMENT</div>
          <h1 className="page-title">Customer Accounts</h1>
          <p className="page-subtitle">
            Track customer contact details, lifetime spend, and repeat purchase frequency.
          </p>
        </div>

        <div className="page-header-actions">
          <button className="btn btn-primary" onClick={openAdd}>
            <Plus size={16} /> Add Customer
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="card table-filter-toolbar">
        <div className="toolbar-search">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            placeholder="Search customers by name, phone, email, or city..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="text-sm text-muted">
          Showing <strong>{filtered.length}</strong> customer accounts
        </div>
      </div>

      {/* Customer Grid */}
      <div className="grid-cards three-column">
        {filtered.map((c) => (
          <div key={c.customer_id} className="card entity-card">
            <div className="entity-header">
              <div className="entity-avatar-box customer-avatar-box"><Users size={20} /></div>
              <div className="entity-title-box">
                <h4>{c.customer_name}</h4>
                <span className="entity-badge">{c.total_orders || 0} completed orders</span>
              </div>
            </div>

            <div className="entity-contact-list">
              {c.phone && (
                <div className="contact-item">
                  <Phone size={14} /> <span>{c.phone}</span>
                </div>
              )}
              {c.email && (
                <div className="contact-item">
                  <Mail size={14} /> <span>{c.email}</span>
                </div>
              )}
              {c.address && (
                <div className="contact-item">
                  <MapPin size={14} /> <span>{c.address}</span>
                </div>
              )}
            </div>

            <div className="entity-stats-row">
              <div className="stat-chunk">
                <span className="sc-label">Orders Placed</span>
                <span className="sc-val">{c.total_orders || 0}</span>
              </div>
              <div className="stat-chunk">
                <span className="sc-label">Lifetime Value</span>
                <span className="sc-val text-emerald font-bold">{formatCurrency(c.total_spent)}</span>
              </div>
            </div>

            <div className="entity-footer-actions">
              <button className="btn btn-secondary btn-sm" onClick={() => openEdit(c)}>
                <Edit2 size={13} /> Edit
              </button>
              <button className="btn btn-secondary btn-sm text-danger" onClick={() => setDeleteTarget(c)}>
                <Trash2 size={13} /> Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      <Modal
        isOpen={isAddOpen || !!editCustomer}
        onClose={() => {
          setIsAddOpen(false);
          setEditCustomer(null);
        }}
        title={editCustomer ? `Edit Customer: ${editCustomer.customer_name}` : 'Register New Customer'}
      >
        <form onSubmit={handleSave} className="modal-form">
          <div className="form-field">
            <label className="form-label">Full Name / Company *</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Rahul Sharma"
              value={formData.customer_name}
              onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
              required
            />
          </div>

          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Phone Number</label>
              <input
                type="text"
                className="form-input"
                placeholder="+91 90000 00001"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>

            <div className="form-field">
              <label className="form-label">Email Address</label>
              <input
                type="email"
                className="form-input"
                placeholder="customer@example.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
          </div>

          <div className="form-field">
            <label className="form-label">Delivery / Billing Address</label>
            <input
              type="text"
              className="form-input"
              placeholder="City, State"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            />
          </div>

          <div className="modal-actions-right">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                setIsAddOpen(false);
                setEditCustomer(null);
              }}
            >
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Saving...' : editCustomer ? 'Update Customer' : 'Save Customer'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      {deleteTarget && (
        <Modal
          isOpen={!!deleteTarget}
          onClose={() => setDeleteTarget(null)}
          title="Confirm Customer Deletion"
          maxWidth="440px"
        >
          <div className="confirmation-box">
            <p>Delete customer <strong>"{deleteTarget.customer_name}"</strong>?</p>
            <p className="text-sm text-muted mt-2">
              Customers with prior sales orders cannot be deleted to protect historical sales records.
            </p>
            <div className="modal-actions-right mt-6">
              <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
              <button className="btn btn-danger" onClick={handleDelete} disabled={submitting}>
                {submitting ? 'Deleting...' : 'Delete Customer'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
