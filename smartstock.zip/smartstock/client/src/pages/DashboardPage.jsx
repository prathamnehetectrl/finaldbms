import React, { useState } from 'react';
import {
  Package,
  Boxes,
  CircleDollarSign,
  TrendingUp,
  Award,
  AlertTriangle,
  Clock,
  Users,
  ArrowRight,
  ExternalLink,
  Layers,
  Sparkles,
  RefreshCw,
  Calendar
} from 'lucide-react';
import { AreaTrendChart, RevenueVsProfitChart, DonutChart, HorizontalBarChart } from '../components/Charts.jsx';
import { formatCurrency, formatDate } from '../api/client';

export default function DashboardPage({
  dashboardData,
  loading,
  onRefresh,
  setActivePage,
  onOpenNewSale
}) {
  const [dateRange, setDateRange] = useState('all');

  const summary = dashboardData?.summary || {};
  const charts = dashboardData?.charts || {};
  const recentSales = dashboardData?.recentSales || [];
  const lowStockAlerts = dashboardData?.lowStockAlerts || [];

  return (
    <div className="page-container dashboard-page">
      {/* Page Header */}
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">
            <Sparkles size={14} className="sparkle-icon" /> COMMERCIAL BUSINESS OVERVIEW
          </div>
          <h1 className="page-title">Executive Dashboard</h1>
          <p className="page-subtitle">
            Real-time inventory levels, financial valuation, and sales velocity powered by MySQL.
          </p>
        </div>

        <div className="page-header-actions">
          <div className="date-select-pill">
            <Calendar size={15} />
            <select value={dateRange} onChange={(e) => setDateRange(e.target.value)}>
              <option value="all">All Time History</option>
              <option value="month">Current Month</option>
              <option value="quarter">This Quarter</option>
              <option value="year">Fiscal Year 2026</option>
            </select>
          </div>

          <button className="btn btn-secondary" onClick={onRefresh} disabled={loading}>
            <RefreshCw size={15} className={loading ? 'spin' : ''} />
            <span>Refresh</span>
          </button>

          <button className="btn btn-primary" onClick={onOpenNewSale}>
            <TrendingUp size={15} />
            <span>New Sale (POS)</span>
          </button>
        </div>
      </div>

      {/* 8 Summary KPI Metric Cards */}
      <div className="kpi-grid">
        {/* 1. Total Products */}
        <div className="kpi-card" onClick={() => setActivePage('inventory')} role="button" tabIndex={0}>
          <div className="kpi-top">
            <span className="kpi-label">Total Products</span>
            <div className="kpi-icon-box icon-blue"><Package size={18} /></div>
          </div>
          <div className="kpi-val">{loading ? '—' : summary.totalProducts}</div>
          <div className="kpi-sub">
            <span className="kpi-trend text-neutral">Active catalogue items</span>
          </div>
        </div>

        {/* 2. Total Inventory Units */}
        <div className="kpi-card" onClick={() => setActivePage('inventory')} role="button" tabIndex={0}>
          <div className="kpi-top">
            <span className="kpi-label">Total Inventory Units</span>
            <div className="kpi-icon-box icon-indigo"><Boxes size={18} /></div>
          </div>
          <div className="kpi-val">{loading ? '—' : (summary.totalUnits || 0).toLocaleString('en-IN')}</div>
          <div className="kpi-sub">
            <span className="kpi-trend text-neutral">Physical stock in warehouse</span>
          </div>
        </div>

        {/* 3. Inventory Cost Value */}
        <div className="kpi-card" onClick={() => setActivePage('inventory')} role="button" tabIndex={0}>
          <div className="kpi-top">
            <span className="kpi-label">Inventory Valuation</span>
            <div className="kpi-icon-box icon-cyan"><CircleDollarSign size={18} /></div>
          </div>
          <div className="kpi-val text-primary">{loading ? '—' : formatCurrency(summary.inventoryCostValue)}</div>
          <div className="kpi-sub">
            <span className="kpi-trend text-neutral">Based on purchase cost price</span>
          </div>
        </div>

        {/* 4. Total Sales Revenue */}
        <div className="kpi-card" onClick={() => setActivePage('sales')} role="button" tabIndex={0}>
          <div className="kpi-top">
            <span className="kpi-label">Total Sales Revenue</span>
            <div className="kpi-icon-box icon-emerald"><TrendingUp size={18} /></div>
          </div>
          <div className="kpi-val text-emerald">{loading ? '—' : formatCurrency(summary.totalSalesRevenue)}</div>
          <div className="kpi-sub">
            <span className="kpi-trend text-emerald">From {summary.completedSalesCount || 0} completed orders</span>
          </div>
        </div>

        {/* 5. Gross Profit */}
        <div className="kpi-card" onClick={() => setActivePage('reports')} role="button" tabIndex={0}>
          <div className="kpi-top">
            <span className="kpi-label">Gross Realized Profit</span>
            <div className="kpi-icon-box icon-purple"><Award size={18} /></div>
          </div>
          <div className="kpi-val text-purple">{loading ? '—' : formatCurrency(summary.grossProfit)}</div>
          <div className="kpi-sub">
            <span className="kpi-trend text-purple">Selling price minus item cost</span>
          </div>
        </div>

        {/* 6. Low-Stock Products */}
        <div
          className={`kpi-card ${summary.lowStockProducts > 0 ? 'kpi-card-warning' : ''}`}
          onClick={() => setActivePage('inventory')}
          role="button"
          tabIndex={0}
        >
          <div className="kpi-top">
            <span className="kpi-label">Low Stock Alerts</span>
            <div className="kpi-icon-box icon-amber"><AlertTriangle size={18} /></div>
          </div>
          <div className="kpi-val text-amber">{loading ? '—' : summary.lowStockProducts}</div>
          <div className="kpi-sub">
            <span className="kpi-trend text-amber">
              {summary.lowStockProducts > 0 ? 'Urgent reordering needed' : 'All stock levels optimal'}
            </span>
          </div>
        </div>

        {/* 7. Pending Purchases */}
        <div className="kpi-card" onClick={() => setActivePage('purchases')} role="button" tabIndex={0}>
          <div className="kpi-top">
            <span className="kpi-label">Pending Purchases</span>
            <div className="kpi-icon-box icon-orange"><Clock size={18} /></div>
          </div>
          <div className="kpi-val text-orange">{loading ? '—' : summary.pendingPurchases}</div>
          <div className="kpi-sub">
            <span className="kpi-trend text-neutral">{formatCurrency(summary.pendingPurchasesAmount)} awaiting intake</span>
          </div>
        </div>

        {/* 8. Total Customers */}
        <div className="kpi-card" onClick={() => setActivePage('customers')} role="button" tabIndex={0}>
          <div className="kpi-top">
            <span className="kpi-label">Registered Customers</span>
            <div className="kpi-icon-box icon-slate"><Users size={18} /></div>
          </div>
          <div className="kpi-val">{loading ? '—' : summary.totalCustomers}</div>
          <div className="kpi-sub">
            <span className="kpi-trend text-neutral">Customer client accounts</span>
          </div>
        </div>
      </div>

      {/* Row 1 Charts: Sales Revenue Trend (Area) & Donut (Sales by Category) */}
      <div className="dashboard-charts-grid two-column">
        <div className="card chart-card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Sales Revenue Velocity</h3>
              <p className="card-subtitle">Monthly completed sales revenue track from MySQL transaction history</p>
            </div>
            <span className="badge badge-primary">Monthly</span>
          </div>
          <div className="card-body">
            <AreaTrendChart data={charts.monthlyRevenue} height={230} />
          </div>
        </div>

        <div className="card chart-card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Sales by Category</h3>
              <p className="card-subtitle">Proportional revenue contribution across product segments</p>
            </div>
            <button className="link-action-btn" onClick={() => setActivePage('categories')}>
              View Categories <ArrowRight size={14} />
            </button>
          </div>
          <div className="card-body">
            <DonutChart data={charts.salesByCategory} />
          </div>
        </div>
      </div>

      {/* Row 2 Charts: Revenue vs Gross Profit & Inventory Distribution */}
      <div className="dashboard-charts-grid two-column">
        <div className="card chart-card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Revenue vs. Gross Profit</h3>
              <p className="card-subtitle">Net sales performance against cost of goods sold</p>
            </div>
          </div>
          <div className="card-body">
            <RevenueVsProfitChart data={charts.revenueVsProfit} height={230} />
          </div>
        </div>

        <div className="card chart-card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Inventory Stock Distribution</h3>
              <p className="card-subtitle">Units and valuation currently stored by category</p>
            </div>
          </div>
          <div className="card-body">
            <HorizontalBarChart data={charts.inventoryByCategory} labelKey="category_name" valueKey="total_units" />
          </div>
        </div>
      </div>

      {/* Row 3: Top-Selling Products & Critical Stock Alerts */}
      <div className="dashboard-charts-grid two-column">
        {/* Top-Selling Products */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Top-Selling Products</h3>
              <p className="card-subtitle">Highest volume inventory items ranked by sales count</p>
            </div>
            <button className="link-action-btn" onClick={() => setActivePage('bi')}>
              Full Analysis <ArrowRight size={14} />
            </button>
          </div>
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>RANK</th>
                    <th>PRODUCT</th>
                    <th>SKU</th>
                    <th className="text-right">UNITS SOLD</th>
                    <th className="text-right">REVENUE</th>
                  </tr>
                </thead>
                <tbody>
                  {(charts.topProducts || []).length === 0 ? (
                    <tr><td colSpan="5" className="empty-cell">No sales records found</td></tr>
                  ) : (
                    charts.topProducts.map((p, idx) => (
                      <tr key={p.product_id}>
                        <td>
                          <span className={`rank-badge rank-${idx + 1}`}>#{idx + 1}</span>
                        </td>
                        <td>
                          <strong>{p.product_name}</strong>
                        </td>
                        <td><span className="sku-tag">{p.sku}</span></td>
                        <td className="text-right"><strong>{p.units_sold}</strong> units</td>
                        <td className="text-right text-primary"><strong>{formatCurrency(p.total_revenue)}</strong></td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Critical Stock Alerts */}
        <div className="card">
          <div className="card-header">
            <div>
              <h3 className="card-title">Stock Replenishment Alerts</h3>
              <p className="card-subtitle">Items at or below safe threshold ({summary.lowStockProducts} alerts)</p>
            </div>
            <button className="link-action-btn" onClick={() => setActivePage('purchases')}>
              Create PO <ArrowRight size={14} />
            </button>
          </div>
          <div className="card-body p-0">
            <div className="table-responsive">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>PRODUCT</th>
                    <th>CATEGORY</th>
                    <th className="text-right">STOCK</th>
                    <th className="text-right">REORDER</th>
                    <th>STATUS</th>
                  </tr>
                </thead>
                <tbody>
                  {lowStockAlerts.length === 0 ? (
                    <tr>
                      <td colSpan="5" className="empty-cell text-emerald">
                        ✓ All products currently have healthy inventory levels!
                      </td>
                    </tr>
                  ) : (
                    lowStockAlerts.map((item) => {
                      const isCritical = item.stock_quantity <= Math.ceil(item.reorder_level / 2);
                      return (
                        <tr key={item.product_id}>
                          <td>
                            <div className="product-cell-inline">
                              <strong>{item.product_name}</strong>
                              <span className="sub-sku">{item.sku}</span>
                            </div>
                          </td>
                          <td><span className="category-tag">{item.category_name}</span></td>
                          <td className="text-right">
                            <strong className={isCritical ? 'text-danger' : 'text-amber'}>
                              {item.stock_quantity}
                            </strong>
                          </td>
                          <td className="text-right text-muted">{item.reorder_level}</td>
                          <td>
                            <span className={`status-pill ${isCritical ? 'status-cancelled' : 'status-pending'}`}>
                              {isCritical ? 'Critical' : 'Low Stock'}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Row 4: Recent Sales Orders Table */}
      <div className="card mt-6">
        <div className="card-header">
          <div>
            <h3 className="card-title">Recent Customer Orders</h3>
            <p className="card-subtitle">Live stream of point-of-sale and invoice transactions</p>
          </div>
          <button className="btn btn-secondary btn-sm" onClick={() => setActivePage('sales')}>
            View All Sales <ArrowRight size={14} />
          </button>
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>ORDER #</th>
                  <th>CUSTOMER</th>
                  <th>DATE & TIME</th>
                  <th>STATUS</th>
                  <th className="text-right">TOTAL AMOUNT</th>
                  <th className="text-center">ACTION</th>
                </tr>
              </thead>
              <tbody>
                {recentSales.length === 0 ? (
                  <tr><td colSpan="6" className="empty-cell">No sales recorded yet</td></tr>
                ) : (
                  recentSales.map((sale) => (
                    <tr key={sale.sale_id}>
                      <td><strong>SO-#{String(sale.sale_id).padStart(4, '0')}</strong></td>
                      <td>{sale.customer_name}</td>
                      <td>{formatDate(sale.sale_date)}</td>
                      <td>
                        <span className={`status-pill status-${sale.status.toLowerCase()}`}>
                          {sale.status}
                        </span>
                      </td>
                      <td className="text-right"><strong>{formatCurrency(sale.total_amount)}</strong></td>
                      <td className="text-center">
                        <button
                          className="btn-icon-subtle"
                          title="View order"
                          onClick={() => setActivePage('sales')}
                        >
                          <ExternalLink size={15} />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
