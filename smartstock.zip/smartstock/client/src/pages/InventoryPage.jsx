import React, { useState, useMemo } from 'react';
import {
  Package,
  Plus,
  Download,
  Search,
  Filter,
  ArrowUpDown,
  Edit2,
  Trash2,
  Eye,
  AlertTriangle,
  Boxes,
  CircleDollarSign,
  CheckCircle2,
  XCircle,
  Truck
} from 'lucide-react';
import Modal from '../components/Modal.jsx';
import { formatCurrency, formatDate } from '../api/client';

export default function InventoryPage({
  products = [],
  categories = [],
  suppliers = [],
  loading,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onRefresh,
  showToast
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('name-asc');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  // Modal states
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [viewProduct, setViewProduct] = useState(null);
  const [deleteProductTarget, setDeleteProductTarget] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    sku: '',
    product_name: '',
    category_id: '',
    supplier_id: '',
    cost_price: '',
    selling_price: '',
    stock_quantity: '',
    reorder_level: '5'
  });

  const resetForm = () => {
    setFormData({
      sku: '',
      product_name: '',
      category_id: categories[0]?.category_id || '',
      supplier_id: suppliers[0]?.supplier_id || '',
      cost_price: '',
      selling_price: '',
      stock_quantity: '0',
      reorder_level: '5'
    });
  };

  const openAddModal = () => {
    resetForm();
    setIsAddOpen(true);
  };

  const openEditModal = (p) => {
    setEditProduct(p);
    setFormData({
      sku: p.sku,
      product_name: p.product_name,
      category_id: p.category_id,
      supplier_id: p.supplier_id,
      cost_price: p.cost_price,
      selling_price: p.selling_price,
      stock_quantity: p.stock_quantity,
      reorder_level: p.reorder_level
    });
  };

  const handleSaveProduct = async (e) => {
    e.preventDefault();
    if (!formData.sku || !formData.product_name || !formData.category_id || !formData.supplier_id) {
      showToast('Please complete all required fields', 'error');
      return;
    }

    if (Number(formData.cost_price) < 0 || Number(formData.selling_price) < 0) {
      showToast('Prices must be non-negative', 'error');
      return;
    }

    setSubmitting(true);
    try {
      if (editProduct) {
        await onUpdateProduct(editProduct.product_id, formData);
        showToast('Product updated successfully', 'success');
        setEditProduct(null);
      } else {
        await onAddProduct(formData);
        showToast('Product added to MySQL inventory', 'success');
        setIsAddOpen(false);
      }
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteProductTarget) return;
    setSubmitting(true);
    try {
      await onDeleteProduct(deleteProductTarget.product_id);
      showToast(`Product "${deleteProductTarget.product_name}" removed`, 'success');
      setDeleteProductTarget(null);
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    if (!products.length) return;
    const headers = ['Product ID', 'SKU', 'Product Name', 'Category', 'Supplier', 'Cost Price', 'Selling Price', 'Available Stock', 'Reorder Level', 'Inventory Value'];
    const rows = products.map(p => [
      p.product_id,
      `"${p.sku}"`,
      `"${p.product_name}"`,
      `"${p.category_name}"`,
      `"${p.supplier_name}"`,
      p.cost_price,
      p.selling_price,
      p.stock_quantity,
      p.reorder_level,
      (Number(p.stock_quantity) * Number(p.cost_price)).toFixed(2)
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `smartstock_inventory_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Inventory report exported as CSV', 'success');
  };

  // Filter & Sort
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchSearch = `${p.product_name} ${p.sku} ${p.category_name} ${p.supplier_name}`
        .toLowerCase()
        .includes(searchTerm.toLowerCase());

      const matchCategory = categoryFilter === 'all' || String(p.category_id) === String(categoryFilter);

      let matchStatus = true;
      const stock = Number(p.stock_quantity);
      const reorder = Number(p.reorder_level);
      if (statusFilter === 'out') matchStatus = stock === 0;
      else if (statusFilter === 'low') matchStatus = stock > 0 && stock <= reorder;
      else if (statusFilter === 'instock') matchStatus = stock > reorder;

      return matchSearch && matchCategory && matchStatus;
    }).sort((a, b) => {
      if (sortBy === 'name-asc') return a.product_name.localeCompare(b.product_name);
      if (sortBy === 'name-desc') return b.product_name.localeCompare(a.product_name);
      if (sortBy === 'stock-asc') return a.stock_quantity - b.stock_quantity;
      if (sortBy === 'stock-desc') return b.stock_quantity - a.stock_quantity;
      if (sortBy === 'price-desc') return b.selling_price - a.selling_price;
      if (sortBy === 'price-asc') return a.selling_price - b.selling_price;
      return 0;
    });
  }, [products, searchTerm, categoryFilter, statusFilter, sortBy]);

  // Statistics
  const totalUnits = products.reduce((sum, p) => sum + Number(p.stock_quantity), 0);
  const totalValue = products.reduce((sum, p) => sum + Number(p.stock_quantity) * Number(p.cost_price), 0);
  const inStockCount = products.filter(p => Number(p.stock_quantity) > Number(p.reorder_level)).length;
  const lowStockCount = products.filter(p => Number(p.stock_quantity) > 0 && Number(p.stock_quantity) <= Number(p.reorder_level)).length;
  const outOfStockCount = products.filter(p => Number(p.stock_quantity) === 0).length;

  // Pagination
  const totalPages = Math.ceil(filteredProducts.length / pageSize) || 1;
  const paginatedProducts = filteredProducts.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  return (
    <div className="page-container inventory-page">
      {/* Header */}
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">CATALOGUE & STOCK MANAGEMENT</div>
          <h1 className="page-title">Inventory Master</h1>
          <p className="page-subtitle">
            Manage products, stock levels, reorder thresholds, and inventory cost valuation.
          </p>
        </div>

        <div className="page-header-actions">
          <button className="btn btn-secondary" onClick={handleExportCSV}>
            <Download size={15} />
            <span>Export CSV</span>
          </button>
          <button className="btn btn-primary" onClick={openAddModal}>
            <Plus size={16} />
            <span>Add New Product</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="kpi-grid">
        <div className="kpi-card">
          <div className="kpi-top">
            <span className="kpi-label">Total SKUs</span>
            <div className="kpi-icon-box icon-blue"><Package size={17} /></div>
          </div>
          <div className="kpi-val">{products.length}</div>
          <div className="kpi-sub">Total catalogue items</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-top">
            <span className="kpi-label">Healthy In-Stock</span>
            <div className="kpi-icon-box icon-emerald"><CheckCircle2 size={17} /></div>
          </div>
          <div className="kpi-val text-emerald">{inStockCount}</div>
          <div className="kpi-sub">Above reorder threshold</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-top">
            <span className="kpi-label">Low Stock Warnings</span>
            <div className="kpi-icon-box icon-amber"><AlertTriangle size={17} /></div>
          </div>
          <div className="kpi-val text-amber">{lowStockCount}</div>
          <div className="kpi-sub">Needs replenishment</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-top">
            <span className="kpi-label">Out of Stock</span>
            <div className="kpi-icon-box icon-red"><XCircle size={17} /></div>
          </div>
          <div className="kpi-val text-danger">{outOfStockCount}</div>
          <div className="kpi-sub">Zero available units</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-top">
            <span className="kpi-label">Total Valuation</span>
            <div className="kpi-icon-box icon-cyan"><CircleDollarSign size={17} /></div>
          </div>
          <div className="kpi-val text-primary">{formatCurrency(totalValue)}</div>
          <div className="kpi-sub">{totalUnits.toLocaleString('en-IN')} units total</div>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="card table-filter-toolbar">
        <div className="toolbar-search">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            placeholder="Search by product name, SKU, or supplier..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
          />
        </div>

        <div className="toolbar-filters">
          <div className="select-wrapper">
            <select
              value={categoryFilter}
              onChange={(e) => {
                setCategoryFilter(e.target.value);
                setCurrentPage(1);
              }}
            >
              <option value="all">All Categories</option>
              {categories.map((c) => (
                <option key={c.category_id} value={c.category_id}>
                  {c.category_name}
                </option>
              ))}
            </select>
          </div>

          <div className="select-wrapper">
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setCurrentPage(1);
              }}
            >
              <option value="all">All Stock Statuses</option>
              <option value="instock">In Stock</option>
              <option value="low">Low Stock</option>
              <option value="out">Out of Stock</option>
            </select>
          </div>

          <div className="select-wrapper">
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
              <option value="name-asc">Sort: Name (A-Z)</option>
              <option value="name-desc">Sort: Name (Z-A)</option>
              <option value="stock-asc">Sort: Stock (Low to High)</option>
              <option value="stock-desc">Sort: Stock (High to Low)</option>
              <option value="price-desc">Sort: Price (High to Low)</option>
              <option value="price-asc">Sort: Price (Low to High)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Products Table Card */}
      <div className="card table-card">
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th>PRODUCT</th>
                <th>SKU</th>
                <th>CATEGORY</th>
                <th>SUPPLIER</th>
                <th className="text-right">COST PRICE</th>
                <th className="text-right">SELLING PRICE</th>
                <th className="text-right">STOCK</th>
                <th>STATUS</th>
                <th className="text-center">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="9" className="empty-cell">Loading products from MySQL...</td></tr>
              ) : paginatedProducts.length === 0 ? (
                <tr>
                  <td colSpan="9" className="empty-cell">
                    No products matched your search or filters.
                  </td>
                </tr>
              ) : (
                paginatedProducts.map((p) => {
                  const stock = Number(p.stock_quantity);
                  const reorder = Number(p.reorder_level);
                  const isOut = stock === 0;
                  const isLow = stock > 0 && stock <= reorder;

                  return (
                    <tr key={p.product_id} className={isLow ? 'row-warning' : isOut ? 'row-danger' : ''}>
                      <td>
                        <div className="product-identity-cell">
                          <div className="product-avatar-box">
                            <Package size={17} />
                          </div>
                          <div>
                            <strong className="product-name-link" onClick={() => setViewProduct(p)}>
                              {p.product_name}
                            </strong>
                            <span className="product-margin-text">
                              Margin: {formatCurrency(p.selling_price - p.cost_price)}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td><span className="sku-tag">{p.sku}</span></td>
                      <td><span className="category-tag">{p.category_name}</span></td>
                      <td><span className="supplier-text">{p.supplier_name}</span></td>
                      <td className="text-right text-muted">{formatCurrency(p.cost_price)}</td>
                      <td className="text-right"><strong>{formatCurrency(p.selling_price)}</strong></td>
                      <td className="text-right">
                        <strong className={isOut ? 'text-danger' : isLow ? 'text-amber' : 'text-neutral'}>
                          {stock}
                        </strong>
                        <span className="text-xs text-muted block">Reorder: {reorder}</span>
                      </td>
                      <td>
                        {isOut ? (
                          <span className="status-pill status-cancelled">Out of Stock</span>
                        ) : isLow ? (
                          <span className="status-pill status-pending">Low Stock</span>
                        ) : (
                          <span className="status-pill status-completed">In Stock</span>
                        )}
                      </td>
                      <td>
                        <div className="action-buttons-group">
                          <button
                            className="btn-icon-subtle"
                            title="View details"
                            onClick={() => setViewProduct(p)}
                          >
                            <Eye size={15} />
                          </button>
                          <button
                            className="btn-icon-subtle"
                            title="Edit product"
                            onClick={() => openEditModal(p)}
                          >
                            <Edit2 size={15} />
                          </button>
                          <button
                            className="btn-icon-subtle text-danger"
                            title="Delete product"
                            onClick={() => setDeleteProductTarget(p)}
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer with Pagination */}
        <div className="table-pagination-footer">
          <span className="pagination-count-label">
            Showing {(currentPage - 1) * pageSize + 1} to{' '}
            {Math.min(currentPage * pageSize, filteredProducts.length)} of {filteredProducts.length} products
          </span>

          <div className="pagination-controls">
            <button
              className="btn btn-secondary btn-sm"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            >
              Previous
            </button>
            <span className="page-indicator">
              Page {currentPage} of {totalPages}
            </span>
            <button
              className="btn btn-secondary btn-sm"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* Add / Edit Product Modal */}
      <Modal
        isOpen={isAddOpen || !!editProduct}
        onClose={() => {
          setIsAddOpen(false);
          setEditProduct(null);
        }}
        title={editProduct ? `Edit Product: ${editProduct.product_name}` : 'Add New Inventory Product'}
        maxWidth="600px"
      >
        <form onSubmit={handleSaveProduct} className="modal-form">
          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Product Name *</label>
              <input
                type="text"
                className="form-input"
                placeholder="e.g. Wireless Ergonomic Mouse"
                value={formData.product_name}
                onChange={(e) => setFormData({ ...formData, product_name: e.target.value })}
                required
              />
            </div>

            <div className="form-field">
              <label className="form-label">SKU (Stock Keeping Unit) *</label>
              <input
                type="text"
                className="form-input"
                placeholder="e.g. SS-MOU-009"
                value={formData.sku}
                onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Category *</label>
              <select
                className="form-select"
                value={formData.category_id}
                onChange={(e) => setFormData({ ...formData, category_id: e.target.value })}
                required
              >
                <option value="">Select Category</option>
                {categories.map((c) => (
                  <option key={c.category_id} value={c.category_id}>
                    {c.category_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-field">
              <label className="form-label">Primary Supplier *</label>
              <select
                className="form-select"
                value={formData.supplier_id}
                onChange={(e) => setFormData({ ...formData, supplier_id: e.target.value })}
                required
              >
                <option value="">Select Supplier</option>
                {suppliers.map((s) => (
                  <option key={s.supplier_id} value={s.supplier_id}>
                    {s.supplier_name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Cost Price (₹) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-input"
                placeholder="0.00"
                value={formData.cost_price}
                onChange={(e) => setFormData({ ...formData, cost_price: e.target.value })}
                required
              />
            </div>

            <div className="form-field">
              <label className="form-label">Selling Price (₹) *</label>
              <input
                type="number"
                step="0.01"
                min="0"
                className="form-input"
                placeholder="0.00"
                value={formData.selling_price}
                onChange={(e) => setFormData({ ...formData, selling_price: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Available Stock Quantity</label>
              <input
                type="number"
                min="0"
                className="form-input"
                placeholder="0"
                value={formData.stock_quantity}
                onChange={(e) => setFormData({ ...formData, stock_quantity: e.target.value })}
              />
            </div>

            <div className="form-field">
              <label className="form-label">Reorder Level Threshold</label>
              <input
                type="number"
                min="1"
                className="form-input"
                placeholder="5"
                value={formData.reorder_level}
                onChange={(e) => setFormData({ ...formData, reorder_level: e.target.value })}
              />
            </div>
          </div>

          <div className="modal-actions-right">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                setIsAddOpen(false);
                setEditProduct(null);
              }}
            >
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Saving to MySQL...' : editProduct ? 'Update Product' : 'Add to Inventory'}
            </button>
          </div>
        </form>
      </Modal>

      {/* View Product Details Drawer / Modal */}
      {viewProduct && (
        <Modal
          isOpen={!!viewProduct}
          onClose={() => setViewProduct(null)}
          title={`Product Dossier: ${viewProduct.product_name}`}
          maxWidth="520px"
        >
          <div className="detail-dossier">
            <div className="dossier-header-row">
              <div className="dossier-avatar"><Package size={28} /></div>
              <div>
                <h4>{viewProduct.product_name}</h4>
                <span className="sku-tag">{viewProduct.sku}</span>
              </div>
            </div>

            <div className="dossier-grid">
              <div className="dossier-item">
                <span className="d-label">Category</span>
                <span className="d-val">{viewProduct.category_name}</span>
              </div>
              <div className="dossier-item">
                <span className="d-label">Supplier</span>
                <span className="d-val">{viewProduct.supplier_name}</span>
              </div>
              <div className="dossier-item">
                <span className="d-label">Cost Price</span>
                <span className="d-val">{formatCurrency(viewProduct.cost_price)}</span>
              </div>
              <div className="dossier-item">
                <span className="d-label">Selling Price</span>
                <span className="d-val text-primary font-bold">{formatCurrency(viewProduct.selling_price)}</span>
              </div>
              <div className="dossier-item">
                <span className="d-label">Stock Quantity</span>
                <span className="d-val font-bold">{viewProduct.stock_quantity} units</span>
              </div>
              <div className="dossier-item">
                <span className="d-label">Reorder Level</span>
                <span className="d-val">{viewProduct.reorder_level} units</span>
              </div>
              <div className="dossier-item">
                <span className="d-label">Inventory Valuation</span>
                <span className="d-val text-emerald font-bold">
                  {formatCurrency(Number(viewProduct.stock_quantity) * Number(viewProduct.cost_price))}
                </span>
              </div>
              <div className="dossier-item">
                <span className="d-label">Unit Profit Margin</span>
                <span className="d-val text-purple font-bold">
                  {formatCurrency(viewProduct.selling_price - viewProduct.cost_price)} (
                  {(((viewProduct.selling_price - viewProduct.cost_price) / viewProduct.selling_price) * 100).toFixed(1)}%)
                </span>
              </div>
            </div>

            <div className="modal-actions-right mt-4">
              <button
                className="btn btn-secondary"
                onClick={() => {
                  const p = viewProduct;
                  setViewProduct(null);
                  openEditModal(p);
                }}
              >
                <Edit2 size={15} /> Edit Product
              </button>
              <button className="btn btn-primary" onClick={() => setViewProduct(null)}>
                Done
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Delete Confirmation Modal */}
      {deleteProductTarget && (
        <Modal
          isOpen={!!deleteProductTarget}
          onClose={() => setDeleteProductTarget(null)}
          title="Confirm Product Deletion"
          maxWidth="460px"
        >
          <div className="confirmation-box">
            <div className="warning-icon-box"><AlertTriangle size={32} /></div>
            <p>
              Are you sure you want to delete <strong>"{deleteProductTarget.product_name}"</strong> ({deleteProductTarget.sku})?
            </p>
            <p className="text-muted text-sm">
              If this product has associated sales or purchase orders, the MySQL relational database will prevent deletion to preserve audit history.
            </p>

            <div className="modal-actions-right mt-6">
              <button className="btn btn-secondary" onClick={() => setDeleteProductTarget(null)} disabled={submitting}>
                Cancel
              </button>
              <button className="btn btn-danger" onClick={handleDelete} disabled={submitting}>
                {submitting ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
