import React, { useState } from 'react';
import { ArrowLeftRight, Plus, Search, Calendar, Filter, ArrowUp, ArrowDown } from 'lucide-react';
import Modal from '../components/Modal.jsx';
import { formatDate } from '../api/client';

export default function MovementsPage({
  movements = [],
  products = [],
  loading,
  onAddMovement,
  onRefresh,
  showToast
}) {
  const [productFilter, setProductFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    product_id: '',
    movement_type: 'Adjustment',
    quantity_change: '',
    notes: ''
  });

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.product_id || !formData.quantity_change) {
      showToast('Please select product and enter quantity change', 'error');
      return;
    }

    if (Number(formData.quantity_change) === 0) {
      showToast('Quantity change cannot be 0', 'error');
      return;
    }

    setSubmitting(true);
    try {
      await onAddMovement(formData);
      showToast('Stock adjustment logged & warehouse balance updated in MySQL', 'success');
      setIsAddOpen(false);
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = movements.filter(m => {
    const matchProd = productFilter === 'all' || String(m.product_id) === String(productFilter);
    const matchType = typeFilter === 'all' || m.movement_type === typeFilter;
    return matchProd && matchType;
  });

  return (
    <div className="page-container">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">AUDIT TRAIL & WAREHOUSE DISCREPANCY LOG</div>
          <h1 className="page-title">Stock Movements</h1>
          <p className="page-subtitle">
            Complete cryptographic audit trail of all inventory receipts, sales deductions, and physical count reconciliations.
          </p>
        </div>

        <div className="page-header-actions">
          <button className="btn btn-primary" onClick={() => setIsAddOpen(true)}>
            <Plus size={16} /> Record Stock Adjustment
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="card table-filter-toolbar">
        <div className="toolbar-filters flex-1">
          <div className="select-wrapper">
            <select value={productFilter} onChange={(e) => setProductFilter(e.target.value)}>
              <option value="all">All Inventory Products</option>
              {products.map((p) => (
                <option key={p.product_id} value={p.product_id}>
                  {p.product_name} ({p.sku})
                </option>
              ))}
            </select>
          </div>

          <div className="select-wrapper">
            <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
              <option value="all">All Movement Types</option>
              <option value="Opening">Opening</option>
              <option value="Purchase">Purchase (Intake)</option>
              <option value="Sale">Sale (Dispatch)</option>
              <option value="Adjustment">Adjustment (Count Reconciliation)</option>
              <option value="Return">Customer Return</option>
            </select>
          </div>
        </div>

        <div className="text-sm text-muted">
          Total Recorded Events: <strong>{filtered.length}</strong>
        </div>
      </div>

      {/* Table */}
      <div className="card table-card">
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th>EVENT ID</th>
                <th>DATE & TIME</th>
                <th>PRODUCT</th>
                <th>SKU</th>
                <th>CATEGORY</th>
                <th>TYPE</th>
                <th className="text-right">QUANTITY DELTA</th>
                <th>AUDIT NOTES</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan="8" className="empty-cell">No stock movements recorded</td></tr>
              ) : (
                filtered.map((m) => {
                  const isPositive = Number(m.quantity_change) > 0;
                  return (
                    <tr key={m.movement_id}>
                      <td><strong>MOV-#{String(m.movement_id).padStart(4, '0')}</strong></td>
                      <td>{formatDate(m.movement_date)}</td>
                      <td><strong>{m.product_name}</strong></td>
                      <td><span className="sku-tag">{m.sku}</span></td>
                      <td><span className="category-tag">{m.category_name}</span></td>
                      <td>
                        <span className={`movement-type-tag type-${m.movement_type.toLowerCase()}`}>
                          {m.movement_type}
                        </span>
                      </td>
                      <td className={`text-right font-bold ${isPositive ? 'text-emerald' : 'text-danger'}`}>
                        {isPositive ? `+${m.quantity_change}` : m.quantity_change} units
                      </td>
                      <td className="text-sm text-muted">{m.notes || '—'}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Adjustment Modal */}
      <Modal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        title="Record Stock Adjustment / Physical Count"
        maxWidth="500px"
      >
        <form onSubmit={handleSave} className="modal-form">
          <div className="form-field">
            <label className="form-label">Product *</label>
            <select
              className="form-select"
              value={formData.product_id}
              onChange={(e) => setFormData({ ...formData, product_id: e.target.value })}
              required
            >
              <option value="">Select product to adjust</option>
              {products.map((p) => (
                <option key={p.product_id} value={p.product_id}>
                  {p.product_name} ({p.sku}) · Current Stock: {p.stock_quantity}
                </option>
              ))}
            </select>
          </div>

          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Adjustment Type *</label>
              <select
                className="form-select"
                value={formData.movement_type}
                onChange={(e) => setFormData({ ...formData, movement_type: e.target.value })}
              >
                <option value="Adjustment">Adjustment (Audit Count)</option>
                <option value="Return">Customer Return</option>
                <option value="Opening">Opening Balance</option>
              </select>
            </div>

            <div className="form-field">
              <label className="form-label">Quantity Change (+ or -) *</label>
              <input
                type="number"
                className="form-input"
                placeholder="e.g. +5 or -2"
                value={formData.quantity_change}
                onChange={(e) => setFormData({ ...formData, quantity_change: e.target.value })}
                required
              />
              <span className="text-xs text-muted mt-1 block">Positive adds stock, negative deducts</span>
            </div>
          </div>

          <div className="form-field">
            <label className="form-label">Reason / Auditor Notes</label>
            <textarea
              className="form-textarea"
              rows={2}
              placeholder="e.g. Broken unit discovered during physical inventory check"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            />
          </div>

          <div className="modal-actions-right">
            <button type="button" className="btn btn-secondary" onClick={() => setIsAddOpen(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Applying in MySQL...' : 'Commit Adjustment'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
