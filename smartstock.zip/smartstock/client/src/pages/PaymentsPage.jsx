import React, { useState } from 'react';
import { CreditCard, Plus, Search, Filter, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import Modal from '../components/Modal.jsx';
import { formatCurrency, formatDate } from '../api/client';

export default function PaymentsPage({
  payments = [],
  loading,
  onAddPayment,
  onRefresh,
  showToast
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [methodFilter, setMethodFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    targetType: 'sale',
    sale_id: '',
    purchase_id: '',
    amount: '',
    payment_method: 'UPI'
  });

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.amount || Number(formData.amount) <= 0) {
      showToast('Please enter a valid payment amount > 0', 'error');
      return;
    }

    if (formData.targetType === 'sale' && !formData.sale_id) {
      showToast('Please enter an associated Sales Order ID', 'error');
      return;
    }

    if (formData.targetType === 'purchase' && !formData.purchase_id) {
      showToast('Please enter an associated Purchase Order ID', 'error');
      return;
    }

    setSubmitting(true);
    try {
      await onAddPayment({
        sale_id: formData.targetType === 'sale' ? formData.sale_id : null,
        purchase_id: formData.targetType === 'purchase' ? formData.purchase_id : null,
        amount: formData.amount,
        payment_method: formData.payment_method
      });
      showToast('Payment recorded in MySQL transaction log', 'success');
      setIsAddOpen(false);
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = payments.filter(p => {
    const matchSearch = `${p.party_name} #${p.payment_id} #${p.sale_id || ''} #${p.purchase_id || ''}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase());

    const matchMethod = methodFilter === 'all' || p.payment_method === methodFilter;
    const matchType = typeFilter === 'all' ||
      (typeFilter === 'sale' && p.sale_id) ||
      (typeFilter === 'purchase' && p.purchase_id);

    return matchSearch && matchMethod && matchType;
  });

  const totalInflow = payments.filter(p => p.sale_id).reduce((s, p) => s + Number(p.amount), 0);
  const totalOutflow = payments.filter(p => p.purchase_id).reduce((s, p) => s + Number(p.amount), 0);

  return (
    <div className="page-container">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">FINANCIAL LEDGER & CASHFLOW</div>
          <h1 className="page-title">Payment Transactions</h1>
          <p className="page-subtitle">
            Audit customer payment receipts and vendor procurement disbursements recorded in MySQL.
          </p>
        </div>

        <div className="page-header-actions">
          <button className="btn btn-primary" onClick={() => setIsAddOpen(true)}>
            <Plus size={16} /> Record Payment
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid two-column mb-6">
        <div className="kpi-card">
          <div className="kpi-top">
            <span className="kpi-label">Customer Cash Inflow</span>
            <div className="kpi-icon-box icon-emerald"><ArrowDownLeft size={18} /></div>
          </div>
          <div className="kpi-val text-emerald">{formatCurrency(totalInflow)}</div>
          <div className="kpi-sub">Total payments collected from customer sales</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-top">
            <span className="kpi-label">Vendor Disbursements</span>
            <div className="kpi-icon-box icon-purple"><ArrowUpRight size={18} /></div>
          </div>
          <div className="kpi-val text-purple">{formatCurrency(totalOutflow)}</div>
          <div className="kpi-sub">Total procurement payments paid to suppliers</div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="card table-filter-toolbar">
        <div className="toolbar-search">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            placeholder="Search payments by party, ID, or order ref..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="toolbar-filters">
          <div className="select-wrapper">
            <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)}>
              <option value="all">All Types</option>
              <option value="sale">Customer Sales (Inflow)</option>
              <option value="purchase">Supplier Purchases (Outflow)</option>
            </select>
          </div>

          <div className="select-wrapper">
            <select value={methodFilter} onChange={(e) => setMethodFilter(e.target.value)}>
              <option value="all">All Payment Methods</option>
              <option value="UPI">UPI</option>
              <option value="Card">Card</option>
              <option value="Cash">Cash</option>
              <option value="Bank Transfer">Bank Transfer</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="card table-card">
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th>PAYMENT ID</th>
                <th>DATE & TIME</th>
                <th>FLOW TYPE</th>
                <th>ASSOCIATED ORDER</th>
                <th>PARTY</th>
                <th>METHOD</th>
                <th className="text-right">AMOUNT</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan="7" className="empty-cell">No payment records found</td></tr>
              ) : (
                filtered.map((p) => {
                  const isInflow = !!p.sale_id;
                  return (
                    <tr key={p.payment_id}>
                      <td><strong>PAY-#{String(p.payment_id).padStart(4, '0')}</strong></td>
                      <td>{formatDate(p.payment_date)}</td>
                      <td>
                        <span className={`status-pill ${isInflow ? 'status-completed' : 'status-pending'}`}>
                          {isInflow ? 'Inflow (Sale)' : 'Outflow (Purchase)'}
                        </span>
                      </td>
                      <td>
                        {p.sale_id ? (
                          <span className="sku-tag">Sale #SO-{p.sale_id}</span>
                        ) : p.purchase_id ? (
                          <span className="sku-tag">PO #PO-{p.purchase_id}</span>
                        ) : '—'}
                      </td>
                      <td><strong>{p.party_name}</strong></td>
                      <td><span className="method-pill">{p.payment_method}</span></td>
                      <td className={`text-right font-bold ${isInflow ? 'text-emerald' : 'text-purple'}`}>
                        {isInflow ? '+' : '-'}{formatCurrency(p.amount)}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Payment Modal */}
      <Modal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        title="Record Financial Transaction"
      >
        <form onSubmit={handleSave} className="modal-form">
          <div className="form-field">
            <label className="form-label">Transaction Flow *</label>
            <select
              className="form-select"
              value={formData.targetType}
              onChange={(e) => setFormData({ ...formData, targetType: e.target.value })}
            >
              <option value="sale">Customer Sale Receipt (Inflow)</option>
              <option value="purchase">Supplier Purchase Payment (Outflow)</option>
            </select>
          </div>

          {formData.targetType === 'sale' ? (
            <div className="form-field">
              <label className="form-label">Sales Order ID (Sale ID) *</label>
              <input
                type="number"
                min="1"
                className="form-input"
                placeholder="e.g. 1"
                value={formData.sale_id}
                onChange={(e) => setFormData({ ...formData, sale_id: e.target.value })}
                required
              />
            </div>
          ) : (
            <div className="form-field">
              <label className="form-label">Purchase Order ID (Purchase ID) *</label>
              <input
                type="number"
                min="1"
                className="form-input"
                placeholder="e.g. 1"
                value={formData.purchase_id}
                onChange={(e) => setFormData({ ...formData, purchase_id: e.target.value })}
                required
              />
            </div>
          )}

          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Amount (₹) *</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                className="form-input"
                placeholder="0.00"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                required
              />
            </div>

            <div className="form-field">
              <label className="form-label">Payment Method *</label>
              <select
                className="form-select"
                value={formData.payment_method}
                onChange={(e) => setFormData({ ...formData, payment_method: e.target.value })}
              >
                <option value="UPI">UPI</option>
                <option value="Card">Card</option>
                <option value="Cash">Cash</option>
                <option value="Bank Transfer">Bank Transfer</option>
              </select>
            </div>
          </div>

          <div className="modal-actions-right">
            <button type="button" className="btn btn-secondary" onClick={() => setIsAddOpen(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Recording...' : 'Record Payment'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
