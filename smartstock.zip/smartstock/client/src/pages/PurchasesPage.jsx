import React, { useState } from 'react';
import { ShoppingCart, Plus, CheckCircle, XCircle, Eye, Search, Calendar, Trash, Package } from 'lucide-react';
import Modal from '../components/Modal.jsx';
import { formatCurrency, formatDate } from '../api/client';

export default function PurchasesPage({
  purchases = [],
  suppliers = [],
  products = [],
  loading,
  onCreatePurchase,
  onUpdateStatus,
  onRefresh,
  showToast
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [viewPO, setViewPO] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // New PO Form
  const [selectedSupplier, setSelectedSupplier] = useState('');
  const [poStatus, setPoStatus] = useState('Received'); // default received or pending
  const [items, setItems] = useState([
    { product_id: '', quantity: 10, unit_cost: 0 }
  ]);

  const openNewPO = () => {
    setSelectedSupplier(suppliers[0]?.supplier_id || '');
    setPoStatus('Received');
    const firstProd = products[0];
    setItems([
      { product_id: firstProd?.product_id || '', quantity: 10, unit_cost: Number(firstProd?.cost_price) || 0 }
    ]);
    setIsAddOpen(true);
  };

  const handleProductChange = (index, prodId) => {
    const prod = products.find(p => String(p.product_id) === String(prodId));
    const newItems = [...items];
    newItems[index].product_id = prodId;
    if (prod) {
      newItems[index].unit_cost = Number(prod.cost_price) || 0;
    }
    setItems(newItems);
  };

  const handleItemChange = (index, field, value) => {
    const newItems = [...items];
    newItems[index][field] = value;
    setItems(newItems);
  };

  const addItemRow = () => {
    const firstProd = products[0];
    setItems([
      ...items,
      { product_id: firstProd?.product_id || '', quantity: 10, unit_cost: Number(firstProd?.cost_price) || 0 }
    ]);
  };

  const removeItemRow = (index) => {
    if (items.length <= 1) return;
    setItems(items.filter((_, i) => i !== index));
  };

  const orderTotal = items.reduce((sum, item) => sum + (Number(item.quantity) || 0) * (Number(item.unit_cost) || 0), 0);

  const handleSubmitPO = async (e) => {
    e.preventDefault();
    if (!selectedSupplier) {
      showToast('Please select a supplier', 'error');
      return;
    }

    for (const it of items) {
      if (!it.product_id || Number(it.quantity) <= 0 || Number(it.unit_cost) < 0) {
        showToast('All items must have a product, quantity > 0, and valid cost', 'error');
        return;
      }
    }

    setSubmitting(true);
    try {
      await onCreatePurchase({
        supplier_id: selectedSupplier,
        status: poStatus,
        items
      });
      showToast(poStatus === 'Received' ? 'Purchase Order recorded & inventory incremented in MySQL!' : 'Purchase Order saved as Pending', 'success');
      setIsAddOpen(false);
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleStatusChange = async (id, newStatus) => {
    try {
      await onUpdateStatus(id, newStatus);
      showToast(`Purchase Order #${id} marked as ${newStatus}`, 'success');
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  const filtered = purchases.filter(p => {
    const matchSearch = `${p.supplier_name} #${p.purchase_id}`.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'all' || p.status.toLowerCase() === statusFilter.toLowerCase();
    return matchSearch && matchStatus;
  });

  return (
    <div className="page-container">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">INVENTORY INTAKE & PROCUREMENT</div>
          <h1 className="page-title">Purchase Orders</h1>
          <p className="page-subtitle">
            Create vendor purchase orders and automatically update physical warehouse stock upon receipt.
          </p>
        </div>

        <div className="page-header-actions">
          <button className="btn btn-primary" onClick={openNewPO}>
            <Plus size={16} /> New Purchase Order
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="card table-filter-toolbar">
        <div className="toolbar-search">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            placeholder="Search by supplier or PO #..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="toolbar-filters">
          <div className="select-wrapper">
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
              <option value="all">All Statuses</option>
              <option value="received">Received</option>
              <option value="pending">Pending</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="card table-card">
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th>PO #</th>
                <th>SUPPLIER</th>
                <th>DATE</th>
                <th>ITEMS</th>
                <th>UNITS</th>
                <th className="text-right">TOTAL AMOUNT</th>
                <th>STATUS</th>
                <th className="text-center">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan="8" className="empty-cell">No purchase orders found</td></tr>
              ) : (
                filtered.map((po) => (
                  <tr key={po.purchase_id}>
                    <td><strong>PO-#{String(po.purchase_id).padStart(4, '0')}</strong></td>
                    <td><span className="font-semibold">{po.supplier_name}</span></td>
                    <td>{formatDate(po.purchase_date)}</td>
                    <td>{po.total_items} line items</td>
                    <td><strong>{po.total_quantity}</strong> units</td>
                    <td className="text-right"><strong>{formatCurrency(po.total_amount)}</strong></td>
                    <td>
                      <span className={`status-pill status-${po.status.toLowerCase()}`}>
                        {po.status}
                      </span>
                    </td>
                    <td>
                      <div className="action-buttons-group">
                        {po.status === 'Pending' && (
                          <button
                            className="btn btn-sm btn-success-subtle"
                            title="Receive goods into inventory"
                            onClick={() => handleStatusChange(po.purchase_id, 'Received')}
                          >
                            <CheckCircle size={14} /> Receive
                          </button>
                        )}
                        {po.status !== 'Cancelled' && (
                          <button
                            className="btn-icon-subtle text-danger"
                            title="Cancel Order"
                            onClick={() => handleStatusChange(po.purchase_id, 'Cancelled')}
                          >
                            <XCircle size={15} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Purchase Order Modal */}
      <Modal
        isOpen={isAddOpen}
        onClose={() => setIsAddOpen(false)}
        title="Create Purchase Order"
        maxWidth="720px"
      >
        <form onSubmit={handleSubmitPO} className="modal-form">
          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Select Vendor / Supplier *</label>
              <select
                className="form-select"
                value={selectedSupplier}
                onChange={(e) => setSelectedSupplier(e.target.value)}
                required
              >
                <option value="">Select a supplier</option>
                {suppliers.map((s) => (
                  <option key={s.supplier_id} value={s.supplier_id}>
                    {s.supplier_name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-field">
              <label className="form-label">Initial Order Status</label>
              <select
                className="form-select"
                value={poStatus}
                onChange={(e) => setPoStatus(e.target.value)}
              >
                <option value="Received">Received (Immediately adds stock to MySQL)</option>
                <option value="Pending">Pending (Awaiting delivery)</option>
              </select>
            </div>
          </div>

          <div className="form-section-title">Purchase Line Items</div>

          <div className="line-items-container">
            {items.map((item, idx) => (
              <div key={idx} className="line-item-row">
                <div className="form-field flex-2">
                  <label className="form-label text-xs">Product</label>
                  <select
                    className="form-select"
                    value={item.product_id}
                    onChange={(e) => handleProductChange(idx, e.target.value)}
                    required
                  >
                    <option value="">Select Product</option>
                    {products.map((p) => (
                      <option key={p.product_id} value={p.product_id}>
                        {p.product_name} ({p.sku}) · In Stock: {p.stock_quantity}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-field flex-1">
                  <label className="form-label text-xs">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    className="form-input"
                    value={item.quantity}
                    onChange={(e) => handleItemChange(idx, 'quantity', e.target.value)}
                    required
                  />
                </div>

                <div className="form-field flex-1">
                  <label className="form-label text-xs">Unit Cost (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    className="form-input"
                    value={item.unit_cost}
                    onChange={(e) => handleItemChange(idx, 'unit_cost', e.target.value)}
                    required
                  />
                </div>

                <div className="form-field flex-1 text-right">
                  <label className="form-label text-xs">Subtotal</label>
                  <div className="subtotal-display">
                    {formatCurrency((Number(item.quantity) || 0) * (Number(item.unit_cost) || 0))}
                  </div>
                </div>

                {items.length > 1 && (
                  <button
                    type="button"
                    className="btn-icon-subtle text-danger delete-item-btn"
                    onClick={() => removeItemRow(idx)}
                    title="Remove item"
                  >
                    <Trash size={16} />
                  </button>
                )}
              </div>
            ))}
          </div>

          <button type="button" className="btn btn-secondary btn-sm mt-2" onClick={addItemRow}>
            <Plus size={14} /> Add Another Item
          </button>

          <div className="order-total-banner">
            <span>Total Purchase Amount:</span>
            <strong className="text-primary text-xl">{formatCurrency(orderTotal)}</strong>
          </div>

          <div className="modal-actions-right mt-6">
            <button type="button" className="btn btn-secondary" onClick={() => setIsAddOpen(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Recording in MySQL...' : 'Confirm Purchase Order'}
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
