import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  Printer,
  Calendar,
  Filter,
  RefreshCw,
  TrendingUp,
  CircleDollarSign,
  Package,
  Truck,
  Users,
  CreditCard,
  ArrowLeftRight
} from 'lucide-react';
import { api, formatCurrency, formatDate } from '../api/client';

export default function ReportsPage({ showToast }) {
  const [selectedReport, setSelectedReport] = useState('sales');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reportData, setReportData] = useState({ rows: [], summary: {} });
  const [loading, setLoading] = useState(false);

  const reportTypes = [
    { id: 'sales', label: 'Sales Report', icon: TrendingUp },
    { id: 'profit', label: 'Gross Profit Report', icon: CircleDollarSign },
    { id: 'inventory', label: 'Inventory Valuation', icon: Package },
    { id: 'lowstock', label: 'Low Stock Shortages', icon: Filter },
    { id: 'purchases', label: 'Procurement Purchases', icon: Truck },
    { id: 'suppliers', label: 'Supplier Portfolio', icon: Truck },
    { id: 'customers', label: 'Customer Spend Ledger', icon: Users },
    { id: 'payments', label: 'Financial Payments', icon: CreditCard },
    { id: 'movements', label: 'Stock Movement Audit', icon: ArrowLeftRight }
  ];

  const fetchReport = async () => {
    setLoading(true);
    try {
      const params = {};
      if (startDate) params.start_date = startDate;
      if (endDate) params.end_date = endDate;
      const res = await api.getReport(selectedReport, params);
      setReportData(res);
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReport();
  }, [selectedReport]);

  const handleExportCSV = () => {
    if (!reportData.rows || reportData.rows.length === 0) {
      showToast('No data to export', 'warning');
      return;
    }
    const headers = Object.keys(reportData.rows[0]);
    const csvRows = reportData.rows.map(row =>
      headers.map(h => `"${String(row[h] || '').replace(/"/g, '""')}"`).join(',')
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...csvRows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `smartstock_${selectedReport}_report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast(`Exported ${selectedReport} report to CSV`, 'success');
  };

  const handlePrint = () => {
    window.print();
  };

  const rows = reportData.rows || [];
  const summary = reportData.summary || {};

  return (
    <div className="page-container reports-page">
      <div className="page-header no-print">
        <div className="page-header-content">
          <div className="page-eyebrow">ENTERPRISE AUDIT & EXPORT</div>
          <h1 className="page-title">Financial & Operational Reports</h1>
          <p className="page-subtitle">
            Generate parameterized business intelligence reports directly extracted from MySQL relational schema.
          </p>
        </div>

        <div className="page-header-actions">
          <button className="btn btn-secondary" onClick={handlePrint}>
            <Printer size={15} /> Print Report
          </button>
          <button className="btn btn-primary" onClick={handleExportCSV}>
            <Download size={15} /> Export as CSV
          </button>
        </div>
      </div>

      {/* Report Selector Tabs */}
      <div className="report-nav-tabs no-print">
        {reportTypes.map((rt) => {
          const Icon = rt.icon;
          const isActive = selectedReport === rt.id;
          return (
            <button
              key={rt.id}
              className={`report-tab-btn ${isActive ? 'active' : ''}`}
              onClick={() => setSelectedReport(rt.id)}
            >
              <Icon size={16} />
              <span>{rt.label}</span>
            </button>
          );
        })}
      </div>

      {/* Filter Parameters */}
      <div className="card table-filter-toolbar no-print">
        <div className="date-filter-inline">
          <Calendar size={16} className="text-muted" />
          <span className="text-sm font-semibold">Date Filter:</span>
          <input
            type="date"
            className="form-input form-input-sm"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
          />
          <span className="text-muted">to</span>
          <input
            type="date"
            className="form-input form-input-sm"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
          />
          <button className="btn btn-secondary btn-sm" onClick={fetchReport} disabled={loading}>
            <RefreshCw size={14} className={loading ? 'spin' : ''} /> Run Query
          </button>
        </div>

        <div className="text-sm text-muted">
          Extracted <strong>{rows.length}</strong> matching records from MySQL
        </div>
      </div>

      {/* Report Print Header (visible in print) */}
      <div className="print-report-header">
        <h2>SmartStock Systems · Operational Report</h2>
        <p>Report Type: {selectedReport.toUpperCase()} | Generated: {new Date().toLocaleString()}</p>
        <hr />
      </div>

      {/* Summary KPI Strip */}
      {Object.keys(summary).length > 0 && (
        <div className="report-summary-strip mb-4">
          {summary.totalRevenue !== undefined && (
            <div className="strip-item">
              <span className="s-label">Total Revenue</span>
              <span className="s-val text-primary">{formatCurrency(summary.totalRevenue)}</span>
            </div>
          )}
          {summary.totalProfit !== undefined && (
            <div className="strip-item">
              <span className="s-label">Gross Realized Profit</span>
              <span className="s-val text-emerald">{formatCurrency(summary.totalProfit)}</span>
            </div>
          )}
          {summary.overallMargin !== undefined && (
            <div className="strip-item">
              <span className="s-label">Blended Margin</span>
              <span className="s-val text-purple">{summary.overallMargin}%</span>
            </div>
          )}
          {summary.totalCost !== undefined && (
            <div className="strip-item">
              <span className="s-label">Inventory Cost Value</span>
              <span className="s-val text-primary">{formatCurrency(summary.totalCost)}</span>
            </div>
          )}
          {summary.totalUnits !== undefined && (
            <div className="strip-item">
              <span className="s-label">Total Stock Units</span>
              <span className="s-val">{summary.totalUnits.toLocaleString('en-IN')} units</span>
            </div>
          )}
          {summary.totalPurchases !== undefined && (
            <div className="strip-item">
              <span className="s-label">Total Procurement</span>
              <span className="s-val text-purple">{formatCurrency(summary.totalPurchases)}</span>
            </div>
          )}
        </div>
      )}

      {/* Data Table */}
      <div className="card table-card">
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              {rows.length > 0 ? (
                <tr>
                  {Object.keys(rows[0]).map((key) => (
                    <th key={key} className={key.includes('amount') || key.includes('price') || key.includes('cost') || key.includes('revenue') || key.includes('profit') ? 'text-right' : ''}>
                      {key.replace(/_/g, ' ').toUpperCase()}
                    </th>
                  ))}
                </tr>
              ) : (
                <tr><th>REPORT DATA</th></tr>
              )}
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="10" className="empty-cell">Running analytical MySQL query...</td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan="10" className="empty-cell">No matching data records for the selected parameters.</td></tr>
              ) : (
                rows.map((row, idx) => (
                  <tr key={idx}>
                    {Object.entries(row).map(([k, v], cIdx) => {
                      const isMoney = k.includes('amount') || k.includes('price') || k.includes('cost') || k.includes('revenue') || k.includes('profit') || k.includes('value');
                      const isDate = k.includes('date');
                      return (
                        <td key={cIdx} className={isMoney ? 'text-right font-medium' : ''}>
                          {isMoney ? formatCurrency(v) : isDate ? formatDate(v) : String(v !== null && v !== undefined ? v : '—')}
                        </td>
                      );
                    })}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
