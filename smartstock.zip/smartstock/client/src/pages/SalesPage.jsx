import React, { useState } from 'react';
import {
  TrendingUp,
  Plus,
  ShoppingCart,
  Printer,
  Trash,
  User,
  AlertCircle,
  CreditCard,
  Search,
  CheckCircle2,
  XCircle,
  Clock
} from 'lucide-react';
import Modal from '../components/Modal.jsx';
import InvoiceModal from '../components/InvoiceModal.jsx';
import { formatCurrency, formatDate } from '../api/client';

export default function SalesPage({
  sales = [],
  customers = [],
  products = [],
  loading,
  onCreateSale,
  onCancelSale,
  onRefresh,
  showToast,
  isQuickSaleOpen = false,
  setIsQuickSaleOpen
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // POS State
  const [posCustomer, setPosCustomer] = useState(''); // empty = walk-in
  const [posPaymentMethod, setPosPaymentMethod] = useState('UPI');
  const [posItems, setPosItems] = useState([
    { product_id: products[0]?.product_id || '', quantity: 1, unit_price: Number(products[0]?.selling_price) || 0 }
  ]);

  const handleProductSelect = (idx, prodId) => {
    const prod = products.find(p => String(p.product_id) === String(prodId));
    const newItems = [...posItems];
    newItems[idx].product_id = prodId;
    if (prod) {
      newItems[idx].unit_price = Number(prod.selling_price) || 0;
      if (newItems[idx].quantity > prod.stock_quantity) {
        newItems[idx].quantity = Math.max(1, prod.stock_quantity);
      }
    }
    setPosItems(newItems);
  };

  const handleQtyChange = (idx, qtyVal) => {
    const newItems = [...posItems];
    newItems[idx].quantity = Number(qtyVal) || 1;
    setPosItems(newItems);
  };

  const addItemRow = () => {
    const firstAvailable = products.find(p => p.stock_quantity > 0) || products[0];
    setPosItems([
      ...posItems,
      { product_id: firstAvailable?.product_id || '', quantity: 1, unit_price: Number(firstAvailable?.selling_price) || 0 }
    ]);
  };

  const removeItemRow = (idx) => {
    if (posItems.length <= 1) return;
    setPosItems(posItems.filter((_, i) => i !== idx));
  };

  const posTotal = posItems.reduce((sum, item) => sum + (Number(item.quantity) || 0) * (Number(item.unit_price) || 0), 0);

  const handleProcessSale = async (e) => {
    e.preventDefault();

    // Verify stock client-side first
    for (const item of posItems) {
      const prod = products.find(p => String(p.product_id) === String(item.product_id));
      if (!prod) {
        showToast('Please select a valid product', 'error');
        return;
      }
      if (Number(item.quantity) <= 0) {
        showToast(`Quantity for "${prod.product_name}" must be greater than 0`, 'error');
        return;
      }
      if (Number(item.quantity) > Number(prod.stock_quantity)) {
        showToast(`Insufficient stock for "${prod.product_name}". Available: ${prod.stock_quantity}, requested: ${item.quantity}`, 'error');
        return;
      }
    }

    setSubmitting(true);
    try {
      const response = await onCreateSale({
        customer_id: posCustomer || null,
        items: posItems,
        payment_method: posPaymentMethod,
        status: 'Completed'
      });

      showToast(`Sale #${response.sale_id} completed successfully & inventory deducted in MySQL!`, 'success');

      // Prepare invoice view
      const customerObj = customers.find(c => String(c.customer_id) === String(posCustomer));
      const invoiceData = {
        sale_id: response.sale_id,
        sale_date: new Date().toISOString(),
        customer_name: customerObj ? customerObj.customer_name : 'Walk-in Customer',
        customer_phone: customerObj ? customerObj.phone : null,
        customer_email: customerObj ? customerObj.email : null,
        payment_method: posPaymentMethod,
        total_amount: response.total_amount,
        status: 'Completed',
        items: response.items
      };

      setSelectedInvoice(invoiceData);
      setIsInvoiceOpen(true);
      if (setIsQuickSaleOpen) setIsQuickSaleOpen(false);

      // Reset POS
      const firstAvailable = products.find(p => p.stock_quantity > 0) || products[0];
      setPosItems([{ product_id: firstAvailable?.product_id || '', quantity: 1, unit_price: Number(firstAvailable?.selling_price) || 0 }]);
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = async (saleId) => {
    if (!window.confirm(`Are you sure you want to cancel Sales Order #${saleId}? MySQL will reverse the deducted stock back into inventory.`)) {
      return;
    }
    try {
      await onCancelSale(saleId);
      showToast(`Sale #${saleId} cancelled and stock restored`, 'success');
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    }
  };

  const filtered = sales.filter(s => {
    const matchSearch = `${s.customer_name} #${s.sale_id}`.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'all' || s.status.toLowerCase() === statusFilter.toLowerCase();
    return matchSearch && matchStatus;
  });

  return (
    <div className="page-container sales-page">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">POINT OF SALE & INVOICING</div>
          <h1 className="page-title">Sales Terminal & Orders</h1>
          <p className="page-subtitle">
            Execute transactional point-of-sale checkouts with immediate inventory deductions and printable invoices.
          </p>
        </div>

        <div className="page-header-actions">
          <button
            className="btn btn-primary"
            onClick={() => {
              if (setIsQuickSaleOpen) setIsQuickSaleOpen(true);
            }}
          >
            <TrendingUp size={16} /> Open POS Checkout
          </button>
        </div>
      </div>

      {/* POS Terminal Card */}
      <div className="card pos-terminal-card mb-6">
        <div className="card-header">
          <div className="pos-brand-tag">
            <ShoppingCart size={18} />
            <span>Fast Checkout Terminal</span>
          </div>
          <span className="badge badge-success">Live Stock Connected</span>
        </div>

        <form onSubmit={handleProcessSale} className="pos-form">
          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Customer Account</label>
              <select
                className="form-select"
                value={posCustomer}
                onChange={(e) => setPosCustomer(e.target.value)}
              >
                <option value="">Walk-in Customer (Guest)</option>
                {customers.map((c) => (
                  <option key={c.customer_id} value={c.customer_id}>
                    {c.customer_name} {c.phone ? `(${c.phone})` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-field">
              <label className="form-label">Payment Method</label>
              <select
                className="form-select"
                value={posPaymentMethod}
                onChange={(e) => setPosPaymentMethod(e.target.value)}
              >
                <option value="UPI">UPI (Google Pay / PhonePe / Paytm)</option>
                <option value="Card">Debit / Credit Card</option>
                <option value="Cash">Cash at Counter</option>
                <option value="Bank Transfer">Bank Transfer / NEFT</option>
              </select>
            </div>
          </div>

          <div className="pos-items-box">
            <div className="pos-items-header">
              <span>PRODUCT</span>
              <span>IN STOCK</span>
              <span>QTY</span>
              <span>PRICE</span>
              <span className="text-right">SUBTOTAL</span>
              <span></span>
            </div>

            {posItems.map((item, idx) => {
              const currentProd = products.find(p => String(p.product_id) === String(item.product_id));
              const available = currentProd ? Number(currentProd.stock_quantity) : 0;
              const isInsufficient = Number(item.quantity) > available;

              return (
                <div key={idx} className={`pos-item-row ${isInsufficient ? 'insufficient-row' : ''}`}>
                  <div className="flex-3">
                    <select
                      className="form-select"
                      value={item.product_id}
                      onChange={(e) => handleProductSelect(idx, e.target.value)}
                      required
                    >
                      <option value="">Select Item to Sell</option>
                      {products.map((p) => (
                        <option
                          key={p.product_id}
                          value={p.product_id}
                          disabled={p.stock_quantity === 0}
                        >
                          {p.product_name} ({p.sku}) · {p.stock_quantity > 0 ? `${p.stock_quantity} available` : 'OUT OF STOCK'}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex-1 text-center font-bold">
                    <span className={available === 0 ? 'text-danger' : available <= 5 ? 'text-amber' : 'text-emerald'}>
                      {available}
                    </span>
                  </div>

                  <div className="flex-1">
                    <input
                      type="number"
                      min="1"
                      max={available}
                      className={`form-input text-center ${isInsufficient ? 'input-error' : ''}`}
                      value={item.quantity}
                      onChange={(e) => handleQtyChange(idx, e.target.value)}
                      required
                    />
                  </div>

                  <div className="flex-1 text-right">
                    {formatCurrency(item.unit_price)}
                  </div>

                  <div className="flex-1 text-right font-bold text-primary">
                    {formatCurrency((Number(item.quantity) || 0) * (Number(item.unit_price) || 0))}
                  </div>

                  <div className="flex-action text-right">
                    {posItems.length > 1 && (
                      <button
                        type="button"
                        className="btn-icon-subtle text-danger"
                        onClick={() => removeItemRow(idx)}
                      >
                        <Trash size={15} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pos-actions-row">
            <button type="button" className="btn btn-secondary btn-sm" onClick={addItemRow}>
              <Plus size={14} /> Add Line Item
            </button>

            <div className="pos-total-container">
              <span className="total-label">Grand Total:</span>
              <span className="total-amount-display">{formatCurrency(posTotal)}</span>
              <button
                type="submit"
                className="btn btn-success btn-lg ml-4"
                disabled={submitting || posTotal <= 0}
              >
                <CheckCircle2 size={18} />
                <span>{submitting ? 'Committing in MySQL...' : 'Complete & Generate Invoice'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Sales Orders History Toolbar */}
      <div className="card table-filter-toolbar">
        <div className="toolbar-search">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            placeholder="Search sales history by customer name or order #..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="toolbar-filters">
          <div className="select-wrapper">
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
              <option value="all">All Order Statuses</option>
              <option value="completed">Completed</option>
              <option value="cancelled">Cancelled</option>
              <option value="pending">Pending</option>
            </select>
          </div>
        </div>
      </div>

      {/* Sales Table */}
      <div className="card table-card">
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th>ORDER #</th>
                <th>CUSTOMER</th>
                <th>DATE & TIME</th>
                <th>ITEMS</th>
                <th>UNITS</th>
                <th>PAYMENT</th>
                <th className="text-right">TOTAL</th>
                <th>STATUS</th>
                <th className="text-center">ACTIONS</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan="9" className="empty-cell">No sales orders found</td></tr>
              ) : (
                filtered.map((s) => (
                  <tr key={s.sale_id}>
                    <td><strong>SO-#{String(s.sale_id).padStart(4, '0')}</strong></td>
                    <td>
                      <span className="customer-name-cell">{s.customer_name}</span>
                      {s.customer_phone && <span className="text-xs text-muted block">{s.customer_phone}</span>}
                    </td>
                    <td>{formatDate(s.sale_date)}</td>
                    <td>{s.total_items} items</td>
                    <td><strong>{s.total_quantity}</strong> units</td>
                    <td><span className="method-pill">{s.payment_method || 'Cash'}</span></td>
                    <td className="text-right"><strong>{formatCurrency(s.total_amount)}</strong></td>
                    <td>
                      <span className={`status-pill status-${s.status.toLowerCase()}`}>
                        {s.status}
                      </span>
                    </td>
                    <td>
                      <div className="action-buttons-group">
                        <button
                          className="btn-icon-subtle"
                          title="Print Tax Invoice"
                          onClick={() => {
                            setSelectedInvoice(s);
                            setIsInvoiceOpen(true);
                          }}
                        >
                          <Printer size={15} />
                        </button>
                        {s.status === 'Completed' && (
                          <button
                            className="btn-icon-subtle text-danger"
                            title="Cancel Order & Restock Inventory"
                            onClick={() => handleCancel(s.sale_id)}
                          >
                            <XCircle size={15} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Tax Invoice Modal */}
      <InvoiceModal
        isOpen={isInvoiceOpen}
        onClose={() => setIsInvoiceOpen(false)}
        sale={selectedInvoice}
      />
    </div>
  );
}
