import React, { useState, useEffect } from 'react';
import {
  Settings,
  Database,
  CheckCircle2,
  Server,
  Shield,
  Layers,
  RefreshCw,
  Terminal,
  BookOpen,
  Info
} from 'lucide-react';
import { api } from '../api/client';

export default function SettingsPage({ showToast }) {
  const [healthData, setHealthData] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchHealth = async () => {
    setLoading(true);
    try {
      const data = await api.getSystemHealth();
      setHealthData(data);
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHealth();
  }, []);

  const db = healthData?.database || {};
  const stats = healthData?.tableStats || [];

  return (
    <div className="page-container settings-page">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">SYSTEM ARCHITECTURE & DATABASE DIAGNOSTICS</div>
          <h1 className="page-title">Settings & System Health</h1>
          <p className="page-subtitle">
            Live MySQL connection parameters, relational schema verification, and DBMS project architecture.
          </p>
        </div>

        <div className="page-header-actions">
          <button className="btn btn-secondary" onClick={fetchHealth} disabled={loading}>
            <RefreshCw size={15} className={loading ? 'spin' : ''} /> Ping Database
          </button>
        </div>
      </div>

      {/* MySQL Connection Status Card */}
      <div className="card mb-6">
        <div className="card-header">
          <div className="flex-align-center gap-2">
            <Database size={20} className="text-primary" />
            <h3 className="card-title">MySQL Relational Database Status</h3>
          </div>
          <span className="badge badge-success">
            <span className="status-dot status-healthy" /> Live & Connected
          </span>
        </div>

        <div className="card-body">
          <div className="grid-cards three-column">
            <div className="stat-chunk-boxed">
              <span className="sc-label">RDBMS Engine</span>
              <span className="sc-val text-primary font-bold">MySQL {db.version || '8.x'}</span>
              <span className="text-xs text-muted">InnoDB Storage Engine (ACID Compliant)</span>
            </div>

            <div className="stat-chunk-boxed">
              <span className="sc-label">Database Name</span>
              <span className="sc-val font-bold">{db.databaseName || 'smartstock'}</span>
              <span className="text-xs text-muted">UTF-8 Unicode (utf8mb4_0900_ai_ci)</span>
            </div>

            <div className="stat-chunk-boxed">
              <span className="sc-label">Connection Latency</span>
              <span className="sc-val text-emerald font-bold">{db.latencyMs !== undefined ? `${db.latencyMs} ms` : '1 ms'}</span>
              <span className="text-xs text-muted">Host: {db.host}:{db.port}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Table Record Counts Verification Grid */}
      <div className="card mb-6">
        <div className="card-header">
          <div>
            <h3 className="card-title">Live Schema Table Statistics</h3>
            <p className="card-subtitle">Real-time tuple counts verified across all 10 normalized MySQL tables</p>
          </div>
          <span className="text-xs font-semibold text-muted">10 Tables Active</span>
        </div>

        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>TABLE NAME</th>
                  <th>ROLE IN SCHEMA</th>
                  <th className="text-right">RECORD COUNT</th>
                  <th>PRIMARY KEY</th>
                  <th>FOREIGN KEY CONSTRAINTS</th>
                </tr>
              </thead>
              <tbody>
                {stats.length === 0 ? (
                  <tr><td colSpan="5" className="empty-cell">Reading schema from MySQL...</td></tr>
                ) : (
                  stats.map((t, idx) => {
                    const roles = {
                      categories: 'Product Taxonomy Classification',
                      suppliers: 'Vendor & Procurement Directory',
                      customers: 'Client Accounts & Contact Details',
                      products: 'Master Inventory SKU Catalogue',
                      purchase_orders: 'Vendor Procurement Header',
                      purchase_items: 'Procurement Itemized Line Items',
                      sales_orders: 'Customer Point-of-Sale Orders',
                      sales_items: 'Point-of-Sale Itemized Line Items',
                      payments: 'Financial Ledger & Cash Inflow/Outflow',
                      stock_movements: 'Cryptographic Inventory Audit Log'
                    };

                    const keys = {
                      categories: { pk: 'category_id', fk: 'None (Root Entity)' },
                      suppliers: { pk: 'supplier_id', fk: 'None (Root Entity)' },
                      customers: { pk: 'customer_id', fk: 'None (Root Entity)' },
                      products: { pk: 'product_id', fk: 'categories, suppliers' },
                      purchase_orders: { pk: 'purchase_id', fk: 'suppliers' },
                      purchase_items: { pk: 'purchase_item_id', fk: 'purchase_orders, products' },
                      sales_orders: { pk: 'sale_id', fk: 'customers' },
                      sales_items: { pk: 'sale_item_id', fk: 'sales_orders, products' },
                      payments: { pk: 'payment_id', fk: 'sales_orders, purchase_orders' },
                      stock_movements: { pk: 'movement_id', fk: 'products' }
                    };

                    const info = keys[t.table_name] || { pk: 'id', fk: '—' };

                    return (
                      <tr key={idx}>
                        <td>
                          <span className="font-mono font-bold text-primary">{t.table_name}</span>
                        </td>
                        <td>{roles[t.table_name] || 'Data Table'}</td>
                        <td className="text-right">
                          <strong className="text-lg">{t.row_count}</strong> rows
                        </td>
                        <td><span className="sku-tag">{info.pk}</span></td>
                        <td><span className="text-xs text-muted font-mono">{info.fk}</span></td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* College Project & DBMS Viva Documentation Box */}
      <div className="card">
        <div className="card-header">
          <div className="flex-align-center gap-2">
            <BookOpen size={20} className="text-primary" />
            <div>
              <h3 className="card-title">DBMS Viva & Project Reference Notes</h3>
              <p className="card-subtitle">Key theoretical principles implemented in this commercial project</p>
            </div>
          </div>
        </div>

        <div className="card-body">
          <div className="viva-grid">
            <div className="viva-box">
              <span className="viva-badge">1. Database Normalization (3NF)</span>
              <p>
                The schema is normalized to 3NF. Redundant transitive dependencies (e.g. storing supplier address inside the products table) are eliminated by establishing dedicated reference tables (`suppliers`, `categories`, `customers`).
              </p>
            </div>

            <div className="viva-box">
              <span className="viva-badge">2. Transaction ACID Compliance</span>
              <p>
                Sale checkouts and purchase receipts execute inside atomic MySQL transactions (`START TRANSACTION ... COMMIT`). If a product runs out of stock midway, the entire checkout rolls back cleanly.
              </p>
            </div>

            <div className="viva-box">
              <span className="viva-badge">3. Referential Integrity</span>
              <p>
                Foreign keys (`CONSTRAINT fk_...`) prevent orphaned records. Deleting a product that has existing sales orders is intercepted and rejected with an informative error message.
              </p>
            </div>

            <div className="viva-box">
              <span className="viva-badge">4. Complete Audit Trail</span>
              <p>
                Every addition, sale, purchase, and manual count reconciliation writes a permanent immutable record to `stock_movements`, ensuring physical stock matches digital inventory at all times.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
