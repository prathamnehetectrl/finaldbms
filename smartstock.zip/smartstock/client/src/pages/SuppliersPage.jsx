import React, { useState } from 'react';
import { Truck, Plus, Edit2, Trash2, Phone, Mail, MapPin, Package, ShoppingBag, Search } from 'lucide-react';
import Modal from '../components/Modal.jsx';
import { formatCurrency } from '../api/client';

export default function SuppliersPage({
  suppliers = [],
  loading,
  onAddSupplier,
  onUpdateSupplier,
  onDeleteSupplier,
  onRefresh,
  showToast
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [editSupplier, setEditSupplier] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    supplier_name: '',
    phone: '',
    email: '',
    address: ''
  });

  const openAdd = () => {
    setFormData({ supplier_name: '', phone: '', email: '', address: '' });
    setIsAddOpen(true);
  };

  const openEdit = (s) => {
    setEditSupplier(s);
    setFormData({
      supplier_name: s.supplier_name,
      phone: s.phone || '',
      email: s.email || '',
      address: s.address || ''
    });
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!formData.supplier_name.trim()) {
      showToast('Supplier name is required', 'error');
      return;
    }

    setSubmitting(true);
    try {
      if (editSupplier) {
        await onUpdateSupplier(editSupplier.supplier_id, formData);
        showToast('Supplier updated successfully', 'success');
        setEditSupplier(null);
      } else {
        await onAddSupplier(formData);
        showToast('Supplier added successfully', 'success');
        setIsAddOpen(false);
      }
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSubmitting(true);
    try {
      await onDeleteSupplier(deleteTarget.supplier_id);
      showToast(`Supplier "${deleteTarget.supplier_name}" deleted`, 'success');
      setDeleteTarget(null);
      onRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  const filtered = suppliers.filter(s =>
    `${s.supplier_name} ${s.phone || ''} ${s.email || ''} ${s.address || ''}`
      .toLowerCase()
      .includes(searchTerm.toLowerCase())
  );

  return (
    <div className="page-container">
      <div className="page-header">
        <div className="page-header-content">
          <div className="page-eyebrow">PROCUREMENT & VENDOR MANAGEMENT</div>
          <h1 className="page-title">Suppliers Directory</h1>
          <p className="page-subtitle">
            Manage product vendors, procurement contacts, and historical purchase order spend.
          </p>
        </div>

        <div className="page-header-actions">
          <button className="btn btn-primary" onClick={openAdd}>
            <Plus size={16} /> Add Supplier
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="card table-filter-toolbar">
        <div className="toolbar-search">
          <Search size={16} className="search-icon" />
          <input
            type="text"
            placeholder="Search suppliers by name, phone, email, or city..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="text-sm text-muted">
          Showing <strong>{filtered.length}</strong> suppliers
        </div>
      </div>

      {/* Supplier Grid */}
      <div className="grid-cards three-column">
        {filtered.map((s) => (
          <div key={s.supplier_id} className="card entity-card">
            <div className="entity-header">
              <div className="entity-avatar-box"><Truck size={20} /></div>
              <div className="entity-title-box">
                <h4>{s.supplier_name}</h4>
                <span className="entity-badge">{s.product_count || 0} products supplied</span>
              </div>
            </div>

            <div className="entity-contact-list">
              {s.phone && (
                <div className="contact-item">
                  <Phone size={14} /> <span>{s.phone}</span>
                </div>
              )}
              {s.email && (
                <div className="contact-item">
                  <Mail size={14} /> <span>{s.email}</span>
                </div>
              )}
              {s.address && (
                <div className="contact-item">
                  <MapPin size={14} /> <span>{s.address}</span>
                </div>
              )}
            </div>

            <div className="entity-stats-row">
              <div className="stat-chunk">
                <span className="sc-label">Purchase Orders</span>
                <span className="sc-val">{s.total_orders || 0} POs</span>
              </div>
              <div className="stat-chunk">
                <span className="sc-label">Total Spend</span>
                <span className="sc-val text-primary">{formatCurrency(s.total_purchased)}</span>
              </div>
            </div>

            <div className="entity-footer-actions">
              <button className="btn btn-secondary btn-sm" onClick={() => openEdit(s)}>
                <Edit2 size={13} /> Edit
              </button>
              <button className="btn btn-secondary btn-sm text-danger" onClick={() => setDeleteTarget(s)}>
                <Trash2 size={13} /> Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      <Modal
        isOpen={isAddOpen || !!editSupplier}
        onClose={() => {
          setIsAddOpen(false);
          setEditSupplier(null);
        }}
        title={editSupplier ? `Edit Supplier: ${editSupplier.supplier_name}` : 'Register New Vendor'}
      >
        <form onSubmit={handleSave} className="modal-form">
          <div className="form-field">
            <label className="form-label">Company / Supplier Name *</label>
            <input
              type="text"
              className="form-input"
              placeholder="e.g. Apex Hardware Supplies Ltd"
              value={formData.supplier_name}
              onChange={(e) => setFormData({ ...formData, supplier_name: e.target.value })}
              required
            />
          </div>

          <div className="form-grid two-column">
            <div className="form-field">
              <label className="form-label">Phone Number</label>
              <input
                type="text"
                className="form-input"
                placeholder="+91 98765 43210"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>

            <div className="form-field">
              <label className="form-label">Email Address</label>
              <input
                type="email"
                className="form-input"
                placeholder="sales@vendor.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
          </div>

          <div className="form-field">
            <label className="form-label">Physical Address</label>
            <input
              type="text"
              className="form-input"
              placeholder="City, State, Zip"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            />
          </div>

          <div className="modal-actions-right">
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => {
                setIsAddOpen(false);
                setEditSupplier(null);
              }}
            >
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Saving...' : editSupplier ? 'Update Supplier' : 'Save Supplier'}
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Confirmation */}
      {deleteTarget && (
        <Modal
          isOpen={!!deleteTarget}
          onClose={() => setDeleteTarget(null)}
          title="Confirm Supplier Deletion"
          maxWidth="440px"
        >
          <div className="confirmation-box">
            <p>Delete vendor <strong>"{deleteTarget.supplier_name}"</strong>?</p>
            <p className="text-sm text-muted mt-2">
              Cannot be deleted if products or purchase orders in the database are linked to this supplier.
            </p>
            <div className="modal-actions-right mt-6">
              <button className="btn btn-secondary" onClick={() => setDeleteTarget(null)}>Cancel</button>
              <button className="btn btn-danger" onClick={handleDelete} disabled={submitting}>
                {submitting ? 'Deleting...' : 'Delete Vendor'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
