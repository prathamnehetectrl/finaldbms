-- SmartStock corrected sample data seed
-- Purpose: populate an empty SmartStock database with consistent stock figures.
-- This is a separate file from the original sample_data.sql and intentionally leaves
-- the original seed untouched. Run it manually only once against an empty database.

USE SmartStock;
SET NAMES utf8mb4;
START TRANSACTION;

-- 1. Categories
INSERT INTO categories (category_id, category_name, description) VALUES
(1, 'Computer Accessories', 'Keyboards, mice, hubs and storage'),
(2, 'Networking', 'Routers and network equipment'),
(3, 'Electronics', 'Audio and video electronics'),
(4, 'Power Backup', 'UPS and power protection');

-- 2. Suppliers
INSERT INTO suppliers (supplier_id, supplier_name, phone, email, address) VALUES
(1, 'TechSource India', '9876543210', 'sales@techsource.example', 'Mumbai, Maharashtra'),
(2, 'Digital World', '9876543211', 'contact@digitalworld.example', 'Pune, Maharashtra'),
(3, 'Smart Systems', '9876543212', 'info@smartsystems.example', 'Nashik, Maharashtra');

-- 3. Customers
INSERT INTO customers (customer_id, customer_name, phone, email, address) VALUES
(1, 'Aarav Sharma', '9000000001', 'aarav@example.com', 'Mumbai, Maharashtra'),
(2, 'Priya Patil', '9000000002', 'priya@example.com', 'Pune, Maharashtra'),
(3, 'Rohan Deshmukh', '9000000003', 'rohan@example.com', 'Nashik, Maharashtra'),
(4, 'Neha Shah', '9000000004', 'neha@example.com', 'Thane, Maharashtra'),
(5, 'Kiran Joshi', '9000000005', 'kiran@example.com', 'Mumbai, Maharashtra');

-- 4. Products
-- Quantities below are reconciled against the opening stock + purchase receipts - completed sales.
INSERT INTO products
(product_id, sku, product_name, category_id, supplier_id, cost_price, selling_price, stock_quantity, reorder_level)
VALUES
(1, 'SS-MOU-001', 'Wireless Mouse', 1, 1, 250.00, 399.00, 41, 10),
(2, 'SS-KEY-002', 'Mechanical Keyboard', 1, 1, 1200.00, 1799.00, 17, 5),
(3, 'SS-HUB-003', 'USB-C Hub', 1, 2, 700.00, 1099.00, 18, 10),
(4, 'SS-RTR-004', 'WiFi Router', 2, 3, 1400.00, 1999.00, 22, 5),
(5, 'SS-WEB-005', 'HD Webcam', 3, 2, 900.00, 1399.00, 13, 8),
(6, 'SS-SPK-006', 'Bluetooth Speaker', 3, 3, 650.00, 999.00, 27, 8),
(7, 'SS-USB-007', 'USB Flash Drive 64GB', 1, 1, 300.00, 449.00, 55, 15),
(8, 'SS-UPS-008', 'UPS Backup', 4, 3, 1800.00, 2499.00, 6, 5);

-- 5. Purchase orders
INSERT INTO purchase_orders
(purchase_id, supplier_id, purchase_date, status, total_amount)
VALUES
(1, 1, '2026-09-02 10:15:00', 'Received', 17000.00),
(2, 2, '2026-09-08 11:30:00', 'Received', 16000.00),
(3, 3, '2026-09-15 14:00:00', 'Received', 36000.00),
(4, 1, '2026-10-20 09:45:00', 'Pending', 6000.00);

-- 6. Purchase items
INSERT INTO purchase_items
(purchase_item_id, purchase_id, product_id, quantity, unit_cost)
VALUES
(1, 1, 1, 20, 250.00),
(2, 1, 2, 5, 1200.00),
(3, 1, 7, 20, 300.00),
(4, 2, 3, 10, 700.00),
(5, 2, 5, 10, 900.00),
(6, 3, 4, 10, 1400.00),
(7, 3, 6, 20, 650.00),
(8, 3, 8, 5, 1800.00),
(9, 4, 2, 5, 1200.00);

-- 7. Sales orders
INSERT INTO sales_orders
(sale_id, customer_id, sale_date, status, total_amount)
VALUES
(1, 1, '2026-09-10 12:10:00', 'Completed', 2196.00),
(2, 2, '2026-09-12 15:20:00', 'Completed', 1799.00),
(3, 3, '2026-09-18 16:05:00', 'Completed', 2798.00),
(4, 4, '2026-10-02 13:30:00', 'Completed', 1998.00),
(5, 5, '2026-10-12 17:10:00', 'Completed', 1399.00),
(6, NULL, '2026-10-22 10:40:00', 'Completed', 2499.00),
(7, 1, '2026-10-23 11:00:00', 'Cancelled', 399.00);

-- 8. Sales items
INSERT INTO sales_items
(sale_item_id, sale_id, product_id, quantity, unit_price, unit_cost)
VALUES
(1, 1, 1, 2, 399.00, 250.00),
(2, 1, 3, 1, 1099.00, 700.00),
(3, 1, 7, 1, 299.00, 300.00),
(4, 2, 2, 1, 1799.00, 1200.00),
(5, 3, 5, 2, 1399.00, 900.00),
(6, 4, 6, 2, 999.00, 650.00),
(7, 5, 5, 1, 1399.00, 900.00),
(8, 6, 8, 1, 2499.00, 1800.00),
(9, 7, 1, 1, 399.00, 250.00);

-- 9. Payments
INSERT INTO payments
(payment_id, sale_id, purchase_id, amount, payment_method, payment_date)
VALUES
(1, 1, NULL, 2196.00, 'UPI', '2026-09-10 12:12:00'),
(2, 2, NULL, 1799.00, 'Card', '2026-09-12 15:22:00'),
(3, 3, NULL, 2798.00, 'Cash', '2026-09-18 16:07:00'),
(4, 4, NULL, 1998.00, 'UPI', '2026-10-02 13:32:00'),
(5, 5, NULL, 1399.00, 'Bank Transfer', '2026-10-12 17:12:00'),
(6, 6, NULL, 2499.00, 'UPI', '2026-10-22 10:42:00'),
(7, NULL, 1, 10000.00, 'Bank Transfer', '2026-09-03 10:00:00'),
(8, NULL, 2, 15300.00, 'UPI', '2026-09-09 11:00:00'),
(9, NULL, 3, 12000.00, 'Bank Transfer', '2026-09-16 10:30:00');

-- 10. Stock movements
INSERT INTO stock_movements
(movement_id, product_id, movement_type, quantity_change, movement_date, notes)
VALUES
(1, 1, 'Opening', 23, '2026-09-01 09:00:00', 'Opening stock'),
(2, 1, 'Purchase', 20, '2026-09-02 10:30:00', 'Received purchase #1'),
(3, 1, 'Sale', -2, '2026-09-10 12:10:00', 'Completed sale #1'),
(5, 2, 'Opening', 13, '2026-09-01 09:00:00', 'Opening stock'),
(6, 2, 'Purchase', 5, '2026-09-02 10:30:00', 'Received purchase #1'),
(7, 2, 'Sale', -1, '2026-09-12 15:20:00', 'Completed sale #2'),
(8, 3, 'Opening', 9, '2026-09-01 09:00:00', 'Opening stock'),
(9, 3, 'Purchase', 10, '2026-09-08 11:45:00', 'Received purchase #2'),
(10, 3, 'Sale', -1, '2026-09-10 12:10:00', 'Completed sale #1'),
(11, 4, 'Opening', 12, '2026-09-01 09:00:00', 'Opening stock'),
(12, 4, 'Purchase', 10, '2026-09-15 14:15:00', 'Received purchase #3'),
(13, 5, 'Opening', 6, '2026-09-01 09:00:00', 'Opening stock'),
(14, 5, 'Purchase', 10, '2026-09-08 11:45:00', 'Received purchase #2'),
(15, 5, 'Sale', -2, '2026-09-18 16:05:00', 'Completed sale #3'),
(16, 5, 'Sale', -1, '2026-10-12 17:10:00', 'Completed sale #5'),
(17, 6, 'Opening', 9, '2026-09-01 09:00:00', 'Opening stock'),
(18, 6, 'Purchase', 20, '2026-09-15 14:15:00', 'Received purchase #3'),
(19, 6, 'Sale', -2, '2026-10-02 13:30:00', 'Completed sale #4'),
(20, 7, 'Opening', 36, '2026-09-01 09:00:00', 'Opening stock'),
(21, 7, 'Purchase', 20, '2026-09-02 10:30:00', 'Received purchase #1'),
(22, 7, 'Sale', -1, '2026-09-10 12:10:00', 'Completed sale #1'),
(23, 8, 'Opening', 2, '2026-09-01 09:00:00', 'Opening stock'),
(24, 8, 'Purchase', 5, '2026-09-15 14:15:00', 'Received purchase #3'),
(25, 8, 'Sale', -1, '2026-10-22 10:40:00', 'Completed sale #6');

COMMIT;

SELECT 'categories' AS table_name, COUNT(*) AS row_count FROM categories
UNION ALL SELECT 'suppliers', COUNT(*) FROM suppliers
UNION ALL SELECT 'customers', COUNT(*) FROM customers
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'purchase_orders', COUNT(*) FROM purchase_orders
UNION ALL SELECT 'purchase_items', COUNT(*) FROM purchase_items
UNION ALL SELECT 'sales_orders', COUNT(*) FROM sales_orders
UNION ALL SELECT 'sales_items', COUNT(*) FROM sales_items
UNION ALL SELECT 'payments', COUNT(*) FROM payments
UNION ALL SELECT 'stock_movements', COUNT(*) FROM stock_movements;

SELECT product_id, sku, product_name, stock_quantity, reorder_level
FROM products
ORDER BY product_id;
