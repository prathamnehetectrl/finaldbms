-- SmartStock expanded sample data
-- Additive and rerunnable: existing rows are retained and generated records are
-- identified by their stable SKU, phone number, or transaction timestamp.
USE smartstock;
SET NAMES utf8mb4;

DROP TEMPORARY TABLE IF EXISTS
  expanded_sales_orders,
  expanded_purchase_orders,
  expanded_sales_stage,
  expanded_purchase_stage,
  expanded_products,
  expanded_customers,
  expanded_suppliers,
  expanded_product_stage,
  expanded_customer_stage,
  expanded_supplier_stage,
  expanded_sequence;

CREATE TEMPORARY TABLE expanded_sequence (
  n INT NOT NULL PRIMARY KEY
);

INSERT INTO expanded_sequence (n)
WITH RECURSIVE numbers (n) AS (
  SELECT 1
  UNION ALL
  SELECT n + 1 FROM numbers WHERE n < 120
)
SELECT n FROM numbers;

CREATE TEMPORARY TABLE expanded_supplier_stage AS
SELECT
  n AS supplier_no,
  ELT(n,
    'Aarav Tech Distributors', 'Bharat Digital Supply', 'Crescent Electronics',
    'Deccan IT Wholesale', 'Eastern Byte Systems', 'Falcon Computer House',
    'Ganga Network Solutions', 'Horizon Office Tech', 'Indus Peripherals',
    'Jupiter Components', 'Kaveri Electronics', 'Lotus Data Systems',
    'Metro Techno Traders', 'National Computer Mart', 'Orbit Telecom Supply',
    'Pioneer Power Systems', 'Quantum IT Products', 'Reliance Gadget Hub',
    'Shreeji Computer Links', 'Trident Digital India'
  ) AS supplier_name,
  CONCAT('98', LPAD(20000000 + n, 8, '0')) AS phone,
  CONCAT('sales', LPAD(n, 2, '0'), '@smartstock.example') AS email,
  CONCAT(
    ELT(MOD(n - 1, 12) + 1,
      'Mumbai', 'Pune', 'Nashik', 'Nagpur', 'Bengaluru', 'Hyderabad',
      'Chennai', 'Ahmedabad', 'Jaipur', 'Kolkata', 'Kochi', 'Delhi'
    ),
    ', ',
    ELT(MOD(n - 1, 12) + 1,
      'Maharashtra', 'Karnataka', 'Telangana', 'Maharashtra',
      'Karnataka', 'Telangana', 'Tamil Nadu', 'Gujarat',
      'Rajasthan', 'West Bengal', 'Kerala', 'Delhi'
    )
  ) AS address
FROM expanded_sequence
WHERE n <= 20;

CREATE TEMPORARY TABLE expanded_customer_stage AS
SELECT
  n AS customer_no,
  CONCAT(
    ELT(MOD(n - 1, 20) + 1,
      'Aarav', 'Aditi', 'Ananya', 'Arjun', 'Diya', 'Ishaan', 'Kavya',
      'Kabir', 'Meera', 'Neha', 'Rohan', 'Saanvi', 'Vikram', 'Priya',
      'Rahul', 'Tanvi', 'Aditya', 'Mira', 'Kunal', 'Zoya'
    ),
    ' ',
    ELT(FLOOR((n - 1) / 20) + 1,
      'Sharma', 'Patel', 'Reddy', 'Iyer', 'Deshmukh', 'Kapoor'
    )
  ) AS customer_name,
  CONCAT('91', LPAD(70000000 + n, 8, '0')) AS phone,
  CONCAT('customer', LPAD(n, 2, '0'), '@smartstock.example') AS email,
  CONCAT(
    ELT(MOD(n - 1, 12) + 1,
      'Mumbai', 'Pune', 'Nashik', 'Nagpur', 'Bengaluru', 'Hyderabad',
      'Chennai', 'Ahmedabad', 'Jaipur', 'Kolkata', 'Kochi', 'Delhi'
    ),
    ', ',
    ELT(MOD(n - 1, 12) + 1,
      'Maharashtra', 'Karnataka', 'Telangana', 'Maharashtra',
      'Karnataka', 'Telangana', 'Tamil Nadu', 'Gujarat',
      'Rajasthan', 'West Bengal', 'Kerala', 'Delhi'
    )
  ) AS address
FROM expanded_sequence
WHERE n <= 60;

CREATE TEMPORARY TABLE expanded_product_stage AS
SELECT
  n AS product_no,
  CONCAT('SSX-', LPAD(n, 3, '0')) AS sku,
  ELT(n,
    'Wireless Mouse - Silent M310', 'Wireless Mouse - Ergonomic M420',
    'Mechanical Keyboard - Blue Switch K87', 'Mechanical Keyboard - Brown Switch K96',
    'Keyboard and Mouse Combo - Office C210', 'Keyboard and Mouse Combo - Wireless C330',
    'USB-C Hub - 5-in-1 H510', 'USB-C Hub - 8-in-1 H820',
    'Laptop Stand - Aluminium L120', 'Laptop Stand - Foldable L240',
    'Wi-Fi Router - Dual Band R1200', 'Wi-Fi Router - AX1800 R1800',
    'Ethernet Cable - Cat6 2m E602', 'Ethernet Cable - Cat6 5m E605',
    'Ethernet Cable - Cat6 10m E610', 'Wi-Fi Range Extender - N300 X300',
    'SSD - SATA 480GB S480', 'SSD - SATA 1TB S1000',
    'SSD - NVMe 512GB N512', 'SSD - NVMe 1TB N1000',
    'USB Flash Drive - 128GB U128', 'Portable Hard Drive - 1TB D1000',
    'RAM - DDR4 8GB 3200MHz M408', 'RAM - DDR4 16GB 3200MHz M416',
    'RAM - DDR5 16GB 5200MHz M516', 'RAM - DDR5 32GB 5200MHz M532',
    'Memory Card - microSD 128GB C128', 'Memory Card - microSD 256GB C256',
    'Webcam - Full HD 1080p W108', 'Webcam - 2K Autofocus W200',
    'Bluetooth Speaker - Compact B120', 'Bluetooth Speaker - Portable B360',
    'Headset - USB Stereo H110', 'Headset - Bluetooth H220',
    'UPS - 600VA Line Interactive P600', 'UPS - 1000VA Line Interactive P1000',
    'Surge Protector - 6 Socket P106', 'Surge Protector - 8 Socket P108',
    'Power Bank - 10000mAh PB10', 'Power Bank - 20000mAh PB20',
    'HDMI Cable - 2m 4K V202', 'HDMI Cable - 5m 4K V505',
    'DisplayPort Cable - 2m DP202', 'USB-C Cable - 1m Fast Charge C101',
    'USB-C Cable - 2m Fast Charge C202', 'USB-A to USB-C Cable - 1m A101',
    'Monitor - 22-inch Full HD D220', 'Monitor - 24-inch IPS Full HD D240',
    'Monitor - 27-inch QHD IPS D270', 'Monitor Stand - Adjustable S210',
    'Monitor Arm - Single Display A110', 'Webcam Light - USB Ring L120',
    'Laptop Cooling Pad - Dual Fan F220', 'Laptop Dock - USB-C D810',
    'Wireless Presenter - USB Receiver P150', 'Barcode Scanner - USB B110',
    'Mobile Charger - 30W USB-C C230', 'Mobile Charger - 65W GaN G265',
    'Document Shredder - Cross Cut O120', 'Label Printer - USB Thermal O220'
  ) AS product_name,
  CASE
    WHEN n <= 10 THEN 'Computer Peripherals'
    WHEN n <= 16 THEN 'Networking Equipment'
    WHEN n <= 22 THEN 'Data Storage'
    WHEN n <= 28 THEN 'Memory and Components'
    WHEN n <= 34 THEN 'Audio and Video'
    WHEN n <= 40 THEN 'Power Backup'
    WHEN n <= 46 THEN 'Cables and Connectivity'
    WHEN n <= 52 THEN 'Displays and Mounts'
    WHEN n <= 56 THEN 'Mobile Accessories'
    ELSE 'Office Technology'
  END AS category_name,
  MOD((n * 7) - 1, 20) + 1 AS supplier_no,
  ROUND((250 + MOD(n * 173, 5750)) / 10) * 10 AS cost_price,
  ROUND(
    ROUND((250 + MOD(n * 173, 5750)) / 10) * 10
    * (1.08 + MOD(n, 8) * 0.045),
    2
  ) AS selling_price,
  CASE
    WHEN n >= 55 THEN 8
    ELSE 12 + MOD(n, 9)
  END AS reorder_level
FROM expanded_sequence
WHERE n <= 60;

CREATE TEMPORARY TABLE expanded_suppliers (
  supplier_no INT NOT NULL PRIMARY KEY,
  supplier_id INT NOT NULL
);

CREATE TEMPORARY TABLE expanded_customers (
  customer_no INT NOT NULL PRIMARY KEY,
  customer_id INT NOT NULL
);

CREATE TEMPORARY TABLE expanded_products (
  product_no INT NOT NULL PRIMARY KEY,
  product_id INT NOT NULL,
  cost_price DECIMAL(10,2) NOT NULL,
  selling_price DECIMAL(10,2) NOT NULL
);

START TRANSACTION;

INSERT INTO categories (category_name, description)
SELECT seed.category_name, seed.description
FROM (
  SELECT 'Computer Peripherals' AS category_name, 'Keyboards, pointing devices, stands and computer accessories' AS description
  UNION ALL SELECT 'Networking Equipment', 'Routers, extenders and wired network accessories'
  UNION ALL SELECT 'Data Storage', 'Solid-state drives, portable drives and removable storage'
  UNION ALL SELECT 'Memory and Components', 'Desktop and laptop memory and internal components'
  UNION ALL SELECT 'Audio and Video', 'Webcams, headsets and speakers'
  UNION ALL SELECT 'Power Backup', 'UPS units, surge protection and backup power'
  UNION ALL SELECT 'Cables and Connectivity', 'Video, data and charging cables'
  UNION ALL SELECT 'Displays and Mounts', 'Monitors, stands and display accessories'
  UNION ALL SELECT 'Mobile Accessories', 'Mobile chargers and power accessories'
  UNION ALL SELECT 'Office Technology', 'Scanning, printing and document handling equipment'
) AS seed
WHERE NOT EXISTS (
  SELECT 1 FROM categories c WHERE c.category_name = seed.category_name
);

INSERT INTO suppliers (supplier_name, phone, email, address)
SELECT ss.supplier_name, ss.phone, ss.email, ss.address
FROM expanded_supplier_stage ss
WHERE NOT EXISTS (
  SELECT 1 FROM suppliers s WHERE s.phone = ss.phone
);

INSERT INTO expanded_suppliers (supplier_no, supplier_id)
SELECT ss.supplier_no, s.supplier_id
FROM expanded_supplier_stage ss
JOIN suppliers s ON s.phone = ss.phone;

INSERT INTO customers (customer_name, phone, email, address)
SELECT cs.customer_name, cs.phone, cs.email, cs.address
FROM expanded_customer_stage cs
WHERE NOT EXISTS (
  SELECT 1 FROM customers c WHERE c.phone = cs.phone
);

INSERT INTO expanded_customers (customer_no, customer_id)
SELECT cs.customer_no, c.customer_id
FROM expanded_customer_stage cs
JOIN customers c ON c.phone = cs.phone;

CREATE TEMPORARY TABLE expanded_purchase_stage AS
SELECT
  s.n AS purchase_no,
  DATE_ADD('2025-11-02 08:00:00', INTERVAL ((s.n - 1) * 7 + s.n) MINUTE) AS purchase_date,
  es.supplier_id,
  CASE
    WHEN MOD(s.n, 12) = 0 THEN 'Cancelled'
    WHEN MOD(s.n, 12) = 11 THEN 'Pending'
    ELSE 'Received'
  END AS status
FROM expanded_sequence s
JOIN expanded_suppliers es ON es.supplier_no = MOD(s.n - 1, 20) + 1
WHERE s.n <= 48;

CREATE TEMPORARY TABLE expanded_sales_stage AS
SELECT
  s.n AS sale_no,
  DATE_ADD('2025-11-03 09:00:00', INTERVAL ((s.n - 1) * 3 + s.n) MINUTE) AS sale_date,
  ec.customer_id,
  CASE
    WHEN MOD(s.n, 17) = 0 THEN 'Cancelled'
    WHEN MOD(s.n, 13) = 0 THEN 'Pending'
    ELSE 'Completed'
  END AS status
FROM expanded_sequence s
JOIN expanded_customers ec ON ec.customer_no = MOD(s.n - 1, 60) + 1
WHERE s.n <= 120;

CREATE TEMPORARY TABLE expanded_purchase_orders (
  purchase_no INT NOT NULL PRIMARY KEY,
  purchase_id INT NOT NULL,
  purchase_date DATETIME NOT NULL,
  status VARCHAR(10) NOT NULL
);

CREATE TEMPORARY TABLE expanded_sales_orders (
  sale_no INT NOT NULL PRIMARY KEY,
  sale_id INT NOT NULL,
  sale_date DATETIME NOT NULL,
  status VARCHAR(10) NOT NULL
);

INSERT INTO products
  (sku, product_name, category_id, supplier_id, cost_price, selling_price, stock_quantity, reorder_level)
SELECT
  ps.sku,
  ps.product_name,
  c.category_id,
  s.supplier_id,
  ps.cost_price,
  ps.selling_price,
  0,
  ps.reorder_level
FROM expanded_product_stage ps
JOIN categories c ON c.category_name = ps.category_name
JOIN expanded_supplier_stage ss ON ss.supplier_no = ps.supplier_no
JOIN suppliers s ON s.phone = ss.phone
WHERE NOT EXISTS (
  SELECT 1 FROM products p WHERE p.sku = ps.sku
);

INSERT INTO expanded_products (product_no, product_id, cost_price, selling_price)
SELECT ps.product_no, p.product_id, p.cost_price, p.selling_price
FROM expanded_product_stage ps
JOIN products p ON p.sku = ps.sku;

INSERT INTO purchase_orders (supplier_id, purchase_date, status, total_amount)
SELECT ps.supplier_id, ps.purchase_date, ps.status, 0.00
FROM expanded_purchase_stage ps
WHERE NOT EXISTS (
  SELECT 1
  FROM purchase_orders po
  WHERE po.supplier_id = ps.supplier_id
    AND po.purchase_date = ps.purchase_date
);

INSERT INTO expanded_purchase_orders (purchase_no, purchase_id, purchase_date, status)
SELECT ps.purchase_no, po.purchase_id, ps.purchase_date, ps.status
FROM expanded_purchase_stage ps
JOIN purchase_orders po
  ON po.purchase_date = ps.purchase_date
 AND po.supplier_id = ps.supplier_id;

INSERT INTO purchase_items (purchase_id, product_id, quantity, unit_cost)
SELECT
  epo.purchase_id,
  ep.product_id,
  18 + MOD(epo.purchase_no * 7 + item.slot_no * 3, 15),
  ep.cost_price
FROM expanded_purchase_orders epo
CROSS JOIN (
  SELECT 1 AS slot_no
  UNION ALL SELECT 2
  UNION ALL SELECT 3
) AS item
JOIN expanded_products ep
  ON ep.product_no = MOD((epo.purchase_no - 1) * 3 + item.slot_no * 7, 60) + 1
WHERE NOT EXISTS (
  SELECT 1
  FROM purchase_items pi
  WHERE pi.purchase_id = epo.purchase_id
    AND pi.product_id = ep.product_id
);

UPDATE purchase_orders po
JOIN expanded_purchase_orders epo ON epo.purchase_id = po.purchase_id
JOIN (
  SELECT purchase_id, SUM(quantity * unit_cost) AS total_amount
  FROM purchase_items
  GROUP BY purchase_id
) AS totals ON totals.purchase_id = po.purchase_id
SET po.total_amount = totals.total_amount;

INSERT INTO sales_orders (customer_id, sale_date, status, total_amount)
SELECT ss.customer_id, ss.sale_date, ss.status, 0.00
FROM expanded_sales_stage ss
WHERE NOT EXISTS (
  SELECT 1
  FROM sales_orders so
  WHERE so.customer_id = ss.customer_id
    AND so.sale_date = ss.sale_date
);

INSERT INTO expanded_sales_orders (sale_no, sale_id, sale_date, status)
SELECT ss.sale_no, so.sale_id, ss.sale_date, ss.status
FROM expanded_sales_stage ss
JOIN sales_orders so
  ON so.sale_date = ss.sale_date
 AND so.customer_id = ss.customer_id;

INSERT INTO sales_items (sale_id, product_id, quantity, unit_price, unit_cost)
SELECT
  eso.sale_id,
  ep.product_id,
  1 + MOD(eso.sale_no + item.slot_no, 3),
  ep.selling_price,
  ep.cost_price
FROM expanded_sales_orders eso
CROSS JOIN (
  SELECT 1 AS slot_no
  UNION ALL SELECT 2
  UNION ALL SELECT 3
) AS item
JOIN expanded_products ep
  ON ep.product_no = CASE item.slot_no
    WHEN 1 THEN MOD(eso.sale_no * 7, 12) + 1
    WHEN 2 THEN MOD(eso.sale_no * 5, 18) + 13
    ELSE MOD(eso.sale_no * 11, 30) + 31
  END
WHERE NOT EXISTS (
  SELECT 1
  FROM sales_items si
  WHERE si.sale_id = eso.sale_id
    AND si.product_id = ep.product_id
);

UPDATE sales_orders so
JOIN expanded_sales_orders eso ON eso.sale_id = so.sale_id
JOIN (
  SELECT sale_id, SUM(quantity * unit_price) AS total_amount
  FROM sales_items
  GROUP BY sale_id
) AS totals ON totals.sale_id = so.sale_id
SET so.total_amount = totals.total_amount;

INSERT INTO payments (sale_id, purchase_id, amount, payment_method, payment_date)
SELECT
  NULL,
  epo.purchase_id,
  ROUND(po.total_amount * (0.65 + MOD(epo.purchase_no, 4) * 0.10), 2),
  ELT(MOD(epo.purchase_no - 1, 4) + 1, 'Cash', 'UPI', 'Card', 'Bank Transfer'),
  DATE_ADD(epo.purchase_date, INTERVAL 1 DAY)
FROM expanded_purchase_orders epo
JOIN purchase_orders po ON po.purchase_id = epo.purchase_id
WHERE epo.status = 'Received'
  AND NOT EXISTS (
    SELECT 1
    FROM payments p
    WHERE p.purchase_id = epo.purchase_id
      AND p.payment_date = DATE_ADD(epo.purchase_date, INTERVAL 1 DAY)
  );

INSERT INTO payments (sale_id, purchase_id, amount, payment_method, payment_date)
SELECT
  eso.sale_id,
  NULL,
  so.total_amount,
  ELT(MOD(eso.sale_no - 1, 4) + 1, 'Cash', 'UPI', 'Card', 'Bank Transfer'),
  DATE_ADD(eso.sale_date, INTERVAL 2 MINUTE)
FROM expanded_sales_orders eso
JOIN sales_orders so ON so.sale_id = eso.sale_id
WHERE eso.status = 'Completed'
  AND NOT EXISTS (
    SELECT 1
    FROM payments p
    WHERE p.sale_id = eso.sale_id
      AND p.payment_date = DATE_ADD(eso.sale_date, INTERVAL 2 MINUTE)
  );

INSERT INTO stock_movements
  (product_id, movement_type, quantity_change, movement_date, notes)
SELECT ep.product_id, 'Opening', 0, '2025-11-01 08:00:00', 'Expanded dataset opening balance'
FROM expanded_products ep
WHERE NOT EXISTS (
  SELECT 1
  FROM stock_movements sm
  WHERE sm.product_id = ep.product_id
    AND sm.movement_type = 'Opening'
    AND sm.movement_date = '2025-11-01 08:00:00'
    AND sm.notes = 'Expanded dataset opening balance'
);

INSERT INTO stock_movements
  (product_id, movement_type, quantity_change, movement_date, notes)
SELECT
  pi.product_id,
  'Purchase',
  pi.quantity,
  DATE_ADD(epo.purchase_date, INTERVAL 30 MINUTE),
  CONCAT('Received expanded purchase #', epo.purchase_id)
FROM expanded_purchase_orders epo
JOIN purchase_orders po ON po.purchase_id = epo.purchase_id AND po.status = 'Received'
JOIN purchase_items pi ON pi.purchase_id = epo.purchase_id
WHERE NOT EXISTS (
  SELECT 1
  FROM stock_movements sm
  WHERE sm.product_id = pi.product_id
    AND sm.movement_type = 'Purchase'
    AND sm.movement_date = DATE_ADD(epo.purchase_date, INTERVAL 30 MINUTE)
    AND sm.notes = CONCAT('Received expanded purchase #', epo.purchase_id)
);

INSERT INTO stock_movements
  (product_id, movement_type, quantity_change, movement_date, notes)
SELECT
  si.product_id,
  'Sale',
  -si.quantity,
  eso.sale_date,
  CONCAT('Completed expanded sale #', eso.sale_id)
FROM expanded_sales_orders eso
JOIN sales_orders so ON so.sale_id = eso.sale_id AND so.status = 'Completed'
JOIN sales_items si ON si.sale_id = eso.sale_id
WHERE NOT EXISTS (
  SELECT 1
  FROM stock_movements sm
  WHERE sm.product_id = si.product_id
    AND sm.movement_type = 'Sale'
    AND sm.movement_date = eso.sale_date
    AND sm.notes = CONCAT('Completed expanded sale #', eso.sale_id)
);

INSERT INTO stock_movements
  (product_id, movement_type, quantity_change, movement_date, notes)
SELECT
  ep.product_id,
  'Adjustment',
  target.target_quantity - COALESCE(SUM(sm.quantity_change), 0),
  '2026-10-31 18:00:00',
  'Expanded dataset cycle-count adjustment'
FROM expanded_products ep
LEFT JOIN stock_movements sm
  ON sm.product_id = ep.product_id
 AND sm.notes <> 'Expanded dataset cycle-count adjustment'
JOIN (
  SELECT 55 AS product_no, 2 AS target_quantity
  UNION ALL SELECT 56, 3
  UNION ALL SELECT 57, 2
  UNION ALL SELECT 58, 4
  UNION ALL SELECT 59, 2
  UNION ALL SELECT 60, 3
) AS target ON target.product_no = ep.product_no
WHERE NOT EXISTS (
  SELECT 1
  FROM stock_movements existing
  WHERE existing.product_id = ep.product_id
    AND existing.movement_type = 'Adjustment'
    AND existing.movement_date = '2026-10-31 18:00:00'
    AND existing.notes = 'Expanded dataset cycle-count adjustment'
)
GROUP BY ep.product_id, target.target_quantity;

UPDATE products p
JOIN expanded_products ep ON ep.product_id = p.product_id
LEFT JOIN (
  SELECT product_id, SUM(quantity_change) AS movement_balance
  FROM stock_movements
  GROUP BY product_id
) AS balances ON balances.product_id = p.product_id
SET p.stock_quantity = COALESCE(balances.movement_balance, 0);

COMMIT;

-- Verification: overall row counts
SELECT 'categories' AS table_name, COUNT(*) AS total_rows FROM categories
UNION ALL SELECT 'suppliers', COUNT(*) FROM suppliers
UNION ALL SELECT 'customers', COUNT(*) FROM customers
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'purchases', COUNT(*) FROM purchase_orders
UNION ALL SELECT 'sales', COUNT(*) FROM sales_orders
UNION ALL SELECT 'payments', COUNT(*) FROM payments;

-- Verification: products at or below their reorder threshold
SELECT product_id, sku, product_name, stock_quantity, reorder_level
FROM products
WHERE stock_quantity <= reorder_level
ORDER BY stock_quantity, product_name;

-- Verification: top 10 products by units sold on completed sales
SELECT p.sku, p.product_name, SUM(si.quantity) AS units_sold
FROM sales_items si
JOIN sales_orders so ON so.sale_id = si.sale_id AND so.status = 'Completed'
JOIN products p ON p.product_id = si.product_id
GROUP BY p.product_id, p.sku, p.product_name
ORDER BY units_sold DESC, p.product_name
LIMIT 10;

-- Verification: monthly completed-sale revenue
SELECT DATE_FORMAT(so.sale_date, '%Y-%m') AS sales_month,
       SUM(si.quantity * si.unit_price) AS revenue_inr
FROM sales_orders so
JOIN sales_items si ON si.sale_id = so.sale_id
WHERE so.status = 'Completed'
GROUP BY DATE_FORMAT(so.sale_date, '%Y-%m')
ORDER BY sales_month;

-- Verification: monthly gross profit (revenue less recorded item cost)
SELECT DATE_FORMAT(so.sale_date, '%Y-%m') AS sales_month,
       SUM(si.quantity * (si.unit_price - si.unit_cost)) AS gross_profit_inr
FROM sales_orders so
JOIN sales_items si ON si.sale_id = so.sale_id
WHERE so.status = 'Completed'
GROUP BY DATE_FORMAT(so.sale_date, '%Y-%m')
ORDER BY sales_month;

-- Verification: product stock against the complete movement ledger
SELECT p.product_id, p.sku, p.product_name, p.stock_quantity,
       COALESCE(SUM(sm.quantity_change), 0) AS movement_balance,
       p.stock_quantity - COALESCE(SUM(sm.quantity_change), 0) AS difference
FROM products p
LEFT JOIN stock_movements sm ON sm.product_id = p.product_id
GROUP BY p.product_id, p.sku, p.product_name, p.stock_quantity
ORDER BY p.product_id;

-- Verification: foreign-key orphan counts (each result should be zero)
SELECT 'products.category_id' AS relation_name, COUNT(*) AS orphan_rows
FROM products p LEFT JOIN categories c ON c.category_id = p.category_id
WHERE c.category_id IS NULL
UNION ALL
SELECT 'products.supplier_id', COUNT(*)
FROM products p LEFT JOIN suppliers s ON s.supplier_id = p.supplier_id
WHERE s.supplier_id IS NULL
UNION ALL
SELECT 'purchase_orders.supplier_id', COUNT(*)
FROM purchase_orders po LEFT JOIN suppliers s ON s.supplier_id = po.supplier_id
WHERE s.supplier_id IS NULL
UNION ALL
SELECT 'purchase_items.purchase_id', COUNT(*)
FROM purchase_items pi LEFT JOIN purchase_orders po ON po.purchase_id = pi.purchase_id
WHERE po.purchase_id IS NULL
UNION ALL
SELECT 'purchase_items.product_id', COUNT(*)
FROM purchase_items pi LEFT JOIN products p ON p.product_id = pi.product_id
WHERE p.product_id IS NULL
UNION ALL
SELECT 'sales_orders.customer_id', COUNT(*)
FROM sales_orders so LEFT JOIN customers c ON c.customer_id = so.customer_id
WHERE so.customer_id IS NOT NULL AND c.customer_id IS NULL
UNION ALL
SELECT 'sales_items.sale_id', COUNT(*)
FROM sales_items si LEFT JOIN sales_orders so ON so.sale_id = si.sale_id
WHERE so.sale_id IS NULL
UNION ALL
SELECT 'sales_items.product_id', COUNT(*)
FROM sales_items si LEFT JOIN products p ON p.product_id = si.product_id
WHERE p.product_id IS NULL
UNION ALL
SELECT 'payments.sale_id', COUNT(*)
FROM payments py LEFT JOIN sales_orders so ON so.sale_id = py.sale_id
WHERE py.sale_id IS NOT NULL AND so.sale_id IS NULL
UNION ALL
SELECT 'payments.purchase_id', COUNT(*)
FROM payments py LEFT JOIN purchase_orders po ON po.purchase_id = py.purchase_id
WHERE py.purchase_id IS NOT NULL AND po.purchase_id IS NULL
UNION ALL
SELECT 'stock_movements.product_id', COUNT(*)
FROM stock_movements sm LEFT JOIN products p ON p.product_id = sm.product_id
WHERE p.product_id IS NULL
UNION ALL
SELECT 'payments.order_reference', COUNT(*)
FROM payments py
WHERE (py.sale_id IS NULL AND py.purchase_id IS NULL)
   OR (py.sale_id IS NOT NULL AND py.purchase_id IS NOT NULL);
