-- MySQL Schema for SmartStock Inventory Management System
-- Database: smartstock

CREATE DATABASE IF NOT EXISTS smartstock;
USE smartstock;

-- 1. Categories
CREATE TABLE IF NOT EXISTS categories (
  category_id INT NOT NULL AUTO_INCREMENT,
  category_name VARCHAR(100) NOT NULL,
  description VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (category_id),
  UNIQUE KEY uq_category_name (category_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 2. Suppliers
CREATE TABLE IF NOT EXISTS suppliers (
  supplier_id INT NOT NULL AUTO_INCREMENT,
  supplier_name VARCHAR(150) NOT NULL,
  phone VARCHAR(20) DEFAULT NULL,
  email VARCHAR(150) DEFAULT NULL,
  address VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (supplier_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 3. Customers
CREATE TABLE IF NOT EXISTS customers (
  customer_id INT NOT NULL AUTO_INCREMENT,
  customer_name VARCHAR(150) NOT NULL,
  phone VARCHAR(20) DEFAULT NULL,
  email VARCHAR(150) DEFAULT NULL,
  address VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (customer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 4. Products
CREATE TABLE IF NOT EXISTS products (
  product_id INT NOT NULL AUTO_INCREMENT,
  sku VARCHAR(50) NOT NULL,
  product_name VARCHAR(150) NOT NULL,
  category_id INT NOT NULL,
  supplier_id INT NOT NULL,
  cost_price DECIMAL(10,2) NOT NULL,
  selling_price DECIMAL(10,2) NOT NULL,
  stock_quantity INT NOT NULL DEFAULT 0,
  reorder_level INT NOT NULL DEFAULT 5,
  PRIMARY KEY (product_id),
  UNIQUE KEY uq_product_sku (sku),
  KEY idx_category_id (category_id),
  KEY idx_supplier_id (supplier_id),
  CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories (category_id),
  CONSTRAINT fk_products_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers (supplier_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 5. Purchase Orders
CREATE TABLE IF NOT EXISTS purchase_orders (
  purchase_id INT NOT NULL AUTO_INCREMENT,
  supplier_id INT NOT NULL,
  purchase_date DATETIME NOT NULL,
  status ENUM('Pending', 'Received', 'Cancelled') NOT NULL DEFAULT 'Pending',
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (purchase_id),
  KEY idx_purchase_supplier (supplier_id),
  CONSTRAINT fk_purchase_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers (supplier_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 6. Purchase Items
CREATE TABLE IF NOT EXISTS purchase_items (
  purchase_item_id INT NOT NULL AUTO_INCREMENT,
  purchase_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  unit_cost DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (purchase_item_id),
  KEY idx_purchase_id (purchase_id),
  KEY idx_purchase_product (product_id),
  CONSTRAINT fk_purchase_items_order FOREIGN KEY (purchase_id) REFERENCES purchase_orders (purchase_id),
  CONSTRAINT fk_purchase_items_product FOREIGN KEY (product_id) REFERENCES products (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 7. Sales Orders
CREATE TABLE IF NOT EXISTS sales_orders (
  sale_id INT NOT NULL AUTO_INCREMENT,
  customer_id INT DEFAULT NULL,
  sale_date DATETIME NOT NULL,
  status ENUM('Completed', 'Cancelled', 'Pending') NOT NULL DEFAULT 'Pending',
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (sale_id),
  KEY idx_sales_customer (customer_id),
  CONSTRAINT fk_sales_customer FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 8. Sales Items
CREATE TABLE IF NOT EXISTS sales_items (
  sale_item_id INT NOT NULL AUTO_INCREMENT,
  sale_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  unit_cost DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (sale_item_id),
  KEY idx_sales_id (sale_id),
  KEY idx_sales_product (product_id),
  CONSTRAINT fk_sales_items_order FOREIGN KEY (sale_id) REFERENCES sales_orders (sale_id),
  CONSTRAINT fk_sales_items_product FOREIGN KEY (product_id) REFERENCES products (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 9. Payments
CREATE TABLE IF NOT EXISTS payments (
  payment_id INT NOT NULL AUTO_INCREMENT,
  sale_id INT DEFAULT NULL,
  purchase_id INT DEFAULT NULL,
  amount DECIMAL(12,2) NOT NULL,
  payment_method VARCHAR(50) NOT NULL,
  payment_date DATETIME NOT NULL,
  PRIMARY KEY (payment_id),
  KEY idx_payments_sale (sale_id),
  KEY idx_payments_purchase (purchase_id),
  CONSTRAINT fk_payments_sale FOREIGN KEY (sale_id) REFERENCES sales_orders (sale_id),
  CONSTRAINT fk_payments_purchase FOREIGN KEY (purchase_id) REFERENCES purchase_orders (purchase_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 10. Stock Movements
CREATE TABLE IF NOT EXISTS stock_movements (
  movement_id INT NOT NULL AUTO_INCREMENT,
  product_id INT NOT NULL,
  movement_type ENUM('Opening', 'Purchase', 'Sale', 'Adjustment', 'Return') NOT NULL,
  quantity_change INT NOT NULL,
  movement_date DATETIME NOT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (movement_id),
  KEY idx_movement_product (product_id),
  CONSTRAINT fk_movement_product FOREIGN KEY (product_id) REFERENCES products (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
