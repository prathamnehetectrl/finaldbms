const path = require('path');
const express = require('express');
const app = express();

// CORS Middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

app.use(express.json());

// API Routes
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/products', require('./routes/products'));
app.use('/api/categories', require('./routes/categories'));
app.use('/api/suppliers', require('./routes/suppliers'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/purchases', require('./routes/purchases'));
app.use('/api/sales', require('./routes/sales'));
app.use('/api/payments', require('./routes/payments'));
app.use('/api/stock-movements', require('./routes/movements'));
app.use('/api/bi', require('./routes/bi'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/system', require('./routes/system'));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'SmartStock API' });
});

// Serve frontend static assets from client/dist
const distPath = path.resolve(__dirname, '../client/dist');
app.use(express.static(distPath));

// Fallback to frontend index.html for client-side routing
app.use((req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

module.exports = app;
