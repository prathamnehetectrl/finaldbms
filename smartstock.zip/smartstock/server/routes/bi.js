const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', async (req, res) => {
  try {
    // 1. Best Selling Products
    const [bestSelling] = await db.query(`
      SELECT 
        p.product_id,
        p.sku,
        p.product_name,
        c.category_name,
        COALESCE(SUM(si.quantity), 0) AS total_sold,
        ROUND(COALESCE(SUM(si.quantity * si.unit_price), 0), 2) AS total_revenue
      FROM products p
      JOIN categories c ON p.category_id = c.category_id
      LEFT JOIN sales_items si ON p.product_id = si.product_id
      LEFT JOIN sales_orders so ON si.sale_id = so.sale_id AND so.status = 'Completed'
      GROUP BY p.product_id, p.sku, p.product_name, c.category_name
      ORDER BY total_sold DESC
      LIMIT 5
    `);

    // 2. Highest Revenue Categories
    const [topCategories] = await db.query(`
      SELECT 
        c.category_name,
        ROUND(COALESCE(SUM(si.quantity * si.unit_price), 0), 2) AS revenue,
        COALESCE(SUM(si.quantity), 0) AS units_sold,
        COUNT(DISTINCT p.product_id) AS product_count
      FROM categories c
      LEFT JOIN products p ON c.category_id = p.category_id
      LEFT JOIN sales_items si ON p.product_id = si.product_id
      LEFT JOIN sales_orders so ON si.sale_id = so.sale_id AND so.status = 'Completed'
      GROUP BY c.category_id, c.category_name
      ORDER BY revenue DESC
    `);

    // 3. Most Profitable Products
    const [mostProfitable] = await db.query(`
      SELECT 
        p.product_id,
        p.product_name,
        p.sku,
        p.cost_price,
        p.selling_price,
        ROUND(p.selling_price - p.cost_price, 2) AS unit_margin,
        ROUND(((p.selling_price - p.cost_price) / p.selling_price) * 100, 1) AS margin_percentage,
        ROUND(COALESCE(SUM((si.unit_price - si.unit_cost) * si.quantity), 0), 2) AS total_profit_generated
      FROM products p
      LEFT JOIN sales_items si ON p.product_id = si.product_id
      LEFT JOIN sales_orders so ON si.sale_id = so.sale_id AND so.status = 'Completed'
      GROUP BY p.product_id, p.product_name, p.sku, p.cost_price, p.selling_price
      ORDER BY total_profit_generated DESC
      LIMIT 5
    `);

    // 4. Low-Stock Recommendations
    const [lowStockRecommendations] = await db.query(`
      SELECT 
        p.product_id,
        p.sku,
        p.product_name,
        p.stock_quantity,
        p.reorder_level,
        (p.reorder_level * 2 - p.stock_quantity) AS recommended_reorder_qty,
        s.supplier_name,
        s.phone AS supplier_phone,
        ROUND((p.reorder_level * 2 - p.stock_quantity) * p.cost_price, 2) AS estimated_cost
      FROM products p
      JOIN suppliers s ON p.supplier_id = s.supplier_id
      WHERE p.stock_quantity <= p.reorder_level
      ORDER BY p.stock_quantity ASC
    `);

    // 5. Slow-Moving Inventory (products with stock but lowest or 0 sales)
    const [slowMoving] = await db.query(`
      SELECT 
        p.product_id,
        p.sku,
        p.product_name,
        p.stock_quantity,
        ROUND(p.stock_quantity * p.cost_price, 2) AS tied_capital,
        COALESCE(SUM(si.quantity), 0) AS units_sold,
        MAX(so.sale_date) AS last_sold_date
      FROM products p
      LEFT JOIN sales_items si ON p.product_id = si.product_id
      LEFT JOIN sales_orders so ON si.sale_id = so.sale_id AND so.status = 'Completed'
      WHERE p.stock_quantity > 0
      GROUP BY p.product_id, p.sku, p.product_name, p.stock_quantity, p.cost_price
      ORDER BY units_sold ASC, tied_capital DESC
      LIMIT 5
    `);

    // 6. Supplier Purchasing Share
    const [supplierAnalysis] = await db.query(`
      SELECT 
        s.supplier_name,
        COUNT(DISTINCT po.purchase_id) AS orders_count,
        ROUND(COALESCE(SUM(po.total_amount), 0), 2) AS total_purchased
      FROM suppliers s
      LEFT JOIN purchase_orders po ON s.supplier_id = po.supplier_id AND po.status = 'Received'
      GROUP BY s.supplier_id, s.supplier_name
      ORDER BY total_purchased DESC
    `);

    // 7. Customer Purchasing Patterns (Top spenders)
    const [customerPatterns] = await db.query(`
      SELECT 
        c.customer_name,
        COUNT(so.sale_id) AS orders_count,
        ROUND(COALESCE(SUM(so.total_amount), 0), 2) AS total_spent,
        ROUND(AVG(so.total_amount), 2) AS average_order_value
      FROM customers c
      JOIN sales_orders so ON c.customer_id = so.customer_id
      WHERE so.status = 'Completed'
      GROUP BY c.customer_id, c.customer_name
      ORDER BY total_spent DESC
      LIMIT 5
    `);

    // 8. Generate dynamic, rule-based business insights from the real SQL data!
    const insights = [];

    // Insight 1: Low stock replenishment
    if (lowStockRecommendations.length > 0) {
      const topLow = lowStockRecommendations[0];
      insights.push({
        type: 'critical',
        title: 'Critical Stock Alert',
        metric: `${lowStockRecommendations.length} products below reorder level`,
        explanation: `"${topLow.product_name}" currently has ${topLow.stock_quantity} units remaining (reorder threshold is ${topLow.reorder_level}).`,
        action: `Contact supplier ${topLow.supplier_name} to place purchase order for ~${topLow.recommended_reorder_qty} units.`
      });
    }

    // Insight 2: Top revenue category
    if (topCategories.length > 0) {
      const topCat = topCategories[0];
      insights.push({
        type: 'success',
        title: 'Leading Revenue Driver',
        metric: `₹${Number(topCat.revenue).toLocaleString('en-IN')}`,
        explanation: `"${topCat.category_name}" generates the highest sales revenue across the catalogue with ${topCat.units_sold} units sold.`,
        action: `Maintain strong supplier relationships for ${topCat.category_name} accessories to avoid stockouts.`
      });
    }

    // Insight 3: Capital locked in slow moving stock
    if (slowMoving.length > 0) {
      const topSlow = slowMoving[0];
      insights.push({
        type: 'warning',
        title: 'Capital Concentration Risk',
        metric: `₹${Number(topSlow.tied_capital).toLocaleString('en-IN')} locked`,
        explanation: `"${topSlow.product_name}" has ${topSlow.stock_quantity} units in storage with low historical movement velocity.`,
        action: `Consider promotional bundling or discount pricing to accelerate turnover and release working capital.`
      });
    }

    // Insight 4: Margin Leader
    if (mostProfitable.length > 0) {
      const bestMargin = mostProfitable[0];
      insights.push({
        type: 'info',
        title: 'High-Margin Champion',
        metric: `${bestMargin.margin_percentage}% margin`,
        explanation: `"${bestMargin.product_name}" yields ₹${bestMargin.unit_margin} gross profit per unit sold.`,
        action: `Increase promotional placement on dashboard and POS checkout to maximize bottom-line profit.`
      });
    }

    res.json({
      bestSelling,
      topCategories,
      mostProfitable,
      lowStockRecommendations,
      slowMoving,
      supplierAnalysis,
      customerPatterns,
      insights
    });
  } catch (error) {
    console.error('BI API Error:', error);
    res.status(500).json({ error: 'Failed to generate BI insights', message: error.message });
  }
});

module.exports = router;
