const express = require('express');
const router = express.Router();
const db = require('../db');

// GET all categories
router.get('/', async (req, res) => {
  try {
    const [categories] = await db.query(`
      SELECT 
        c.category_id,
        c.category_name,
        c.description,
        COUNT(p.product_id) AS product_count,
        COALESCE(SUM(p.stock_quantity), 0) AS total_units,
        ROUND(COALESCE(SUM(p.stock_quantity * p.cost_price), 0), 2) AS total_value
      FROM categories c
      LEFT JOIN products p ON c.category_id = p.category_id
      GROUP BY c.category_id, c.category_name, c.description
      ORDER BY c.category_id ASC
    `);
    res.json(categories);
  } catch (error) {
    console.error('Categories GET Error:', error);
    res.status(500).json({ error: 'Failed to fetch categories', message: error.message });
  }
});

// POST add category
router.post('/', async (req, res) => {
  const { category_name, description } = req.body;
  if (!category_name || !category_name.trim()) {
    return res.status(400).json({ error: 'Category name is required' });
  }

  try {
    const [existing] = await db.query('SELECT category_id FROM categories WHERE category_name = ?', [category_name.trim()]);
    if (existing.length > 0) {
      return res.status(400).json({ error: 'A category with this name already exists' });
    }

    const [result] = await db.query(`
      INSERT INTO categories (category_name, description) VALUES (?, ?)
    `, [category_name.trim(), description ? description.trim() : null]);

    res.status(201).json({ message: 'Category created successfully', category_id: result.insertId });
  } catch (error) {
    console.error('Categories POST Error:', error);
    res.status(500).json({ error: 'Failed to create category', message: error.message });
  }
});

// PUT update category
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { category_name, description } = req.body;

  if (!category_name || !category_name.trim()) {
    return res.status(400).json({ error: 'Category name is required' });
  }

  try {
    const [existing] = await db.query('SELECT category_id FROM categories WHERE category_name = ? AND category_id != ?', [category_name.trim(), id]);
    if (existing.length > 0) {
      return res.status(400).json({ error: 'Another category already has this name' });
    }

    const [result] = await db.query(`
      UPDATE categories SET category_name = ?, description = ? WHERE category_id = ?
    `, [category_name.trim(), description ? description.trim() : null, id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Category not found' });
    }

    res.json({ message: 'Category updated successfully' });
  } catch (error) {
    console.error('Categories PUT Error:', error);
    res.status(500).json({ error: 'Failed to update category', message: error.message });
  }
});

// DELETE category
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [[productCount]] = await db.query('SELECT COUNT(*) AS c FROM products WHERE category_id = ?', [id]);
    if (productCount.c > 0) {
      return res.status(400).json({
        error: `Cannot delete category: ${productCount.c} product(s) are currently assigned to it. Please reassign or delete them first.`
      });
    }

    const [result] = await db.query('DELETE FROM categories WHERE category_id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Category not found' });
    }

    res.json({ message: 'Category deleted successfully' });
  } catch (error) {
    console.error('Categories DELETE Error:', error);
    res.status(500).json({ error: 'Failed to delete category', message: error.message });
  }
});

module.exports = router;
