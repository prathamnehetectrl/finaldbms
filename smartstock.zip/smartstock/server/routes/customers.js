const express = require('express');
const router = express.Router();
const db = require('../db');

// GET all customers
router.get('/', async (req, res) => {
  try {
    const [customers] = await db.query(`
      SELECT 
        c.customer_id,
        c.customer_name,
        c.phone,
        c.email,
        c.address,
        COUNT(so.sale_id) AS total_orders,
        ROUND(COALESCE(SUM(CASE WHEN so.status = 'Completed' THEN so.total_amount ELSE 0 END), 0), 2) AS total_spent
      FROM customers c
      LEFT JOIN sales_orders so ON c.customer_id = so.customer_id
      GROUP BY c.customer_id, c.customer_name, c.phone, c.email, c.address
      ORDER BY c.customer_id ASC
    `);
    res.json(customers);
  } catch (error) {
    console.error('Customers GET Error:', error);
    res.status(500).json({ error: 'Failed to fetch customers', message: error.message });
  }
});

// GET customer details with sales orders
router.get('/:id', async (req, res) => {
  try {
    const [[customer]] = await db.query('SELECT * FROM customers WHERE customer_id = ?', [req.params.id]);
    if (!customer) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    const [orders] = await db.query(`
      SELECT sale_id, sale_date, status, total_amount 
      FROM sales_orders 
      WHERE customer_id = ? 
      ORDER BY sale_date DESC
    `, [req.params.id]);

    res.json({
      ...customer,
      orders
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch customer details', message: error.message });
  }
});

// POST add customer
router.post('/', async (req, res) => {
  const { customer_name, phone, email, address } = req.body;
  if (!customer_name || !customer_name.trim()) {
    return res.status(400).json({ error: 'Customer name is required' });
  }

  try {
    const [result] = await db.query(`
      INSERT INTO customers (customer_name, phone, email, address) VALUES (?, ?, ?, ?)
    `, [customer_name.trim(), phone || null, email || null, address || null]);

    res.status(201).json({ message: 'Customer created successfully', customer_id: result.insertId });
  } catch (error) {
    console.error('Customers POST Error:', error);
    res.status(500).json({ error: 'Failed to create customer', message: error.message });
  }
});

// PUT update customer
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { customer_name, phone, email, address } = req.body;

  if (!customer_name || !customer_name.trim()) {
    return res.status(400).json({ error: 'Customer name is required' });
  }

  try {
    const [result] = await db.query(`
      UPDATE customers SET customer_name = ?, phone = ?, email = ?, address = ? WHERE customer_id = ?
    `, [customer_name.trim(), phone || null, email || null, address || null, id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.json({ message: 'Customer updated successfully' });
  } catch (error) {
    console.error('Customers PUT Error:', error);
    res.status(500).json({ error: 'Failed to update customer', message: error.message });
  }
});

// DELETE customer
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [[orderCount]] = await db.query('SELECT COUNT(*) AS c FROM sales_orders WHERE customer_id = ?', [id]);
    if (orderCount.c > 0) {
      return res.status(400).json({
        error: `Cannot delete customer: customer has ${orderCount.c} existing sales orders.`
      });
    }

    const [result] = await db.query('DELETE FROM customers WHERE customer_id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Customer not found' });
    }

    res.json({ message: 'Customer deleted successfully' });
  } catch (error) {
    console.error('Customers DELETE Error:', error);
    res.status(500).json({ error: 'Failed to delete customer', message: error.message });
  }
});

module.exports = router;
