const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', async (req, res) => {
  try {
    // 1. Summary Metrics
    const [[productsData]] = await db.query(`
      SELECT 
        COUNT(*) AS total_products,
        COALESCE(SUM(stock_quantity), 0) AS total_units,
        COALESCE(SUM(stock_quantity * cost_price), 0) AS inventory_value
      FROM products
    `);

    const [[salesData]] = await db.query(`
      SELECT 
        COALESCE(SUM(total_amount), 0) AS total_revenue,
        COUNT(*) AS completed_sales
      FROM sales_orders 
      WHERE status = 'Completed'
    `);

    const [[profitData]] = await db.query(`
      SELECT 
        COALESCE(SUM((si.unit_price - si.unit_cost) * si.quantity), 0) AS gross_profit
      FROM sales_items si
      JOIN sales_orders so ON si.sale_id = so.sale_id
      WHERE so.status = 'Completed'
    `);

    const [[lowStockData]] = await db.query(`
      SELECT COUNT(*) AS low_stock_count
      FROM products
      WHERE stock_quantity <= reorder_level
    `);

    const [[pendingPurchasesData]] = await db.query(`
      SELECT 
        COUNT(*) AS pending_purchases,
        COALESCE(SUM(total_amount), 0) AS pending_amount
      FROM purchase_orders
      WHERE status = 'Pending'
    `);

    const [[customersData]] = await db.query(`
      SELECT COUNT(*) AS total_customers FROM customers
    `);

    // 2. Monthly Revenue Trend
    const [monthlyRevenue] = await db.query(`
      SELECT 
        DATE_FORMAT(sale_date, '%Y-%m') AS month,
        DATE_FORMAT(sale_date, '%b %Y') AS month_label,
        ROUND(SUM(total_amount), 2) AS revenue
      FROM sales_orders
      WHERE status = 'Completed'
      GROUP BY month, month_label
      ORDER BY month ASC
    `);

    // 3. Revenue vs Profit by month
    const [revenueVsProfit] = await db.query(`
      SELECT 
        DATE_FORMAT(so.sale_date, '%Y-%m') AS month,
        DATE_FORMAT(so.sale_date, '%b') AS month_label,
        ROUND(SUM(so.total_amount), 2) AS revenue,
        ROUND(SUM((si.unit_price - si.unit_cost) * si.quantity), 2) AS profit
      FROM sales_orders so
      JOIN sales_items si ON so.sale_id = si.sale_id
      WHERE so.status = 'Completed'
      GROUP BY month, month_label
      ORDER BY month ASC
    `);

    // 4. Sales by Category
    const [salesByCategory] = await db.query(`
      SELECT 
        c.category_name,
        ROUND(SUM(si.quantity * si.unit_price), 2) AS total_sales,
        SUM(si.quantity) AS units_sold
      FROM sales_items si
      JOIN sales_orders so ON si.sale_id = so.sale_id
      JOIN products p ON si.product_id = p.product_id
      JOIN categories c ON p.category_id = c.category_id
      WHERE so.status = 'Completed'
      GROUP BY c.category_id, c.category_name
      ORDER BY total_sales DESC
    `);

    // 5. Inventory Distribution by Category
    const [inventoryByCategory] = await db.query(`
      SELECT 
        c.category_name,
        SUM(p.stock_quantity) AS total_units,
        ROUND(SUM(p.stock_quantity * p.cost_price), 2) AS total_value
      FROM products p
      JOIN categories c ON p.category_id = c.category_id
      GROUP BY c.category_id, c.category_name
      ORDER BY total_units DESC
    `);

    // 6. Top-Selling Products
    const [topProducts] = await db.query(`
      SELECT 
        p.product_id,
        p.product_name,
        p.sku,
        SUM(si.quantity) AS units_sold,
        ROUND(SUM(si.quantity * si.unit_price), 2) AS total_revenue
      FROM sales_items si
      JOIN sales_orders so ON si.sale_id = so.sale_id
      JOIN products p ON si.product_id = p.product_id
      WHERE so.status = 'Completed'
      GROUP BY p.product_id, p.product_name, p.sku
      ORDER BY units_sold DESC
      LIMIT 5
    `);

    // 7. Purchase vs Sales comparison totals
    const [[purchaseTotals]] = await db.query(`
      SELECT 
        ROUND(COALESCE(SUM(total_amount), 0), 2) AS total_purchases
      FROM purchase_orders 
      WHERE status = 'Received'
    `);

    // 8. Recent Sales Orders
    const [recentSales] = await db.query(`
      SELECT 
        so.sale_id,
        so.sale_date,
        so.status,
        so.total_amount,
        COALESCE(c.customer_name, 'Walk-in Customer') AS customer_name
      FROM sales_orders so
      LEFT JOIN customers c ON so.customer_id = c.customer_id
      ORDER BY so.sale_date DESC
      LIMIT 5
    `);

    // 9. Critical Stock Alerts
    const [lowStockAlerts] = await db.query(`
      SELECT 
        p.product_id,
        p.sku,
        p.product_name,
        p.stock_quantity,
        p.reorder_level,
        c.category_name
      FROM products p
      JOIN categories c ON p.category_id = c.category_id
      WHERE p.stock_quantity <= p.reorder_level
      ORDER BY p.stock_quantity ASC
      LIMIT 6
    `);

    res.json({
      summary: {
        totalProducts: Number(productsData.total_products) || 0,
        totalUnits: Number(productsData.total_units) || 0,
        inventoryCostValue: Number(productsData.inventory_value) || 0,
        totalSalesRevenue: Number(salesData.total_revenue) || 0,
        completedSalesCount: Number(salesData.completed_sales) || 0,
        grossProfit: Number(profitData.gross_profit) || 0,
        lowStockProducts: Number(lowStockData.low_stock_count) || 0,
        pendingPurchases: Number(pendingPurchasesData.pending_purchases) || 0,
        pendingPurchasesAmount: Number(pendingPurchasesData.pending_amount) || 0,
        totalCustomers: Number(customersData.total_customers) || 0,
        totalPurchasesReceived: Number(purchaseTotals.total_purchases) || 0
      },
      charts: {
        monthlyRevenue,
        revenueVsProfit,
        salesByCategory,
        inventoryByCategory,
        topProducts,
        purchasesVsSales: [
          { name: 'Purchases (Received)', value: Number(purchaseTotals.total_purchases) || 0 },
          { name: 'Sales (Completed)', value: Number(salesData.total_revenue) || 0 }
        ]
      },
      recentSales,
      lowStockAlerts
    });
  } catch (error) {
    console.error('Dashboard API Error:', error);
    res.status(500).json({ error: 'Failed to load dashboard data', message: error.message });
  }
});

module.exports = router;
