const express = require('express');
const router = express.Router();
const db = require('../db');

// GET all stock movements
router.get('/', async (req, res) => {
  try {
    const { product_id, type, start_date, end_date } = req.query;
    let query = `
      SELECT 
        sm.movement_id,
        sm.product_id,
        p.sku,
        p.product_name,
        c.category_name,
        sm.movement_type,
        sm.quantity_change,
        sm.movement_date,
        sm.notes
      FROM stock_movements sm
      JOIN products p ON sm.product_id = p.product_id
      JOIN categories c ON p.category_id = c.category_id
      WHERE 1=1
    `;
    const params = [];

    if (product_id) {
      query += ` AND sm.product_id = ?`;
      params.push(product_id);
    }

    if (type) {
      query += ` AND sm.movement_type = ?`;
      params.push(type);
    }

    if (start_date) {
      query += ` AND DATE(sm.movement_date) >= ?`;
      params.push(start_date);
    }

    if (end_date) {
      query += ` AND DATE(sm.movement_date) <= ?`;
      params.push(end_date);
    }

    query += ` ORDER BY sm.movement_date DESC, sm.movement_id DESC`;

    const [movements] = await db.query(query, params);
    res.json(movements);
  } catch (error) {
    console.error('Stock Movements GET Error:', error);
    res.status(500).json({ error: 'Failed to fetch stock movements', message: error.message });
  }
});

// POST record manual stock adjustment / return
router.post('/', async (req, res) => {
  const { product_id, movement_type, quantity_change, notes } = req.body;

  if (!product_id || !movement_type || quantity_change === undefined) {
    return res.status(400).json({ error: 'Product, movement type, and quantity change are required' });
  }

  const qty = Number(quantity_change);
  if (qty === 0) {
    return res.status(400).json({ error: 'Quantity change cannot be 0' });
  }

  if (!['Adjustment', 'Return', 'Opening'].includes(movement_type)) {
    return res.status(400).json({ error: 'Movement type must be Adjustment, Return, or Opening' });
  }

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    const [[prod]] = await conn.query('SELECT stock_quantity, product_name FROM products WHERE product_id = ? FOR UPDATE', [product_id]);
    if (!prod) {
      await conn.rollback();
      return res.status(404).json({ error: 'Product not found' });
    }

    const newStock = Number(prod.stock_quantity) + qty;
    if (newStock < 0) {
      await conn.rollback();
      return res.status(400).json({
        error: `Adjustment would cause negative inventory for "${prod.product_name}". Current: ${prod.stock_quantity}, Change: ${qty}`
      });
    }

    // Update product stock
    await conn.query('UPDATE products SET stock_quantity = ? WHERE product_id = ?', [newStock, product_id]);

    // Insert movement record
    const [result] = await conn.query(`
      INSERT INTO stock_movements (product_id, movement_type, quantity_change, movement_date, notes)
      VALUES (?, ?, ?, NOW(), ?)
    `, [product_id, movement_type, qty, notes || `${movement_type} recorded via dashboard`]);

    await conn.commit();
    res.status(201).json({
      message: 'Stock adjustment recorded successfully',
      movement_id: result.insertId,
      new_stock: newStock
    });
  } catch (error) {
    await conn.rollback();
    console.error('Stock Movements POST Error:', error);
    res.status(500).json({ error: 'Failed to record stock adjustment', message: error.message });
  } finally {
    conn.release();
  }
});

module.exports = router;
