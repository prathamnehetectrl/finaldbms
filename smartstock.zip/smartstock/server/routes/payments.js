const express = require('express');
const router = express.Router();
const db = require('../db');

// GET all payments
router.get('/', async (req, res) => {
  try {
    const { method, type } = req.query;
    let query = `
      SELECT 
        p.payment_id,
        p.sale_id,
        p.purchase_id,
        p.amount,
        p.payment_method,
        p.payment_date,
        CASE 
          WHEN p.sale_id IS NOT NULL THEN 'Customer Sale'
          WHEN p.purchase_id IS NOT NULL THEN 'Supplier Purchase'
          ELSE 'Other'
        END AS payment_type,
        COALESCE(c.customer_name, s.supplier_name, 'General') AS party_name
      FROM payments p
      LEFT JOIN sales_orders so ON p.sale_id = so.sale_id
      LEFT JOIN customers c ON so.customer_id = c.customer_id
      LEFT JOIN purchase_orders po ON p.purchase_id = po.purchase_id
      LEFT JOIN suppliers s ON po.supplier_id = s.supplier_id
      WHERE 1=1
    `;
    const params = [];

    if (method) {
      query += ` AND p.payment_method = ?`;
      params.push(method);
    }

    if (type === 'sale') {
      query += ` AND p.sale_id IS NOT NULL`;
    } else if (type === 'purchase') {
      query += ` AND p.purchase_id IS NOT NULL`;
    }

    query += ` ORDER BY p.payment_date DESC`;

    const [payments] = await db.query(query, params);
    res.json(payments);
  } catch (error) {
    console.error('Payments GET Error:', error);
    res.status(500).json({ error: 'Failed to fetch payments', message: error.message });
  }
});

// POST record payment
router.post('/', async (req, res) => {
  const { sale_id, purchase_id, amount, payment_method } = req.body;

  if (!amount || Number(amount) <= 0 || !payment_method) {
    return res.status(400).json({ error: 'Valid amount > 0 and payment method are required' });
  }

  if (!sale_id && !purchase_id) {
    return res.status(400).json({ error: 'Payment must link to either a sale_id or purchase_id' });
  }

  try {
    const [result] = await db.query(`
      INSERT INTO payments (sale_id, purchase_id, amount, payment_method, payment_date)
      VALUES (?, ?, ?, ?, NOW())
    `, [sale_id || null, purchase_id || null, Number(amount), payment_method]);

    res.status(201).json({ message: 'Payment recorded successfully', payment_id: result.insertId });
  } catch (error) {
    console.error('Payments POST Error:', error);
    res.status(500).json({ error: 'Failed to record payment', message: error.message });
  }
});

module.exports = router;
