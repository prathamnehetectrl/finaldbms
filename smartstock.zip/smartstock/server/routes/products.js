const express = require('express');
const router = express.Router();
const db = require('../db');

// GET all products with filtering & search
router.get('/', async (req, res) => {
  try {
    const { search, category, status } = req.query;
    let query = `
      SELECT 
        p.product_id,
        p.sku,
        p.product_name,
        p.category_id,
        c.category_name,
        p.supplier_id,
        s.supplier_name,
        p.cost_price,
        p.selling_price,
        p.stock_quantity,
        p.reorder_level,
        ROUND(p.stock_quantity * p.cost_price, 2) AS inventory_value
      FROM products p
      JOIN categories c ON p.category_id = c.category_id
      JOIN suppliers s ON p.supplier_id = s.supplier_id
      WHERE 1=1
    `;
    const params = [];

    if (search) {
      query += ` AND (p.product_name LIKE ? OR p.sku LIKE ? OR s.supplier_name LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (category) {
      query += ` AND p.category_id = ?`;
      params.push(category);
    }

    if (status === 'out') {
      query += ` AND p.stock_quantity = 0`;
    } else if (status === 'low') {
      query += ` AND p.stock_quantity > 0 AND p.stock_quantity <= p.reorder_level`;
    } else if (status === 'instock') {
      query += ` AND p.stock_quantity > p.reorder_level`;
    }

    query += ` ORDER BY p.product_id ASC`;

    const [products] = await db.query(query, params);
    res.json(products);
  } catch (error) {
    console.error('Products GET Error:', error);
    res.status(500).json({ error: 'Failed to fetch products', message: error.message });
  }
});

// GET single product
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT 
        p.*,
        c.category_name,
        s.supplier_name
      FROM products p
      JOIN categories c ON p.category_id = c.category_id
      JOIN suppliers s ON p.supplier_id = s.supplier_id
      WHERE p.product_id = ?
    `, [req.params.id]);

    if (!rows.length) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch product details', message: error.message });
  }
});

// POST add new product
router.post('/', async (req, res) => {
  const { sku, product_name, category_id, supplier_id, cost_price, selling_price, stock_quantity, reorder_level } = req.body;

  if (!sku || !product_name || !category_id || !supplier_id || cost_price === undefined || selling_price === undefined) {
    return res.status(400).json({ error: 'Missing required product fields' });
  }

  const cost = Number(cost_price);
  const selling = Number(selling_price);
  const stock = Number(stock_quantity || 0);
  const reorder = Number(reorder_level || 5);

  if (cost < 0 || selling < 0 || stock < 0 || reorder < 0) {
    return res.status(400).json({ error: 'Prices and stock quantities must be non-negative' });
  }

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    // Check duplicate SKU
    const [existing] = await conn.query('SELECT product_id FROM products WHERE sku = ?', [sku.trim()]);
    if (existing.length > 0) {
      await conn.rollback();
      return res.status(400).json({ error: `Product with SKU "${sku}" already exists` });
    }

    const [result] = await conn.query(`
      INSERT INTO products (sku, product_name, category_id, supplier_id, cost_price, selling_price, stock_quantity, reorder_level)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `, [sku.trim(), product_name.trim(), category_id, supplier_id, cost, selling, stock, reorder]);

    const newProductId = result.insertId;

    // Record opening stock movement if stock > 0
    if (stock > 0) {
      await conn.query(`
        INSERT INTO stock_movements (product_id, movement_type, quantity_change, movement_date, notes)
        VALUES (?, 'Opening', ?, NOW(), 'Initial inventory setup')
      `, [newProductId, stock]);
    }

    await conn.commit();
    res.status(201).json({ message: 'Product created successfully', product_id: newProductId });
  } catch (error) {
    await conn.rollback();
    console.error('Products POST Error:', error);
    res.status(500).json({ error: 'Failed to create product', message: error.message });
  } finally {
    conn.release();
  }
});

// PUT update product
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { sku, product_name, category_id, supplier_id, cost_price, selling_price, stock_quantity, reorder_level } = req.body;

  if (!sku || !product_name || !category_id || !supplier_id || cost_price === undefined || selling_price === undefined) {
    return res.status(400).json({ error: 'Missing required product fields' });
  }

  const cost = Number(cost_price);
  const selling = Number(selling_price);
  const stock = Number(stock_quantity || 0);
  const reorder = Number(reorder_level || 5);

  if (cost < 0 || selling < 0 || stock < 0 || reorder < 0) {
    return res.status(400).json({ error: 'Prices and stock quantities must be non-negative' });
  }

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    // Check SKU collision with other products
    const [existing] = await conn.query('SELECT product_id FROM products WHERE sku = ? AND product_id != ?', [sku.trim(), id]);
    if (existing.length > 0) {
      await conn.rollback();
      return res.status(400).json({ error: `SKU "${sku}" is already used by another product` });
    }

    // Get current stock to log adjustment if changed
    const [[current]] = await conn.query('SELECT stock_quantity FROM products WHERE product_id = ?', [id]);
    if (!current) {
      await conn.rollback();
      return res.status(404).json({ error: 'Product not found' });
    }

    const diff = stock - Number(current.stock_quantity);

    await conn.query(`
      UPDATE products 
      SET sku = ?, product_name = ?, category_id = ?, supplier_id = ?, cost_price = ?, selling_price = ?, stock_quantity = ?, reorder_level = ?
      WHERE product_id = ?
    `, [sku.trim(), product_name.trim(), category_id, supplier_id, cost, selling, stock, reorder, id]);

    if (diff !== 0) {
      await conn.query(`
        INSERT INTO stock_movements (product_id, movement_type, quantity_change, movement_date, notes)
        VALUES (?, 'Adjustment', ?, NOW(), 'Manual product edit adjustment')
      `, [id, diff]);
    }

    await conn.commit();
    res.json({ message: 'Product updated successfully' });
  } catch (error) {
    await conn.rollback();
    console.error('Products PUT Error:', error);
    res.status(500).json({ error: 'Failed to update product', message: error.message });
  } finally {
    conn.release();
  }
});

// DELETE product
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    // Check if product is referenced in sales or purchases
    const [[salesCount]] = await db.query('SELECT COUNT(*) AS c FROM sales_items WHERE product_id = ?', [id]);
    const [[purchaseCount]] = await db.query('SELECT COUNT(*) AS c FROM purchase_items WHERE product_id = ?', [id]);

    if (salesCount.c > 0 || purchaseCount.c > 0) {
      return res.status(400).json({
        error: 'Cannot delete product because it has associated sales or purchase order records in the database. Archiving or zeroing stock is recommended.'
      });
    }

    // Delete stock movements first then product
    await db.query('DELETE FROM stock_movements WHERE product_id = ?', [id]);
    await db.query('DELETE FROM products WHERE product_id = ?', [id]);

    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Products DELETE Error:', error);
    res.status(500).json({ error: 'Failed to delete product', message: error.message });
  }
});

module.exports = router;
