const express = require('express');
const router = express.Router();
const db = require('../db');

// GET all purchase orders
router.get('/', async (req, res) => {
  try {
    const [purchases] = await db.query(`
      SELECT 
        po.purchase_id,
        po.supplier_id,
        s.supplier_name,
        po.purchase_date,
        po.status,
        po.total_amount,
        COUNT(pi.purchase_item_id) AS total_items,
        COALESCE(SUM(pi.quantity), 0) AS total_quantity
      FROM purchase_orders po
      JOIN suppliers s ON po.supplier_id = s.supplier_id
      LEFT JOIN purchase_items pi ON po.purchase_id = pi.purchase_id
      GROUP BY po.purchase_id, po.supplier_id, s.supplier_name, po.purchase_date, po.status, po.total_amount
      ORDER BY po.purchase_date DESC
    `);
    res.json(purchases);
  } catch (error) {
    console.error('Purchases GET Error:', error);
    res.status(500).json({ error: 'Failed to fetch purchase orders', message: error.message });
  }
});

// GET single purchase order details
router.get('/:id', async (req, res) => {
  try {
    const [[po]] = await db.query(`
      SELECT 
        po.*,
        s.supplier_name,
        s.phone AS supplier_phone,
        s.email AS supplier_email,
        s.address AS supplier_address
      FROM purchase_orders po
      JOIN suppliers s ON po.supplier_id = s.supplier_id
      WHERE po.purchase_id = ?
    `, [req.params.id]);

    if (!po) {
      return res.status(404).json({ error: 'Purchase order not found' });
    }

    const [items] = await db.query(`
      SELECT 
        pi.purchase_item_id,
        pi.product_id,
        p.sku,
        p.product_name,
        pi.quantity,
        pi.unit_cost,
        ROUND(pi.quantity * pi.unit_cost, 2) AS line_total
      FROM purchase_items pi
      JOIN products p ON pi.product_id = p.product_id
      WHERE pi.purchase_id = ?
    `, [req.params.id]);

    const [payments] = await db.query(`
      SELECT payment_id, amount, payment_method, payment_date
      FROM payments
      WHERE purchase_id = ?
    `, [req.params.id]);

    res.json({
      ...po,
      items,
      payments
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch purchase order details', message: error.message });
  }
});

// POST create new purchase order
router.post('/', async (req, res) => {
  const { supplier_id, status = 'Pending', items } = req.body;

  if (!supplier_id || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Supplier and at least one item are required' });
  }

  // Calculate total amount
  let totalAmount = 0;
  for (const item of items) {
    const qty = Number(item.quantity);
    const cost = Number(item.unit_cost);
    if (!item.product_id || qty <= 0 || cost < 0) {
      return res.status(400).json({ error: 'Each item must have a valid product, quantity > 0, and non-negative cost' });
    }
    totalAmount += qty * cost;
  }
  totalAmount = Math.round(totalAmount * 100) / 100;

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    // Insert purchase order
    const [poResult] = await conn.query(`
      INSERT INTO purchase_orders (supplier_id, purchase_date, status, total_amount)
      VALUES (?, NOW(), ?, ?)
    `, [supplier_id, status, totalAmount]);

    const purchaseId = poResult.insertId;

    // Insert items & optionally update inventory
    for (const item of items) {
      const qty = Number(item.quantity);
      const cost = Number(item.unit_cost);

      await conn.query(`
        INSERT INTO purchase_items (purchase_id, product_id, quantity, unit_cost)
        VALUES (?, ?, ?, ?)
      `, [purchaseId, item.product_id, qty, cost]);

      if (status === 'Received') {
        // Increase product stock
        await conn.query(`
          UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?
        `, [qty, item.product_id]);

        // Insert stock movement
        await conn.query(`
          INSERT INTO stock_movements (product_id, movement_type, quantity_change, movement_date, notes)
          VALUES (?, 'Purchase', ?, NOW(), ?)
        `, [item.product_id, qty, `Received purchase #${purchaseId}`]);
      }
    }

    await conn.commit();
    res.status(201).json({
      message: 'Purchase order created successfully',
      purchase_id: purchaseId,
      total_amount: totalAmount
    });
  } catch (error) {
    await conn.rollback();
    console.error('Purchases POST Error:', error);
    res.status(500).json({ error: 'Failed to create purchase order', message: error.message });
  } finally {
    conn.release();
  }
});

// PUT update status (e.g. mark as Received or Cancelled)
router.put('/:id/status', async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!['Pending', 'Received', 'Cancelled'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status. Must be Pending, Received, or Cancelled' });
  }

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    const [[po]] = await conn.query('SELECT * FROM purchase_orders WHERE purchase_id = ?', [id]);
    if (!po) {
      await conn.rollback();
      return res.status(404).json({ error: 'Purchase order not found' });
    }

    const prevStatus = po.status;

    if (prevStatus === status) {
      await conn.rollback();
      return res.json({ message: 'Status is already ' + status });
    }

    // Get order items
    const [items] = await conn.query('SELECT * FROM purchase_items WHERE purchase_id = ?', [id]);

    // If changing from (Pending or Cancelled) to Received -> increase stock
    if (status === 'Received' && prevStatus !== 'Received') {
      for (const item of items) {
        await conn.query('UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?', [item.quantity, item.product_id]);
        await conn.query(`
          INSERT INTO stock_movements (product_id, movement_type, quantity_change, movement_date, notes)
          VALUES (?, 'Purchase', ?, NOW(), ?)
        `, [item.product_id, item.quantity, `Received purchase #${id}`]);
      }
    }
    // If changing from Received to Cancelled -> reverse stock
    else if (status === 'Cancelled' && prevStatus === 'Received') {
      for (const item of items) {
        await conn.query('UPDATE products SET stock_quantity = GREATEST(0, stock_quantity - ?) WHERE product_id = ?', [item.quantity, item.product_id]);
        await conn.query(`
          INSERT INTO stock_movements (product_id, movement_type, quantity_change, movement_date, notes)
          VALUES (?, 'Adjustment', ?, NOW(), ?)
        `, [item.product_id, -item.quantity, `Reversal from cancelled purchase #${id}`]);
      }
    }

    await conn.query('UPDATE purchase_orders SET status = ? WHERE purchase_id = ?', [status, id]);

    await conn.commit();
    res.json({ message: `Purchase order #${id} status changed to ${status}` });
  } catch (error) {
    await conn.rollback();
    console.error('Purchases Status PUT Error:', error);
    res.status(500).json({ error: 'Failed to update purchase order status', message: error.message });
  } finally {
    conn.release();
  }
});

module.exports = router;
