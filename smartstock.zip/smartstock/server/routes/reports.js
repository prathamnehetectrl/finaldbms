const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/:reportType', async (req, res) => {
  const { reportType } = req.params;
  const { start_date, end_date } = req.query;

  try {
    let data = [];
    let summary = {};

    switch (reportType) {
      case 'sales': {
        let query = `
          SELECT 
            so.sale_id,
            so.sale_date,
            COALESCE(c.customer_name, 'Walk-in Customer') AS customer_name,
            so.status,
            so.total_amount,
            COUNT(si.sale_item_id) AS items_count,
            COALESCE(MAX(p.payment_method), 'Cash') AS payment_method
          FROM sales_orders so
          LEFT JOIN customers c ON so.customer_id = c.customer_id
          LEFT JOIN sales_items si ON so.sale_id = si.sale_id
          LEFT JOIN payments p ON so.sale_id = p.sale_id
          WHERE 1=1
        `;
        const params = [];
        if (start_date) { query += ` AND DATE(so.sale_date) >= ?`; params.push(start_date); }
        if (end_date) { query += ` AND DATE(so.sale_date) <= ?`; params.push(end_date); }
        query += ` GROUP BY so.sale_id, so.sale_date, c.customer_name, so.status, so.total_amount ORDER BY so.sale_date DESC`;

        [data] = await db.query(query, params);
        const total = data.reduce((sum, r) => sum + Number(r.total_amount), 0);
        summary = { totalRevenue: total, orderCount: data.length };
        break;
      }

      case 'profit': {
        let query = `
          SELECT 
            so.sale_id,
            so.sale_date,
            p.sku,
            p.product_name,
            c.category_name,
            si.quantity,
            si.unit_price,
            si.unit_cost,
            ROUND(si.quantity * si.unit_price, 2) AS line_revenue,
            ROUND(si.quantity * si.unit_cost, 2) AS line_cost,
            ROUND((si.unit_price - si.unit_cost) * si.quantity, 2) AS line_profit,
            ROUND(((si.unit_price - si.unit_cost) / si.unit_price) * 100, 1) AS margin_percent
          FROM sales_items si
          JOIN sales_orders so ON si.sale_id = so.sale_id
          JOIN products p ON si.product_id = p.product_id
          JOIN categories c ON p.category_id = c.category_id
          WHERE so.status = 'Completed'
        `;
        const params = [];
        if (start_date) { query += ` AND DATE(so.sale_date) >= ?`; params.push(start_date); }
        if (end_date) { query += ` AND DATE(so.sale_date) <= ?`; params.push(end_date); }
        query += ` ORDER BY so.sale_date DESC`;

        [data] = await db.query(query, params);
        const totalRevenue = data.reduce((sum, r) => sum + Number(r.line_revenue), 0);
        const totalProfit = data.reduce((sum, r) => sum + Number(r.line_profit), 0);
        summary = { totalRevenue, totalProfit, overallMargin: totalRevenue > 0 ? ((totalProfit / totalRevenue) * 100).toFixed(1) : 0 };
        break;
      }

      case 'inventory': {
        const [rows] = await db.query(`
          SELECT 
            p.product_id,
            p.sku,
            p.product_name,
            c.category_name,
            s.supplier_name,
            p.stock_quantity,
            p.reorder_level,
            p.cost_price,
            p.selling_price,
            ROUND(p.stock_quantity * p.cost_price, 2) AS inventory_cost,
            ROUND(p.stock_quantity * p.selling_price, 2) AS potential_revenue,
            ROUND(p.stock_quantity * (p.selling_price - p.cost_price), 2) AS potential_profit
          FROM products p
          JOIN categories c ON p.category_id = c.category_id
          JOIN suppliers s ON p.supplier_id = s.supplier_id
          ORDER BY p.product_id ASC
        `);
        data = rows;
        const totalCost = data.reduce((sum, r) => sum + Number(r.inventory_cost), 0);
        const totalUnits = data.reduce((sum, r) => sum + Number(r.stock_quantity), 0);
        summary = { totalProducts: data.length, totalUnits, totalCost };
        break;
      }

      case 'lowstock': {
        const [rows] = await db.query(`
          SELECT 
            p.product_id,
            p.sku,
            p.product_name,
            c.category_name,
            s.supplier_name,
            s.phone AS supplier_phone,
            p.stock_quantity,
            p.reorder_level,
            (p.reorder_level - p.stock_quantity) AS shortage,
            p.cost_price,
            ROUND((p.reorder_level * 2 - p.stock_quantity) * p.cost_price, 2) AS estimated_replenishment_cost
          FROM products p
          JOIN categories c ON p.category_id = c.category_id
          JOIN suppliers s ON p.supplier_id = s.supplier_id
          WHERE p.stock_quantity <= p.reorder_level
          ORDER BY p.stock_quantity ASC
        `);
        data = rows;
        summary = { lowStockItemsCount: data.length };
        break;
      }

      case 'purchases': {
        let query = `
          SELECT 
            po.purchase_id,
            po.purchase_date,
            s.supplier_name,
            po.status,
            po.total_amount,
            COUNT(pi.purchase_item_id) AS items_count,
            COALESCE(SUM(pi.quantity), 0) AS total_quantity
          FROM purchase_orders po
          JOIN suppliers s ON po.supplier_id = s.supplier_id
          LEFT JOIN purchase_items pi ON po.purchase_id = pi.purchase_id
          WHERE 1=1
        `;
        const params = [];
        if (start_date) { query += ` AND DATE(po.purchase_date) >= ?`; params.push(start_date); }
        if (end_date) { query += ` AND DATE(po.purchase_date) <= ?`; params.push(end_date); }
        query += ` GROUP BY po.purchase_id, po.purchase_date, s.supplier_name, po.status, po.total_amount ORDER BY po.purchase_date DESC`;

        [data] = await db.query(query, params);
        const total = data.reduce((sum, r) => sum + Number(r.total_amount), 0);
        summary = { totalPurchases: total, orderCount: data.length };
        break;
      }

      case 'suppliers': {
        const [rows] = await db.query(`
          SELECT 
            s.supplier_id,
            s.supplier_name,
            s.phone,
            s.email,
            s.address,
            COUNT(DISTINCT p.product_id) AS products_count,
            COUNT(DISTINCT po.purchase_id) AS orders_count,
            ROUND(COALESCE(SUM(po.total_amount), 0), 2) AS total_purchased
          FROM suppliers s
          LEFT JOIN products p ON s.supplier_id = p.supplier_id
          LEFT JOIN purchase_orders po ON s.supplier_id = po.supplier_id AND po.status = 'Received'
          GROUP BY s.supplier_id, s.supplier_name, s.phone, s.email, s.address
          ORDER BY total_purchased DESC
        `);
        data = rows;
        summary = { totalSuppliers: data.length };
        break;
      }

      case 'customers': {
        const [rows] = await db.query(`
          SELECT 
            c.customer_id,
            c.customer_name,
            c.phone,
            c.email,
            c.address,
            COUNT(so.sale_id) AS orders_count,
            ROUND(COALESCE(SUM(CASE WHEN so.status = 'Completed' THEN so.total_amount ELSE 0 END), 0), 2) AS total_spent
          FROM customers c
          LEFT JOIN sales_orders so ON c.customer_id = so.customer_id
          GROUP BY c.customer_id, c.customer_name, c.phone, c.email, c.address
          ORDER BY total_spent DESC
        `);
        data = rows;
        summary = { totalCustomers: data.length };
        break;
      }

      case 'payments': {
        let query = `
          SELECT 
            p.payment_id,
            p.payment_date,
            p.payment_method,
            p.amount,
            CASE 
              WHEN p.sale_id IS NOT NULL THEN 'Customer Sale'
              WHEN p.purchase_id IS NOT NULL THEN 'Supplier Purchase'
              ELSE 'General'
            END AS transaction_type,
            COALESCE(c.customer_name, s.supplier_name, 'N/A') AS party_name,
            COALESCE(p.sale_id, p.purchase_id) AS ref_id
          FROM payments p
          LEFT JOIN sales_orders so ON p.sale_id = so.sale_id
          LEFT JOIN customers c ON so.customer_id = c.customer_id
          LEFT JOIN purchase_orders po ON p.purchase_id = po.purchase_id
          LEFT JOIN suppliers s ON po.supplier_id = s.supplier_id
          WHERE 1=1
        `;
        const params = [];
        if (start_date) { query += ` AND DATE(p.payment_date) >= ?`; params.push(start_date); }
        if (end_date) { query += ` AND DATE(p.payment_date) <= ?`; params.push(end_date); }
        query += ` ORDER BY p.payment_date DESC`;

        [data] = await db.query(query, params);
        const total = data.reduce((sum, r) => sum + Number(r.amount), 0);
        summary = { totalAmount: total, count: data.length };
        break;
      }

      case 'movements': {
        let query = `
          SELECT 
            sm.movement_id,
            sm.movement_date,
            p.sku,
            p.product_name,
            sm.movement_type,
            sm.quantity_change,
            sm.notes
          FROM stock_movements sm
          JOIN products p ON sm.product_id = p.product_id
          WHERE 1=1
        `;
        const params = [];
        if (start_date) { query += ` AND DATE(sm.movement_date) >= ?`; params.push(start_date); }
        if (end_date) { query += ` AND DATE(sm.movement_date) <= ?`; params.push(end_date); }
        query += ` ORDER BY sm.movement_date DESC`;

        [data] = await db.query(query, params);
        summary = { totalMovements: data.length };
        break;
      }

      default:
        return res.status(400).json({ error: `Unknown report type: ${reportType}` });
    }

    res.json({
      reportType,
      summary,
      generatedAt: new Date().toISOString(),
      rows: data
    });
  } catch (error) {
    console.error('Reports Error:', error);
    res.status(500).json({ error: 'Failed to generate report', message: error.message });
  }
});

module.exports = router;
