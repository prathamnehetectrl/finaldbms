const express = require('express');
const router = express.Router();
const db = require('../db');

// GET all sales orders
router.get('/', async (req, res) => {
  try {
    const [sales] = await db.query(`
      SELECT 
        so.sale_id,
        so.customer_id,
        COALESCE(c.customer_name, 'Walk-in Customer') AS customer_name,
        c.phone AS customer_phone,
        so.sale_date,
        so.status,
        so.total_amount,
        COUNT(si.sale_item_id) AS total_items,
        COALESCE(SUM(si.quantity), 0) AS total_quantity,
        COALESCE(MAX(p.payment_method), 'Pending') AS payment_method
      FROM sales_orders so
      LEFT JOIN customers c ON so.customer_id = c.customer_id
      LEFT JOIN sales_items si ON so.sale_id = si.sale_id
      LEFT JOIN payments p ON so.sale_id = p.sale_id
      GROUP BY so.sale_id, so.customer_id, c.customer_name, c.phone, so.sale_date, so.status, so.total_amount
      ORDER BY so.sale_date DESC
    `);
    res.json(sales);
  } catch (error) {
    console.error('Sales GET Error:', error);
    res.status(500).json({ error: 'Failed to fetch sales orders', message: error.message });
  }
});

// GET single sale order details for invoice
router.get('/:id', async (req, res) => {
  try {
    const [[sale]] = await db.query(`
      SELECT 
        so.*,
        COALESCE(c.customer_name, 'Walk-in Customer') AS customer_name,
        c.phone AS customer_phone,
        c.email AS customer_email,
        c.address AS customer_address
      FROM sales_orders so
      LEFT JOIN customers c ON so.customer_id = c.customer_id
      WHERE so.sale_id = ?
    `, [req.params.id]);

    if (!sale) {
      return res.status(404).json({ error: 'Sales order not found' });
    }

    const [items] = await db.query(`
      SELECT 
        si.sale_item_id,
        si.product_id,
        p.sku,
        p.product_name,
        si.quantity,
        si.unit_price,
        si.unit_cost,
        ROUND(si.quantity * si.unit_price, 2) AS line_total,
        ROUND((si.unit_price - si.unit_cost) * si.quantity, 2) AS line_profit
      FROM sales_items si
      JOIN products p ON si.product_id = p.product_id
      WHERE si.sale_id = ?
    `, [req.params.id]);

    const [payments] = await db.query(`
      SELECT payment_id, amount, payment_method, payment_date
      FROM payments
      WHERE sale_id = ?
    `, [req.params.id]);

    res.json({
      ...sale,
      items,
      payments
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch sales order details', message: error.message });
  }
});

// POST transactional Point of Sale order creation
router.post('/', async (req, res) => {
  const { customer_id, items, payment_method = 'Cash', status = 'Completed' } = req.body;

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Sale must contain at least one item' });
  }

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    let totalAmount = 0;
    const validatedItems = [];

    // 1. Verify stock availability and collect item prices
    for (const item of items) {
      const qty = Number(item.quantity);
      if (!item.product_id || qty <= 0) {
        await conn.rollback();
        return res.status(400).json({ error: 'Invalid product or quantity' });
      }

      const [[prod]] = await conn.query(`
        SELECT product_id, sku, product_name, cost_price, selling_price, stock_quantity
        FROM products
        WHERE product_id = ?
        FOR UPDATE
      `, [item.product_id]);

      if (!prod) {
        await conn.rollback();
        return res.status(400).json({ error: `Product ID ${item.product_id} not found` });
      }

      if (status === 'Completed' && prod.stock_quantity < qty) {
        await conn.rollback();
        return res.status(400).json({
          error: `Insufficient stock for "${prod.product_name}". Requested: ${qty}, Available: ${prod.stock_quantity}`
        });
      }

      const unitPrice = item.unit_price !== undefined ? Number(item.unit_price) : Number(prod.selling_price);
      const unitCost = Number(prod.cost_price);
      const lineTotal = Math.round(qty * unitPrice * 100) / 100;
      totalAmount += lineTotal;

      validatedItems.push({
        product_id: prod.product_id,
        product_name: prod.product_name,
        sku: prod.sku,
        quantity: qty,
        unit_price: unitPrice,
        unit_cost: unitCost,
        line_total: lineTotal
      });
    }

    totalAmount = Math.round(totalAmount * 100) / 100;

    // 2. Insert sales order
    const [soResult] = await conn.query(`
      INSERT INTO sales_orders (customer_id, sale_date, status, total_amount)
      VALUES (?, NOW(), ?, ?)
    `, [customer_id || null, status, totalAmount]);

    const saleId = soResult.insertId;

    // 3. Insert sales items, update stock, record movements
    for (const item of validatedItems) {
      await conn.query(`
        INSERT INTO sales_items (sale_id, product_id, quantity, unit_price, unit_cost)
        VALUES (?, ?, ?, ?, ?)
      `, [saleId, item.product_id, item.quantity, item.unit_price, item.unit_cost]);

      if (status === 'Completed') {
        // Deduct inventory
        await conn.query(`
          UPDATE products SET stock_quantity = stock_quantity - ? WHERE product_id = ?
        `, [item.quantity, item.product_id]);

        // Insert stock movement
        await conn.query(`
          INSERT INTO stock_movements (product_id, movement_type, quantity_change, movement_date, notes)
          VALUES (?, 'Sale', ?, NOW(), ?)
        `, [item.product_id, -item.quantity, `Completed sale #${saleId}`]);
      }
    }

    // 4. Record payment if payment_method is provided and status is Completed
    if (status === 'Completed' && payment_method) {
      await conn.query(`
        INSERT INTO payments (sale_id, purchase_id, amount, payment_method, payment_date)
        VALUES (?, NULL, ?, ?, NOW())
      `, [saleId, totalAmount, payment_method]);
    }

    await conn.commit();

    res.status(201).json({
      message: 'Sale created successfully',
      sale_id: saleId,
      total_amount: totalAmount,
      items_count: validatedItems.length,
      items: validatedItems
    });
  } catch (error) {
    await conn.rollback();
    console.error('Sales POST Error:', error);
    res.status(500).json({ error: 'Failed to process sale', message: error.message });
  } finally {
    conn.release();
  }
});

// PUT cancel sale order
router.put('/:id/cancel', async (req, res) => {
  const { id } = req.params;
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    const [[sale]] = await conn.query('SELECT * FROM sales_orders WHERE sale_id = ?', [id]);
    if (!sale) {
      await conn.rollback();
      return res.status(404).json({ error: 'Sales order not found' });
    }

    if (sale.status === 'Cancelled') {
      await conn.rollback();
      return res.json({ message: 'Order is already cancelled' });
    }

    // If order was Completed, restore stock
    if (sale.status === 'Completed') {
      const [items] = await conn.query('SELECT * FROM sales_items WHERE sale_id = ?', [id]);
      for (const item of items) {
        await conn.query('UPDATE products SET stock_quantity = stock_quantity + ? WHERE product_id = ?', [item.quantity, item.product_id]);
        await conn.query(`
          INSERT INTO stock_movements (product_id, movement_type, quantity_change, movement_date, notes)
          VALUES (?, 'Adjustment', ?, NOW(), ?)
        `, [item.product_id, item.quantity, `Restocked from cancelled sale #${id}`]);
      }
    }

    await conn.query("UPDATE sales_orders SET status = 'Cancelled' WHERE sale_id = ?", [id]);

    await conn.commit();
    res.json({ message: `Sales order #${id} has been cancelled and inventory restored.` });
  } catch (error) {
    await conn.rollback();
    console.error('Sales Cancel Error:', error);
    res.status(500).json({ error: 'Failed to cancel sale', message: error.message });
  } finally {
    conn.release();
  }
});

module.exports = router;
