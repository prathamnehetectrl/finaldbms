const express = require('express');
const router = express.Router();
const db = require('../db');

// GET all suppliers
router.get('/', async (req, res) => {
  try {
    const [suppliers] = await db.query(`
      SELECT 
        s.supplier_id,
        s.supplier_name,
        s.phone,
        s.email,
        s.address,
        COUNT(DISTINCT p.product_id) AS product_count,
        COUNT(DISTINCT po.purchase_id) AS total_orders,
        ROUND(COALESCE(SUM(po.total_amount), 0), 2) AS total_purchased
      FROM suppliers s
      LEFT JOIN products p ON s.supplier_id = p.supplier_id
      LEFT JOIN purchase_orders po ON s.supplier_id = po.supplier_id AND po.status = 'Received'
      GROUP BY s.supplier_id, s.supplier_name, s.phone, s.email, s.address
      ORDER BY s.supplier_id ASC
    `);
    res.json(suppliers);
  } catch (error) {
    console.error('Suppliers GET Error:', error);
    res.status(500).json({ error: 'Failed to fetch suppliers', message: error.message });
  }
});

// GET supplier details with orders and products
router.get('/:id', async (req, res) => {
  try {
    const [[supplier]] = await db.query('SELECT * FROM suppliers WHERE supplier_id = ?', [req.params.id]);
    if (!supplier) {
      return res.status(404).json({ error: 'Supplier not found' });
    }

    const [products] = await db.query('SELECT product_id, sku, product_name, stock_quantity, cost_price FROM products WHERE supplier_id = ?', [req.params.id]);
    const [orders] = await db.query('SELECT purchase_id, purchase_date, status, total_amount FROM purchase_orders WHERE supplier_id = ? ORDER BY purchase_date DESC', [req.params.id]);

    res.json({
      ...supplier,
      products,
      orders
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch supplier details', message: error.message });
  }
});

// POST add supplier
router.post('/', async (req, res) => {
  const { supplier_name, phone, email, address } = req.body;
  if (!supplier_name || !supplier_name.trim()) {
    return res.status(400).json({ error: 'Supplier name is required' });
  }

  try {
    const [result] = await db.query(`
      INSERT INTO suppliers (supplier_name, phone, email, address) VALUES (?, ?, ?, ?)
    `, [supplier_name.trim(), phone || null, email || null, address || null]);

    res.status(201).json({ message: 'Supplier created successfully', supplier_id: result.insertId });
  } catch (error) {
    console.error('Suppliers POST Error:', error);
    res.status(500).json({ error: 'Failed to create supplier', message: error.message });
  }
});

// PUT update supplier
router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { supplier_name, phone, email, address } = req.body;

  if (!supplier_name || !supplier_name.trim()) {
    return res.status(400).json({ error: 'Supplier name is required' });
  }

  try {
    const [result] = await db.query(`
      UPDATE suppliers SET supplier_name = ?, phone = ?, email = ?, address = ? WHERE supplier_id = ?
    `, [supplier_name.trim(), phone || null, email || null, address || null, id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Supplier not found' });
    }

    res.json({ message: 'Supplier updated successfully' });
  } catch (error) {
    console.error('Suppliers PUT Error:', error);
    res.status(500).json({ error: 'Failed to update supplier', message: error.message });
  }
});

// DELETE supplier
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [[prodCount]] = await db.query('SELECT COUNT(*) AS c FROM products WHERE supplier_id = ?', [id]);
    const [[orderCount]] = await db.query('SELECT COUNT(*) AS c FROM purchase_orders WHERE supplier_id = ?', [id]);

    if (prodCount.c > 0 || orderCount.c > 0) {
      return res.status(400).json({
        error: `Cannot delete supplier: linked to ${prodCount.c} product(s) and ${orderCount.c} purchase order(s).`
      });
    }

    const [result] = await db.query('DELETE FROM suppliers WHERE supplier_id = ?', [id]);
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Supplier not found' });
    }

    res.json({ message: 'Supplier deleted successfully' });
  } catch (error) {
    console.error('Suppliers DELETE Error:', error);
    res.status(500).json({ error: 'Failed to delete supplier', message: error.message });
  }
});

module.exports = router;
