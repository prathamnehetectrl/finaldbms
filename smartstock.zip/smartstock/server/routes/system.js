const express = require('express');
const router = express.Router();
const db = require('../db');

// GET system health & DB status
router.get('/health', async (req, res) => {
  const startTime = Date.now();
  try {
    const [[ver]] = await db.query('SELECT VERSION() AS version, DATABASE() as db_name');
    const latency = Date.now() - startTime;

    // Get row counts for all tables
    const [counts] = await db.query(`
      SELECT 'categories' AS table_name, COUNT(*) AS row_count FROM categories
      UNION ALL SELECT 'suppliers', COUNT(*) FROM suppliers
      UNION ALL SELECT 'customers', COUNT(*) FROM customers
      UNION ALL SELECT 'products', COUNT(*) FROM products
      UNION ALL SELECT 'purchase_orders', COUNT(*) FROM purchase_orders
      UNION ALL SELECT 'purchase_items', COUNT(*) FROM purchase_items
      UNION ALL SELECT 'sales_orders', COUNT(*) FROM sales_orders
      UNION ALL SELECT 'sales_items', COUNT(*) FROM sales_items
      UNION ALL SELECT 'payments', COUNT(*) FROM payments
      UNION ALL SELECT 'stock_movements', COUNT(*) FROM stock_movements
    `);

    res.json({
      status: 'healthy',
      database: {
        engine: 'MySQL',
        connected: true,
        version: ver.version,
        databaseName: ver.db_name,
        latencyMs: latency,
        host: process.env.DB_HOST || '127.0.0.1',
        port: process.env.DB_PORT || 3306,
        user: process.env.DB_USER || 'root'
      },
      tableStats: counts,
      environment: {
        nodeVersion: process.version,
        uptimeSeconds: Math.floor(process.uptime()),
        timestamp: new Date().toISOString()
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      database: {
        engine: 'MySQL',
        connected: false,
        error: error.message
      }
    });
  }
});

module.exports = router;
